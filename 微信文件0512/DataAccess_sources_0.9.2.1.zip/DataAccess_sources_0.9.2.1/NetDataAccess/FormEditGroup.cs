﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NetDataAccess.Common;
using NetDataAccess.Dao;

namespace NetDataAccess
{
    /// <summary>
    /// 编辑分组
    /// </summary>
    public partial class FormEditGroup : Form
    {
        #region 构造函数
        public FormEditGroup(Proj_Group group)
        {
            InitializeComponent();
            this.Group = group;
            this.Load += new EventHandler(FormEditGroup_Load);
        }
        #endregion

        #region Load时显示分组信息
        private void FormEditGroup_Load(object sender, EventArgs e)
        {
            if (this.Group != null)
            {
                this.textBoxName.Text = this.Group.Name;
                this.textBoxDescription.Text = this.Group.Description;
            }
        }
        #endregion

        #region 分组
        public Proj_Group _Group = null;
        /// <summary>
        /// 分组
        /// </summary>
        public Proj_Group Group 
        {
            get
            {
                return _Group;
            }
            set
            {
                _Group = value;
            }
        }
        #endregion 

        #region 点击确认按钮
        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (Check() && SaveToDB())
            {
                this.DialogResult = DialogResult.OK;
            }
        }
        #endregion

        #region 保存
        private bool SaveToDB()
        {
            if (CommonUtil.IsNullOrBlank(this.Group.Id))
            {
                string id = ProjectTaskAccess.AddNewGroup(this.Group);
                if (id != null)
                {
                    this.Group.Id = id;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
               return ProjectTaskAccess.UpdateGroup(this.Group);
            }
        }
        #endregion

        #region 验证
        private bool Check()
        {
            string groupName = this.textBoxName.Text.Trim();
            if (CommonUtil.IsNullOrBlank(groupName))
            {
                CommonUtil.Alert("验证", "请录入组名.");
                return false;
            }
            else
            {
                //新建分组
                if (this.Group == null)
                {
                    this.Group = new Proj_Group();
                    this.Group.Name = groupName;
                    this.Group.Description = this.textBoxDescription.Text.Trim();
                    return true;
                }
                else
                {
                    //判断此组名是否存在且Id不同
                    Proj_Group g = ProjectTaskAccess.GetGroupInfoByNameFromDB(groupName);
                    if (g != null && g.Id != this.Group.Id)
                    {
                        CommonUtil.Alert("验证", "已存在的组名，请使用其它名称.");
                        return false;
                    }
                    else
                    {
                        this.Group.Name = groupName;
                        this.Group.Description = this.textBoxDescription.Text.Trim();
                        return true;
                    }
                }
            }
        }
        #endregion

        #region 取消按钮
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
