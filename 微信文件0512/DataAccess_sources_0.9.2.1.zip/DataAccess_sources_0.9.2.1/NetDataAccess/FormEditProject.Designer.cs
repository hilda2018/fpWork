﻿namespace NetDataAccess
{
    partial class FormEditProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMain = new System.Windows.Forms.Panel();
            this.groupBoxExternal = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelProgramAfterGrabAll = new System.Windows.Forms.Label();
            this.textBoxProgramAfterGrabAll = new System.Windows.Forms.TextBox();
            this.groupBoxDetailPage = new System.Windows.Forms.GroupBox();
            this.panelDetailBottom = new System.Windows.Forms.Panel();
            this.labelDetailGrabInfo = new System.Windows.Forms.Label();
            this.textBoxDetailGrabInfo = new System.Windows.Forms.TextBox();
            this.panelDetailTop = new System.Windows.Forms.Panel();
            this.comboBoxDetailGrabType = new System.Windows.Forms.ComboBox();
            this.labelDetailGrabType = new System.Windows.Forms.Label();
            this.groupBoxListPage = new System.Windows.Forms.GroupBox();
            this.panelListPageBottom = new System.Windows.Forms.Panel();
            this.labelListPageInfo = new System.Windows.Forms.Label();
            this.textBoxListPageInfo = new System.Windows.Forms.TextBox();
            this.panelListPageTop = new System.Windows.Forms.Panel();
            this.comboBoxListNavigateType = new System.Windows.Forms.ComboBox();
            this.labelListNavigateType = new System.Windows.Forms.Label();
            this.groupBoxLogin = new System.Windows.Forms.GroupBox();
            this.panelLoginBottom = new System.Windows.Forms.Panel();
            this.labelLoginPageInfo = new System.Windows.Forms.Label();
            this.textBoxLoginPageInfo = new System.Windows.Forms.TextBox();
            this.panelLoginTop = new System.Windows.Forms.Panel();
            this.comboBoxLoginType = new System.Windows.Forms.ComboBox();
            this.labelLoginType = new System.Windows.Forms.Label();
            this.groupBoxRun = new System.Windows.Forms.GroupBox();
            this.panelTaskTime = new System.Windows.Forms.Panel();
            this.textBoxTaskTime = new System.Windows.Forms.TextBox();
            this.labelTaskTime = new System.Windows.Forms.Label();
            this.panelRunTop = new System.Windows.Forms.Panel();
            this.labelTaskTimeType = new System.Windows.Forms.Label();
            this.numericUpDownReTryTime = new System.Windows.Forms.NumericUpDown();
            this.labelReTryTime = new System.Windows.Forms.Label();
            this.numericUpDownReTryInterval = new System.Windows.Forms.NumericUpDown();
            this.labelReTryInterval = new System.Windows.Forms.Label();
            this.comboBoxTaskTimeType = new System.Windows.Forms.ComboBox();
            this.groupBoxBase = new System.Windows.Forms.GroupBox();
            this.textBoxDescription = new System.Windows.Forms.TextBox();
            this.labelDescription = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.buttonShowWebPage = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            this.panelMain.SuspendLayout();
            this.groupBoxExternal.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBoxDetailPage.SuspendLayout();
            this.panelDetailBottom.SuspendLayout();
            this.panelDetailTop.SuspendLayout();
            this.groupBoxListPage.SuspendLayout();
            this.panelListPageBottom.SuspendLayout();
            this.panelListPageTop.SuspendLayout();
            this.groupBoxLogin.SuspendLayout();
            this.panelLoginBottom.SuspendLayout();
            this.panelLoginTop.SuspendLayout();
            this.groupBoxRun.SuspendLayout();
            this.panelTaskTime.SuspendLayout();
            this.panelRunTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownReTryTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownReTryInterval)).BeginInit();
            this.groupBoxBase.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.groupBoxExternal);
            this.panelMain.Controls.Add(this.groupBoxDetailPage);
            this.panelMain.Controls.Add(this.groupBoxListPage);
            this.panelMain.Controls.Add(this.groupBoxLogin);
            this.panelMain.Controls.Add(this.groupBoxRun);
            this.panelMain.Controls.Add(this.groupBoxBase);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMain.Location = new System.Drawing.Point(3, 3);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(844, 511);
            this.panelMain.TabIndex = 0;
            // 
            // groupBoxExternal
            // 
            this.groupBoxExternal.AutoSize = true;
            this.groupBoxExternal.Controls.Add(this.panel1);
            this.groupBoxExternal.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxExternal.Location = new System.Drawing.Point(0, 436);
            this.groupBoxExternal.Name = "groupBoxExternal";
            this.groupBoxExternal.Size = new System.Drawing.Size(844, 75);
            this.groupBoxExternal.TabIndex = 9;
            this.groupBoxExternal.TabStop = false;
            this.groupBoxExternal.Text = "事件";
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.labelProgramAfterGrabAll);
            this.panel1.Controls.Add(this.textBoxProgramAfterGrabAll);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(838, 55);
            this.panel1.TabIndex = 5;
            // 
            // labelProgramAfterGrabAll
            // 
            this.labelProgramAfterGrabAll.AutoSize = true;
            this.labelProgramAfterGrabAll.Location = new System.Drawing.Point(9, 6);
            this.labelProgramAfterGrabAll.Name = "labelProgramAfterGrabAll";
            this.labelProgramAfterGrabAll.Size = new System.Drawing.Size(95, 12);
            this.labelProgramAfterGrabAll.TabIndex = 1;
            this.labelProgramAfterGrabAll.Text = "全部抓取完成后:";
            // 
            // textBoxProgramAfterGrabAll
            // 
            this.textBoxProgramAfterGrabAll.Location = new System.Drawing.Point(107, 3);
            this.textBoxProgramAfterGrabAll.Multiline = true;
            this.textBoxProgramAfterGrabAll.Name = "textBoxProgramAfterGrabAll";
            this.textBoxProgramAfterGrabAll.Size = new System.Drawing.Size(712, 49);
            this.textBoxProgramAfterGrabAll.TabIndex = 11;
            // 
            // groupBoxDetailPage
            // 
            this.groupBoxDetailPage.AutoSize = true;
            this.groupBoxDetailPage.Controls.Add(this.panelDetailBottom);
            this.groupBoxDetailPage.Controls.Add(this.panelDetailTop);
            this.groupBoxDetailPage.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxDetailPage.Location = new System.Drawing.Point(0, 337);
            this.groupBoxDetailPage.Name = "groupBoxDetailPage";
            this.groupBoxDetailPage.Size = new System.Drawing.Size(844, 99);
            this.groupBoxDetailPage.TabIndex = 8;
            this.groupBoxDetailPage.TabStop = false;
            this.groupBoxDetailPage.Text = "详情页";
            // 
            // panelDetailBottom
            // 
            this.panelDetailBottom.AutoSize = true;
            this.panelDetailBottom.Controls.Add(this.labelDetailGrabInfo);
            this.panelDetailBottom.Controls.Add(this.textBoxDetailGrabInfo);
            this.panelDetailBottom.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDetailBottom.Location = new System.Drawing.Point(3, 41);
            this.panelDetailBottom.Name = "panelDetailBottom";
            this.panelDetailBottom.Size = new System.Drawing.Size(838, 55);
            this.panelDetailBottom.TabIndex = 5;
            // 
            // labelDetailGrabInfo
            // 
            this.labelDetailGrabInfo.AutoSize = true;
            this.labelDetailGrabInfo.Location = new System.Drawing.Point(45, 6);
            this.labelDetailGrabInfo.Name = "labelDetailGrabInfo";
            this.labelDetailGrabInfo.Size = new System.Drawing.Size(59, 12);
            this.labelDetailGrabInfo.TabIndex = 1;
            this.labelDetailGrabInfo.Text = "抓取设置:";
            // 
            // textBoxDetailGrabInfo
            // 
            this.textBoxDetailGrabInfo.Location = new System.Drawing.Point(107, 3);
            this.textBoxDetailGrabInfo.Multiline = true;
            this.textBoxDetailGrabInfo.Name = "textBoxDetailGrabInfo";
            this.textBoxDetailGrabInfo.Size = new System.Drawing.Size(712, 49);
            this.textBoxDetailGrabInfo.TabIndex = 11;
            // 
            // panelDetailTop
            // 
            this.panelDetailTop.Controls.Add(this.comboBoxDetailGrabType);
            this.panelDetailTop.Controls.Add(this.labelDetailGrabType);
            this.panelDetailTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDetailTop.Location = new System.Drawing.Point(3, 17);
            this.panelDetailTop.Name = "panelDetailTop";
            this.panelDetailTop.Size = new System.Drawing.Size(838, 24);
            this.panelDetailTop.TabIndex = 5;
            // 
            // comboBoxDetailGrabType
            // 
            this.comboBoxDetailGrabType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDetailGrabType.FormattingEnabled = true;
            this.comboBoxDetailGrabType.Items.AddRange(new object[] {
            "SingleLineType",
            "MultiLineType",
            "ProgramType"});
            this.comboBoxDetailGrabType.Location = new System.Drawing.Point(107, 3);
            this.comboBoxDetailGrabType.Name = "comboBoxDetailGrabType";
            this.comboBoxDetailGrabType.Size = new System.Drawing.Size(163, 20);
            this.comboBoxDetailGrabType.TabIndex = 10;
            // 
            // labelDetailGrabType
            // 
            this.labelDetailGrabType.AutoSize = true;
            this.labelDetailGrabType.Location = new System.Drawing.Point(45, 6);
            this.labelDetailGrabType.Name = "labelDetailGrabType";
            this.labelDetailGrabType.Size = new System.Drawing.Size(59, 12);
            this.labelDetailGrabType.TabIndex = 3;
            this.labelDetailGrabType.Text = "抓取方式:";
            // 
            // groupBoxListPage
            // 
            this.groupBoxListPage.AutoSize = true;
            this.groupBoxListPage.Controls.Add(this.panelListPageBottom);
            this.groupBoxListPage.Controls.Add(this.panelListPageTop);
            this.groupBoxListPage.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxListPage.Location = new System.Drawing.Point(0, 238);
            this.groupBoxListPage.Name = "groupBoxListPage";
            this.groupBoxListPage.Size = new System.Drawing.Size(844, 99);
            this.groupBoxListPage.TabIndex = 7;
            this.groupBoxListPage.TabStop = false;
            this.groupBoxListPage.Text = "列表页";
            // 
            // panelListPageBottom
            // 
            this.panelListPageBottom.AutoSize = true;
            this.panelListPageBottom.Controls.Add(this.labelListPageInfo);
            this.panelListPageBottom.Controls.Add(this.textBoxListPageInfo);
            this.panelListPageBottom.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelListPageBottom.Location = new System.Drawing.Point(3, 41);
            this.panelListPageBottom.Name = "panelListPageBottom";
            this.panelListPageBottom.Size = new System.Drawing.Size(838, 55);
            this.panelListPageBottom.TabIndex = 5;
            // 
            // labelListPageInfo
            // 
            this.labelListPageInfo.AutoSize = true;
            this.labelListPageInfo.Location = new System.Drawing.Point(33, 6);
            this.labelListPageInfo.Name = "labelListPageInfo";
            this.labelListPageInfo.Size = new System.Drawing.Size(71, 12);
            this.labelListPageInfo.TabIndex = 1;
            this.labelListPageInfo.Text = "列表页设置:";
            // 
            // textBoxListPageInfo
            // 
            this.textBoxListPageInfo.Location = new System.Drawing.Point(107, 3);
            this.textBoxListPageInfo.Multiline = true;
            this.textBoxListPageInfo.Name = "textBoxListPageInfo";
            this.textBoxListPageInfo.Size = new System.Drawing.Size(712, 49);
            this.textBoxListPageInfo.TabIndex = 9;
            // 
            // panelListPageTop
            // 
            this.panelListPageTop.Controls.Add(this.comboBoxListNavigateType);
            this.panelListPageTop.Controls.Add(this.labelListNavigateType);
            this.panelListPageTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelListPageTop.Location = new System.Drawing.Point(3, 17);
            this.panelListPageTop.Name = "panelListPageTop";
            this.panelListPageTop.Size = new System.Drawing.Size(838, 24);
            this.panelListPageTop.TabIndex = 5;
            // 
            // comboBoxListNavigateType
            // 
            this.comboBoxListNavigateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxListNavigateType.FormattingEnabled = true;
            this.comboBoxListNavigateType.Items.AddRange(new object[] {
            "ClickNextType",
            "ProgramType"});
            this.comboBoxListNavigateType.Location = new System.Drawing.Point(107, 3);
            this.comboBoxListNavigateType.Name = "comboBoxListNavigateType";
            this.comboBoxListNavigateType.Size = new System.Drawing.Size(163, 20);
            this.comboBoxListNavigateType.TabIndex = 8;
            // 
            // labelListNavigateType
            // 
            this.labelListNavigateType.AutoSize = true;
            this.labelListNavigateType.Location = new System.Drawing.Point(45, 6);
            this.labelListNavigateType.Name = "labelListNavigateType";
            this.labelListNavigateType.Size = new System.Drawing.Size(59, 12);
            this.labelListNavigateType.TabIndex = 3;
            this.labelListNavigateType.Text = "导航方式:";
            // 
            // groupBoxLogin
            // 
            this.groupBoxLogin.AutoSize = true;
            this.groupBoxLogin.Controls.Add(this.panelLoginBottom);
            this.groupBoxLogin.Controls.Add(this.panelLoginTop);
            this.groupBoxLogin.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxLogin.Location = new System.Drawing.Point(0, 140);
            this.groupBoxLogin.Name = "groupBoxLogin";
            this.groupBoxLogin.Size = new System.Drawing.Size(844, 98);
            this.groupBoxLogin.TabIndex = 4;
            this.groupBoxLogin.TabStop = false;
            this.groupBoxLogin.Text = "登录";
            // 
            // panelLoginBottom
            // 
            this.panelLoginBottom.AutoSize = true;
            this.panelLoginBottom.Controls.Add(this.labelLoginPageInfo);
            this.panelLoginBottom.Controls.Add(this.textBoxLoginPageInfo);
            this.panelLoginBottom.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLoginBottom.Location = new System.Drawing.Point(3, 40);
            this.panelLoginBottom.Name = "panelLoginBottom";
            this.panelLoginBottom.Size = new System.Drawing.Size(838, 55);
            this.panelLoginBottom.TabIndex = 5;
            // 
            // labelLoginPageInfo
            // 
            this.labelLoginPageInfo.AutoSize = true;
            this.labelLoginPageInfo.Location = new System.Drawing.Point(33, 6);
            this.labelLoginPageInfo.Name = "labelLoginPageInfo";
            this.labelLoginPageInfo.Size = new System.Drawing.Size(71, 12);
            this.labelLoginPageInfo.TabIndex = 1;
            this.labelLoginPageInfo.Text = "登录页设置:";
            // 
            // textBoxLoginPageInfo
            // 
            this.textBoxLoginPageInfo.Location = new System.Drawing.Point(105, 3);
            this.textBoxLoginPageInfo.Multiline = true;
            this.textBoxLoginPageInfo.Name = "textBoxLoginPageInfo";
            this.textBoxLoginPageInfo.Size = new System.Drawing.Size(716, 49);
            this.textBoxLoginPageInfo.TabIndex = 7;
            // 
            // panelLoginTop
            // 
            this.panelLoginTop.Controls.Add(this.comboBoxLoginType);
            this.panelLoginTop.Controls.Add(this.labelLoginType);
            this.panelLoginTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLoginTop.Location = new System.Drawing.Point(3, 17);
            this.panelLoginTop.Name = "panelLoginTop";
            this.panelLoginTop.Size = new System.Drawing.Size(838, 23);
            this.panelLoginTop.TabIndex = 5;
            // 
            // comboBoxLoginType
            // 
            this.comboBoxLoginType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxLoginType.FormattingEnabled = true;
            this.comboBoxLoginType.Items.AddRange(new object[] {
            "HasLogin",
            "NoneLogin"});
            this.comboBoxLoginType.Location = new System.Drawing.Point(105, 2);
            this.comboBoxLoginType.Name = "comboBoxLoginType";
            this.comboBoxLoginType.Size = new System.Drawing.Size(163, 20);
            this.comboBoxLoginType.TabIndex = 6;
            // 
            // labelLoginType
            // 
            this.labelLoginType.AutoSize = true;
            this.labelLoginType.Location = new System.Drawing.Point(43, 7);
            this.labelLoginType.Name = "labelLoginType";
            this.labelLoginType.Size = new System.Drawing.Size(59, 12);
            this.labelLoginType.TabIndex = 3;
            this.labelLoginType.Text = "登录方式:";
            // 
            // groupBoxRun
            // 
            this.groupBoxRun.AutoSize = true;
            this.groupBoxRun.Controls.Add(this.panelTaskTime);
            this.groupBoxRun.Controls.Add(this.panelRunTop);
            this.groupBoxRun.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxRun.Location = new System.Drawing.Point(0, 42);
            this.groupBoxRun.Name = "groupBoxRun";
            this.groupBoxRun.Size = new System.Drawing.Size(844, 98);
            this.groupBoxRun.TabIndex = 3;
            this.groupBoxRun.TabStop = false;
            this.groupBoxRun.Text = "执行";
            // 
            // panelTaskTime
            // 
            this.panelTaskTime.AutoSize = true;
            this.panelTaskTime.Controls.Add(this.textBoxTaskTime);
            this.panelTaskTime.Controls.Add(this.labelTaskTime);
            this.panelTaskTime.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTaskTime.Location = new System.Drawing.Point(3, 40);
            this.panelTaskTime.Name = "panelTaskTime";
            this.panelTaskTime.Size = new System.Drawing.Size(838, 55);
            this.panelTaskTime.TabIndex = 5;
            // 
            // textBoxTaskTime
            // 
            this.textBoxTaskTime.Location = new System.Drawing.Point(105, 3);
            this.textBoxTaskTime.Multiline = true;
            this.textBoxTaskTime.Name = "textBoxTaskTime";
            this.textBoxTaskTime.Size = new System.Drawing.Size(714, 49);
            this.textBoxTaskTime.TabIndex = 5;
            // 
            // labelTaskTime
            // 
            this.labelTaskTime.AutoSize = true;
            this.labelTaskTime.Location = new System.Drawing.Point(29, 6);
            this.labelTaskTime.Name = "labelTaskTime";
            this.labelTaskTime.Size = new System.Drawing.Size(71, 12);
            this.labelTaskTime.TabIndex = 3;
            this.labelTaskTime.Text = "定时器设置:";
            // 
            // panelRunTop
            // 
            this.panelRunTop.Controls.Add(this.labelTaskTimeType);
            this.panelRunTop.Controls.Add(this.numericUpDownReTryTime);
            this.panelRunTop.Controls.Add(this.labelReTryTime);
            this.panelRunTop.Controls.Add(this.numericUpDownReTryInterval);
            this.panelRunTop.Controls.Add(this.labelReTryInterval);
            this.panelRunTop.Controls.Add(this.comboBoxTaskTimeType);
            this.panelRunTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelRunTop.Location = new System.Drawing.Point(3, 17);
            this.panelRunTop.Name = "panelRunTop";
            this.panelRunTop.Size = new System.Drawing.Size(838, 23);
            this.panelRunTop.TabIndex = 4;
            // 
            // labelTaskTimeType
            // 
            this.labelTaskTimeType.AutoSize = true;
            this.labelTaskTimeType.Location = new System.Drawing.Point(43, 7);
            this.labelTaskTimeType.Name = "labelTaskTimeType";
            this.labelTaskTimeType.Size = new System.Drawing.Size(59, 12);
            this.labelTaskTimeType.TabIndex = 1;
            this.labelTaskTimeType.Text = "执行方式:";
            // 
            // numericUpDownReTryTime
            // 
            this.numericUpDownReTryTime.Location = new System.Drawing.Point(361, 1);
            this.numericUpDownReTryTime.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownReTryTime.Name = "numericUpDownReTryTime";
            this.numericUpDownReTryTime.Size = new System.Drawing.Size(69, 21);
            this.numericUpDownReTryTime.TabIndex = 3;
            this.numericUpDownReTryTime.Visible = false;
            // 
            // labelReTryTime
            // 
            this.labelReTryTime.AutoSize = true;
            this.labelReTryTime.Location = new System.Drawing.Point(296, 7);
            this.labelReTryTime.Name = "labelReTryTime";
            this.labelReTryTime.Size = new System.Drawing.Size(59, 12);
            this.labelReTryTime.TabIndex = 1;
            this.labelReTryTime.Text = "重试次数:";
            this.labelReTryTime.Visible = false;
            // 
            // numericUpDownReTryInterval
            // 
            this.numericUpDownReTryInterval.Location = new System.Drawing.Point(573, 2);
            this.numericUpDownReTryInterval.Maximum = new decimal(new int[] {
            525600,
            0,
            0,
            0});
            this.numericUpDownReTryInterval.Name = "numericUpDownReTryInterval";
            this.numericUpDownReTryInterval.Size = new System.Drawing.Size(69, 21);
            this.numericUpDownReTryInterval.TabIndex = 4;
            this.numericUpDownReTryInterval.Visible = false;
            // 
            // labelReTryInterval
            // 
            this.labelReTryInterval.AutoSize = true;
            this.labelReTryInterval.Location = new System.Drawing.Point(470, 7);
            this.labelReTryInterval.Name = "labelReTryInterval";
            this.labelReTryInterval.Size = new System.Drawing.Size(101, 12);
            this.labelReTryInterval.TabIndex = 1;
            this.labelReTryInterval.Text = "重试间隔(分钟)：";
            this.labelReTryInterval.Visible = false;
            // 
            // comboBoxTaskTimeType
            // 
            this.comboBoxTaskTimeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTaskTimeType.FormattingEnabled = true;
            this.comboBoxTaskTimeType.Items.AddRange(new object[] {
            "Manual",
            "Timer"});
            this.comboBoxTaskTimeType.Location = new System.Drawing.Point(105, 2);
            this.comboBoxTaskTimeType.Name = "comboBoxTaskTimeType";
            this.comboBoxTaskTimeType.Size = new System.Drawing.Size(163, 20);
            this.comboBoxTaskTimeType.TabIndex = 2;
            // 
            // groupBoxBase
            // 
            this.groupBoxBase.Controls.Add(this.textBoxDescription);
            this.groupBoxBase.Controls.Add(this.labelDescription);
            this.groupBoxBase.Controls.Add(this.textBoxName);
            this.groupBoxBase.Controls.Add(this.labelName);
            this.groupBoxBase.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxBase.Location = new System.Drawing.Point(0, 0);
            this.groupBoxBase.Name = "groupBoxBase";
            this.groupBoxBase.Size = new System.Drawing.Size(844, 42);
            this.groupBoxBase.TabIndex = 3;
            this.groupBoxBase.TabStop = false;
            this.groupBoxBase.Text = "基本信息";
            // 
            // textBoxDescription
            // 
            this.textBoxDescription.Location = new System.Drawing.Point(364, 15);
            this.textBoxDescription.Name = "textBoxDescription";
            this.textBoxDescription.Size = new System.Drawing.Size(458, 21);
            this.textBoxDescription.TabIndex = 1;
            // 
            // labelDescription
            // 
            this.labelDescription.AutoSize = true;
            this.labelDescription.Location = new System.Drawing.Point(323, 18);
            this.labelDescription.Name = "labelDescription";
            this.labelDescription.Size = new System.Drawing.Size(35, 12);
            this.labelDescription.TabIndex = 1;
            this.labelDescription.Text = "描述:";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(108, 18);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(163, 21);
            this.textBoxName.TabIndex = 0;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(70, 21);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(35, 12);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "名称:";
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.buttonShowWebPage);
            this.panelBottom.Controls.Add(this.buttonCancel);
            this.panelBottom.Controls.Add(this.buttonOK);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBottom.Location = new System.Drawing.Point(3, 514);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(844, 32);
            this.panelBottom.TabIndex = 1;
            // 
            // buttonShowWebPage
            // 
            this.buttonShowWebPage.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonShowWebPage.Location = new System.Drawing.Point(3, 3);
            this.buttonShowWebPage.Name = "buttonShowWebPage";
            this.buttonShowWebPage.Size = new System.Drawing.Size(88, 23);
            this.buttonShowWebPage.TabIndex = 13;
            this.buttonShowWebPage.Text = "显示网页(&S)";
            this.buttonShowWebPage.UseVisualStyleBackColor = true;
            this.buttonShowWebPage.Click += new System.EventHandler(this.buttonShowWebPage_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(657, 3);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 13;
            this.buttonCancel.Text = "取消(&C)";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(747, 3);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(75, 23);
            this.buttonOK.TabIndex = 12;
            this.buttonOK.Text = "确定(&O)";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // FormEditProject
            // 
            this.AcceptButton = this.buttonOK;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(850, 572);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormEditProject";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "请录入项目信息";
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.groupBoxExternal.ResumeLayout(false);
            this.groupBoxExternal.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBoxDetailPage.ResumeLayout(false);
            this.groupBoxDetailPage.PerformLayout();
            this.panelDetailBottom.ResumeLayout(false);
            this.panelDetailBottom.PerformLayout();
            this.panelDetailTop.ResumeLayout(false);
            this.panelDetailTop.PerformLayout();
            this.groupBoxListPage.ResumeLayout(false);
            this.groupBoxListPage.PerformLayout();
            this.panelListPageBottom.ResumeLayout(false);
            this.panelListPageBottom.PerformLayout();
            this.panelListPageTop.ResumeLayout(false);
            this.panelListPageTop.PerformLayout();
            this.groupBoxLogin.ResumeLayout(false);
            this.groupBoxLogin.PerformLayout();
            this.panelLoginBottom.ResumeLayout(false);
            this.panelLoginBottom.PerformLayout();
            this.panelLoginTop.ResumeLayout(false);
            this.panelLoginTop.PerformLayout();
            this.groupBoxRun.ResumeLayout(false);
            this.groupBoxRun.PerformLayout();
            this.panelTaskTime.ResumeLayout(false);
            this.panelTaskTime.PerformLayout();
            this.panelRunTop.ResumeLayout(false);
            this.panelRunTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownReTryTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownReTryInterval)).EndInit();
            this.groupBoxBase.ResumeLayout(false);
            this.groupBoxBase.PerformLayout();
            this.panelBottom.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Label labelTaskTimeType;
        private System.Windows.Forms.ComboBox comboBoxTaskTimeType;
        private System.Windows.Forms.GroupBox groupBoxRun;
        private System.Windows.Forms.GroupBox groupBoxBase;
        private System.Windows.Forms.NumericUpDown numericUpDownReTryInterval;
        private System.Windows.Forms.Label labelReTryInterval;
        private System.Windows.Forms.NumericUpDown numericUpDownReTryTime;
        private System.Windows.Forms.Label labelReTryTime;
        private System.Windows.Forms.Panel panelRunTop;
        private System.Windows.Forms.Panel panelTaskTime;
        private System.Windows.Forms.GroupBox groupBoxLogin;
        private System.Windows.Forms.TextBox textBoxLoginPageInfo;
        private System.Windows.Forms.Label labelLoginType;
        private System.Windows.Forms.ComboBox comboBoxLoginType;
        private System.Windows.Forms.Panel panelLoginBottom;
        private System.Windows.Forms.Panel panelLoginTop;
        private System.Windows.Forms.GroupBox groupBoxListPage;
        private System.Windows.Forms.Panel panelListPageBottom;
        private System.Windows.Forms.Panel panelListPageTop;
        private System.Windows.Forms.ComboBox comboBoxListNavigateType;
        private System.Windows.Forms.Label labelListNavigateType;
        private System.Windows.Forms.TextBox textBoxTaskTime;
        private System.Windows.Forms.Label labelTaskTime;
        private System.Windows.Forms.Label labelListPageInfo;
        private System.Windows.Forms.TextBox textBoxListPageInfo;
        private System.Windows.Forms.GroupBox groupBoxDetailPage;
        private System.Windows.Forms.Panel panelDetailBottom;
        private System.Windows.Forms.Label labelDetailGrabInfo;
        private System.Windows.Forms.TextBox textBoxDetailGrabInfo;
        private System.Windows.Forms.Panel panelDetailTop;
        private System.Windows.Forms.ComboBox comboBoxDetailGrabType;
        private System.Windows.Forms.Label labelDetailGrabType;
        private System.Windows.Forms.Label labelLoginPageInfo;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.GroupBox groupBoxExternal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelProgramAfterGrabAll;
        private System.Windows.Forms.TextBox textBoxProgramAfterGrabAll;
        private System.Windows.Forms.Button buttonShowWebPage;
    }
}