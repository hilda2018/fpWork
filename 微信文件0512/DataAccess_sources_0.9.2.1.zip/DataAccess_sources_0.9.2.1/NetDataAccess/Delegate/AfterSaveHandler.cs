﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Delegate
{
    /// <summary>
    /// 保存后
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void AfterSaveHandler(object sender, System.EventArgs e);
}
