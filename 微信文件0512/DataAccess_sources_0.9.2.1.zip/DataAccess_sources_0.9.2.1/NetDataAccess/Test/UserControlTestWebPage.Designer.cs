﻿namespace NetDataAccess.Test
{
    partial class UserControlTestWebPage
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.labelFoundElements = new System.Windows.Forms.Label();
            this.textBoxFoundHtml = new System.Windows.Forms.TextBox();
            this.splitContainerFoundElements = new System.Windows.Forms.SplitContainer();
            this.textBoxFoundText = new System.Windows.Forms.TextBox();
            this.buttonShowPage = new System.Windows.Forms.Button();
            this.textBoxPageUrl = new System.Windows.Forms.TextBox();
            this.labelWebPageUrl = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.buttonMultiFocus = new System.Windows.Forms.Button();
            this.buttonFocus = new System.Windows.Forms.Button();
            this.textBoxElementPath = new System.Windows.Forms.TextBox();
            this.labelElementPath = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabPageFoundLog = new System.Windows.Forms.TabPage();
            this.panelFoundElementsTop = new System.Windows.Forms.Panel();
            this.panelMain = new System.Windows.Forms.Panel();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageWebBrowser = new System.Windows.Forms.TabPage();
            this.webBrowserMain = new System.Windows.Forms.WebBrowser();
            this.tabPageXPathDescription = new System.Windows.Forms.TabPage();
            this.textBoxXPathDescription = new System.Windows.Forms.TextBox();
            this.checkBoxIsAlert = new System.Windows.Forms.CheckBox();
            this.splitContainerFoundElements.Panel1.SuspendLayout();
            this.splitContainerFoundElements.Panel2.SuspendLayout();
            this.splitContainerFoundElements.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabPageFoundLog.SuspendLayout();
            this.panelFoundElementsTop.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageWebBrowser.SuspendLayout();
            this.tabPageXPathDescription.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelFoundElements
            // 
            this.labelFoundElements.AutoSize = true;
            this.labelFoundElements.Location = new System.Drawing.Point(4, 4);
            this.labelFoundElements.Name = "labelFoundElements";
            this.labelFoundElements.Size = new System.Drawing.Size(0, 12);
            this.labelFoundElements.TabIndex = 0;
            // 
            // textBoxFoundHtml
            // 
            this.textBoxFoundHtml.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFoundHtml.Font = new System.Drawing.Font("宋体", 9F);
            this.textBoxFoundHtml.Location = new System.Drawing.Point(0, 0);
            this.textBoxFoundHtml.MaxLength = 3276700;
            this.textBoxFoundHtml.Multiline = true;
            this.textBoxFoundHtml.Name = "textBoxFoundHtml";
            this.textBoxFoundHtml.ReadOnly = true;
            this.textBoxFoundHtml.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxFoundHtml.Size = new System.Drawing.Size(478, 440);
            this.textBoxFoundHtml.TabIndex = 1;
            // 
            // splitContainerFoundElements
            // 
            this.splitContainerFoundElements.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerFoundElements.Location = new System.Drawing.Point(3, 24);
            this.splitContainerFoundElements.Name = "splitContainerFoundElements";
            // 
            // splitContainerFoundElements.Panel1
            // 
            this.splitContainerFoundElements.Panel1.Controls.Add(this.textBoxFoundText);
            // 
            // splitContainerFoundElements.Panel2
            // 
            this.splitContainerFoundElements.Panel2.Controls.Add(this.textBoxFoundHtml);
            this.splitContainerFoundElements.Size = new System.Drawing.Size(941, 440);
            this.splitContainerFoundElements.SplitterDistance = 459;
            this.splitContainerFoundElements.TabIndex = 1;
            // 
            // textBoxFoundText
            // 
            this.textBoxFoundText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFoundText.Font = new System.Drawing.Font("宋体", 9F);
            this.textBoxFoundText.Location = new System.Drawing.Point(0, 0);
            this.textBoxFoundText.MaxLength = 3276700;
            this.textBoxFoundText.Multiline = true;
            this.textBoxFoundText.Name = "textBoxFoundText";
            this.textBoxFoundText.ReadOnly = true;
            this.textBoxFoundText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxFoundText.Size = new System.Drawing.Size(459, 440);
            this.textBoxFoundText.TabIndex = 0;
            // 
            // buttonShowPage
            // 
            this.buttonShowPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonShowPage.Location = new System.Drawing.Point(751, 4);
            this.buttonShowPage.Name = "buttonShowPage";
            this.buttonShowPage.Size = new System.Drawing.Size(75, 23);
            this.buttonShowPage.TabIndex = 2;
            this.buttonShowPage.Text = "转到";
            this.buttonShowPage.UseVisualStyleBackColor = true;
            this.buttonShowPage.Click += new System.EventHandler(this.buttonShowPage_Click);
            // 
            // textBoxPageUrl
            // 
            this.textBoxPageUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPageUrl.Location = new System.Drawing.Point(40, 4);
            this.textBoxPageUrl.Name = "textBoxPageUrl";
            this.textBoxPageUrl.Size = new System.Drawing.Size(705, 21);
            this.textBoxPageUrl.TabIndex = 1;
            this.textBoxPageUrl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxPageUrl_KeyDown);
            // 
            // labelWebPageUrl
            // 
            this.labelWebPageUrl.AutoSize = true;
            this.labelWebPageUrl.Location = new System.Drawing.Point(4, 8);
            this.labelWebPageUrl.Name = "labelWebPageUrl";
            this.labelWebPageUrl.Size = new System.Drawing.Size(35, 12);
            this.labelWebPageUrl.TabIndex = 0;
            this.labelWebPageUrl.Text = "地址:";
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.checkBoxIsAlert);
            this.panelTop.Controls.Add(this.buttonShowPage);
            this.panelTop.Controls.Add(this.textBoxPageUrl);
            this.panelTop.Controls.Add(this.labelWebPageUrl);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(955, 29);
            this.panelTop.TabIndex = 5;
            // 
            // buttonMultiFocus
            // 
            this.buttonMultiFocus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMultiFocus.Location = new System.Drawing.Point(751, 6);
            this.buttonMultiFocus.Name = "buttonMultiFocus";
            this.buttonMultiFocus.Size = new System.Drawing.Size(72, 23);
            this.buttonMultiFocus.TabIndex = 18;
            this.buttonMultiFocus.Text = "批量定位";
            this.buttonMultiFocus.UseVisualStyleBackColor = true;
            this.buttonMultiFocus.Click += new System.EventHandler(this.buttonMultiFocus_Click);
            // 
            // buttonFocus
            // 
            this.buttonFocus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonFocus.Location = new System.Drawing.Point(673, 6);
            this.buttonFocus.Name = "buttonFocus";
            this.buttonFocus.Size = new System.Drawing.Size(72, 23);
            this.buttonFocus.TabIndex = 17;
            this.buttonFocus.Text = "定位";
            this.buttonFocus.UseVisualStyleBackColor = true;
            this.buttonFocus.Click += new System.EventHandler(this.buttonFocus_Click);
            // 
            // textBoxElementPath
            // 
            this.textBoxElementPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxElementPath.HideSelection = false;
            this.textBoxElementPath.Location = new System.Drawing.Point(75, 6);
            this.textBoxElementPath.Name = "textBoxElementPath";
            this.textBoxElementPath.Size = new System.Drawing.Size(592, 21);
            this.textBoxElementPath.TabIndex = 16;
            // 
            // labelElementPath
            // 
            this.labelElementPath.AutoSize = true;
            this.labelElementPath.Location = new System.Drawing.Point(4, 10);
            this.labelElementPath.Name = "labelElementPath";
            this.labelElementPath.Size = new System.Drawing.Size(65, 12);
            this.labelElementPath.TabIndex = 15;
            this.labelElementPath.Text = "xPath路径:";
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.buttonMultiFocus);
            this.panelBottom.Controls.Add(this.buttonFocus);
            this.panelBottom.Controls.Add(this.textBoxElementPath);
            this.panelBottom.Controls.Add(this.labelElementPath);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 522);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(955, 35);
            this.panelBottom.TabIndex = 4;
            // 
            // tabPageFoundLog
            // 
            this.tabPageFoundLog.Controls.Add(this.splitContainerFoundElements);
            this.tabPageFoundLog.Controls.Add(this.panelFoundElementsTop);
            this.tabPageFoundLog.Location = new System.Drawing.Point(4, 22);
            this.tabPageFoundLog.Name = "tabPageFoundLog";
            this.tabPageFoundLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFoundLog.Size = new System.Drawing.Size(947, 467);
            this.tabPageFoundLog.TabIndex = 1;
            this.tabPageFoundLog.Text = "定位结果";
            this.tabPageFoundLog.UseVisualStyleBackColor = true;
            // 
            // panelFoundElementsTop
            // 
            this.panelFoundElementsTop.Controls.Add(this.labelFoundElements);
            this.panelFoundElementsTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFoundElementsTop.Location = new System.Drawing.Point(3, 3);
            this.panelFoundElementsTop.Name = "panelFoundElementsTop";
            this.panelFoundElementsTop.Size = new System.Drawing.Size(941, 21);
            this.panelFoundElementsTop.TabIndex = 2;
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.tabControlMain);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 29);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(955, 493);
            this.panelMain.TabIndex = 3;
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageWebBrowser);
            this.tabControlMain.Controls.Add(this.tabPageFoundLog);
            this.tabControlMain.Controls.Add(this.tabPageXPathDescription);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(955, 493);
            this.tabControlMain.TabIndex = 1;
            // 
            // tabPageWebBrowser
            // 
            this.tabPageWebBrowser.Controls.Add(this.webBrowserMain);
            this.tabPageWebBrowser.Location = new System.Drawing.Point(4, 22);
            this.tabPageWebBrowser.Name = "tabPageWebBrowser";
            this.tabPageWebBrowser.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWebBrowser.Size = new System.Drawing.Size(947, 467);
            this.tabPageWebBrowser.TabIndex = 0;
            this.tabPageWebBrowser.Text = "浏览器";
            this.tabPageWebBrowser.UseVisualStyleBackColor = true;
            // 
            // webBrowserMain
            // 
            this.webBrowserMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserMain.Location = new System.Drawing.Point(3, 3);
            this.webBrowserMain.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserMain.Name = "webBrowserMain";
            this.webBrowserMain.ScriptErrorsSuppressed = true;
            this.webBrowserMain.Size = new System.Drawing.Size(941, 461);
            this.webBrowserMain.TabIndex = 0;
            // 
            // tabPageXPathDescription
            // 
            this.tabPageXPathDescription.Controls.Add(this.textBoxXPathDescription);
            this.tabPageXPathDescription.Location = new System.Drawing.Point(4, 22);
            this.tabPageXPathDescription.Name = "tabPageXPathDescription";
            this.tabPageXPathDescription.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageXPathDescription.Size = new System.Drawing.Size(947, 467);
            this.tabPageXPathDescription.TabIndex = 2;
            this.tabPageXPathDescription.Text = "XPath详细说明";
            this.tabPageXPathDescription.UseVisualStyleBackColor = true;
            // 
            // textBoxXPathDescription
            // 
            this.textBoxXPathDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxXPathDescription.Location = new System.Drawing.Point(3, 3);
            this.textBoxXPathDescription.Multiline = true;
            this.textBoxXPathDescription.Name = "textBoxXPathDescription";
            this.textBoxXPathDescription.Size = new System.Drawing.Size(941, 461);
            this.textBoxXPathDescription.TabIndex = 0;
            // 
            // checkBoxIsAlert
            // 
            this.checkBoxIsAlert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxIsAlert.AutoSize = true;
            this.checkBoxIsAlert.Location = new System.Drawing.Point(833, 7);
            this.checkBoxIsAlert.Name = "checkBoxIsAlert";
            this.checkBoxIsAlert.Size = new System.Drawing.Size(72, 16);
            this.checkBoxIsAlert.TabIndex = 3;
            this.checkBoxIsAlert.Text = "点击提示";
            this.checkBoxIsAlert.UseVisualStyleBackColor = true;
            // 
            // UserControlWebPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelBottom);
            this.Name = "UserControlWebPage";
            this.Size = new System.Drawing.Size(955, 557);
            this.splitContainerFoundElements.Panel1.ResumeLayout(false);
            this.splitContainerFoundElements.Panel1.PerformLayout();
            this.splitContainerFoundElements.Panel2.ResumeLayout(false);
            this.splitContainerFoundElements.Panel2.PerformLayout();
            this.splitContainerFoundElements.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelBottom.ResumeLayout(false);
            this.panelBottom.PerformLayout();
            this.tabPageFoundLog.ResumeLayout(false);
            this.panelFoundElementsTop.ResumeLayout(false);
            this.panelFoundElementsTop.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.tabControlMain.ResumeLayout(false);
            this.tabPageWebBrowser.ResumeLayout(false);
            this.tabPageXPathDescription.ResumeLayout(false);
            this.tabPageXPathDescription.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelFoundElements;
        private System.Windows.Forms.TextBox textBoxFoundHtml;
        private System.Windows.Forms.SplitContainer splitContainerFoundElements;
        private System.Windows.Forms.TextBox textBoxFoundText;
        private System.Windows.Forms.Button buttonShowPage;
        private System.Windows.Forms.TextBox textBoxPageUrl;
        private System.Windows.Forms.Label labelWebPageUrl;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Button buttonMultiFocus;
        private System.Windows.Forms.Button buttonFocus;
        private System.Windows.Forms.TextBox textBoxElementPath;
        private System.Windows.Forms.Label labelElementPath;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.TabPage tabPageFoundLog;
        private System.Windows.Forms.Panel panelFoundElementsTop;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageWebBrowser;
        private System.Windows.Forms.TabPage tabPageXPathDescription;
        private System.Windows.Forms.TextBox textBoxXPathDescription;
        private System.Windows.Forms.WebBrowser webBrowserMain;
        private System.Windows.Forms.CheckBox checkBoxIsAlert;
    }
}
