﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using NetDataAccess.Base.Common;
using HtmlAgilityPack;

namespace NetDataAccess.Test
{
    /// <summary>
    /// 测试一个网页
    /// </summary>
    public partial class UserControlTestWebPage : UserControl
    { 
        #region 构造函数
        public UserControlTestWebPage()
        {
            InitializeComponent(); 
            this.Load += new EventHandler(FormWebPage_Load);
            this.webBrowserMain.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowserMain_DocumentCompleted);
            
            /*
            问题：
                动态js加载的数据，如何获取，例如价格数据；京东滚动窗口时才冬天加载部分列表页数据；
             */
        }
        #endregion

        #region HtmlAgilityPack HtmlDocument
        private HtmlAgilityPack.HtmlDocument HtmlDoc
        {
            get;
            set;
        }
        #endregion
         
        #region 网页加载完成
        void webBrowserMain_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            this.webBrowserMain.Document.Click -= new HtmlElementEventHandler(Document_Click);
            this.webBrowserMain.Document.Click += new HtmlElementEventHandler(Document_Click);
            if (this.webBrowserMain.ReadyState == WebBrowserReadyState.Complete && !this.webBrowserMain.IsBusy)
            {
                //this.webBrowserMain.Document.Window.ScrollTo(10000, 10000);
                //网页加载完成 
            }
        } 

        private void Document_Click(object sender, HtmlElementEventArgs e)
        {
            if (this.checkBoxIsAlert.Checked)
            {
                e.ReturnValue = false;
                e.BubbleEvent = false;
                Point p = e.ClientMousePosition;

                //找到所点击的元素
                HtmlElement htmlElement = this.webBrowserMain.Document.GetElementFromPoint(p);

                CommonUtil.Alert("", htmlElement.OuterHtml);

                //给出建议Xpath
                this.textBoxElementPath.Text = GetPathInfo(htmlElement);

                //路径中所有的元素信息
                StringBuilder pathInfosStr = new StringBuilder();
                List<string> pathElementInfos = GetPathElementInfo(htmlElement);
                for (int i = pathElementInfos.Count - 1; i >= 0; i--)
                {
                    string pathInfo = pathElementInfos[i];
                    pathInfosStr.AppendLine(pathInfo);
                }

                this.textBoxXPathDescription.Text = pathInfosStr.ToString();

                HtmlDoc = new HtmlAgilityPack.HtmlDocument();
                HtmlDoc.LoadHtml(this.webBrowserMain.Document.Body.OuterHtml);
            }
        }
        #endregion

        #region 获取当前节点及其父节点信息
        private string GetPathInfo(HtmlElement htmlElement)
        {
            string pathStr = "";
            HtmlElement bodyElement = htmlElement.Document.Body;
            HtmlElement tempElement = htmlElement;
            bool hasGetPath = false;
            while (!hasGetPath)
            {
                if (tempElement == bodyElement)
                {
                    pathStr = "//body" + pathStr;
                    hasGetPath = true;
                }
                else if (tempElement.Id != null)
                {
                    pathStr = "//*[@id=\"" + tempElement.Id + "\"]" + pathStr;
                    hasGetPath = true;
                }
                else
                {
                    string tagName = tempElement.TagName.ToLower();
                    HtmlElement parentElement = tempElement.Parent;
                    HtmlElementCollection allChildren = parentElement.Children;
                    HtmlElement checkElement = allChildren[0];
                    int sameTagIndex = 1;
                    int index = 0;
                    while (checkElement != tempElement)
                    {
                        if (checkElement.TagName.ToLower() == tagName)
                        {
                            sameTagIndex++;
                        }
                        index++;
                        checkElement = allChildren[index];
                    }
                    pathStr = "/" + tagName + "[" + sameTagIndex + "]" + pathStr;
                    tempElement = parentElement;
                }
            }

            return pathStr;
        }
        #endregion

        #region 获取路径中所有元素情况
        private List<string> GetPathElementInfo(HtmlElement htmlElement)
        {
            List<string> pathElementInfos = new List<string>(); 
            HtmlElement bodyElement = htmlElement.Document.Body;
            HtmlElement tempElement = htmlElement;
            bool hasCheckBody = false;
            while (!hasCheckBody)
            {
                if (tempElement == bodyElement)
                {
                    pathElementInfos.Add("body");
                    hasCheckBody = true;
                } 
                else
                {
                    string tagName = tempElement.TagName.ToLower();

                    string pathInfo = tagName + ", Id=" + tempElement.Id + ", ";

                    HtmlElement parentElement = tempElement.Parent;
                    HtmlElementCollection allChildren = parentElement.Children;
                    HtmlElement checkElement = allChildren[0];
                    //正序
                    int sameTagIndex = 1;
                    int index = 0;
                    while ( checkElement != tempElement)
                    {
                        if ( checkElement.TagName.ToLower() == tagName)
                        {
                            sameTagIndex++;
                        }
                        index++;
                        checkElement = allChildren[index];
                    }

                    //倒序
                    int lastIndex = 0;
                    while (index < allChildren.Count)
                    {
                        checkElement = allChildren[index];
                        if ( checkElement.TagName.ToLower() == tagName)
                        {
                            lastIndex++;
                        }
                        index++;
                    } 
                    pathInfo += ("Index=" + sameTagIndex + ", " + "LastIndex=" + lastIndex);

                    tempElement = parentElement;
                    pathElementInfos.Add(pathInfo);
                }
            }

            return pathElementInfos;
        }
        #endregion

        #region Load时
        private void FormWebPage_Load(object sender, EventArgs e)
        { 

        }
        #endregion  

        #region 转到按钮
        private void buttonShowPage_Click(object sender, EventArgs e)
        {
            ShowWebPage();
        }
        #endregion

        #region 显示网页
        private void ShowWebPage()
        {
            this.webBrowserMain.Navigate(this.textBoxPageUrl.Text);
           // this.webBrowserMain.Url = new Uri(this.textBoxPageUrl.Text);
        }
        #endregion

        #region 网址输入框按键按下
        private void textBoxPageUrl_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    ShowWebPage();
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region 定位按钮
        private void buttonFocus_Click(object sender, EventArgs e)
        {
            try
            {
                HtmlDoc = new HtmlAgilityPack.HtmlDocument();
                HtmlDoc.LoadHtml(this.webBrowserMain.Document.Body.OuterHtml);
                HtmlNode node = HtmlDoc.DocumentNode.SelectSingleNode(this.textBoxElementPath.Text);
                if(node==null)
                {
                    ShowFoundElementInfo(0,"","","");
                }
                else
                {
                    ShowFoundElementInfo(1, "", node.InnerText, node.OuterHtml);
                }
            }
            catch (Exception ex)
            {
                ShowFoundElementInfo(0, "错误:" + ex.Message, "", "");
            }
        }
        #endregion

        #region 显示定位结果
        private void ShowFoundElementInfo(int count, string msg, string text, string html)
        {
            this.tabControlMain.SelectedTab = this.tabPageFoundLog;
            labelFoundElements.Text = "找到" + count.ToString() + "个元素. " + msg;
            textBoxFoundHtml.Text = html;
            textBoxFoundText.Text = text;
        }
        #endregion

        #region 批量定位按钮
        private void buttonMultiFocus_Click(object sender, EventArgs e)
        {
            try
            {
                HtmlDoc = new HtmlAgilityPack.HtmlDocument();
                HtmlDoc.LoadHtml(this.webBrowserMain.Document.Body.OuterHtml);
                HtmlNodeCollection nodes = HtmlDoc.DocumentNode.SelectNodes(this.textBoxElementPath.Text);
                StringBuilder text = new StringBuilder();
                StringBuilder html = new StringBuilder();
                if (nodes != null)
                {
                    foreach (HtmlNode node in nodes)
                    {
                        text.AppendLine(node.InnerText);
                        html.AppendLine(node.OuterHtml);
                    }
                    ShowFoundElementInfo(nodes.Count, "", text.ToString(), html.ToString());
                }
                else
                {
                    ShowFoundElementInfo(0, "", "", "");
                }
            }
            catch (Exception ex)
            {
                CommonUtil.Alert("错误", ex.Message);
            }
        }
        #endregion 
    }
}
