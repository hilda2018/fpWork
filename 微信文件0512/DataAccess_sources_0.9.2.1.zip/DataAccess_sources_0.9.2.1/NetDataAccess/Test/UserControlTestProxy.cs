﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using NetDataAccess.Base.Proxy;
using System.Net;
using NetDataAccess.Base.Web;
using System.IO;
using NetDataAccess.Base.Common;
using System.Threading;

namespace NetDataAccess.Test
{
    /// <summary>
    /// 测试代理
    /// </summary>
    public partial class UserControlTestProxy : UserControl
    {
        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        public UserControlTestProxy()
        {
            InitializeComponent();
        }
        #endregion

        #region 记录是否正在运行
        private bool _Running = true;
        #endregion

        #region 点击测试按钮
        /// <summary>
        /// 点击测试按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonTest_Click(object sender, EventArgs e)
        {
            string url = this.textBoxTestUrl.Text.Trim();
            int timeout = (int)this.numericUpDownTimeout.Value;
            this.textBoxResult.Clear();

            ParameterizedThreadStart ts = new ParameterizedThreadStart(Test);
            Thread thread = new Thread(ts);
            thread.Start(new object[] { url, timeout });
        }
        #endregion

        #region 记录结果
        private int _AllCount = 0;
        private int _SucceedCount = 0;
        private int _ErrorCount = 0;
        #endregion

        #region 测试
        /// <summary>
        /// 测试
        /// </summary>
        /// <param name="parameters"></param>
        private void Test(object parameters)
        {
            string url = (string)((object[])parameters)[0];
            int timeout = (int)((object[])parameters)[1];
            List<ProxyServer> servers = ProxyServers.AllProxies;
            _ErrorCount = 0;
            _SucceedCount = 0;
            _AllCount = servers.Count;
            this.InvokeAppendLogText("开始测试.");

            foreach (ProxyServer ps in servers)
            {
                if (this._Running)
                {
                    TestOne(url, timeout, ps);
                    Thread.Sleep(200);
                }
            }
        }
        #endregion

        #region 输出测试日志到界面
        private delegate void TestInvokeDelegate(string msg);
        private void InvokeAppendLogText(string msg)
        {
            if (this._Running)
            {
                this.Invoke(new TestInvokeDelegate(this.AppendLogText), DateTime.Now.ToString("(yyyy-MM-dd HH:mm:ss) ") + msg);
            }
        }
        private void AppendLogText(string msg)
        {
            if (this._Running)
            {
                this.textBoxResult.AppendText(msg + "\r\n");
            }
        }
        #endregion

        #region 关闭测试
        public void Close()
        {
            this._Running = false;
        }
        #endregion

        #region 测试一个代理
        private void TestOne(string url, int timeout, ProxyServer ps)
        {
            try
            {
                NDAWebClient client = new NDAWebClient();
                client.ProxyServer = ps;
                client.Timeout = timeout * 1000;
                Uri uri = new Uri(url);
                client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                client.OpenReadCompleted += client_OpenReadCompleted;
                client.OpenReadAsync(uri);
            }
            catch (Exception ex)
            {
                string errorInfo = "访问失败, 代理地址: " + ps.Address + ". " + ex.Message;
                //this.InvokeAppendLogText(errorInfo, LogLevelType.Error, true);
                InvokeAppendLogText(errorInfo);
            }
        }
        #endregion

        #region 刷新状态
        private void RefreshStatus(bool succeed)
        {
            if (succeed)
            {
                _SucceedCount++;
            }
            else
            {
                _ErrorCount++;
            }
            string msg = "已成功" + _SucceedCount.ToString() + "个, 出错" + _ErrorCount.ToString() + "个,待测试" + (_AllCount - _SucceedCount - _ErrorCount).ToString() + "个";
            InvokeAppendLogText(msg);
        }
        #endregion

        #region 获取到数据时只需
        private void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            Stream data = null;
            StreamReader reader = null;
            NDAWebClient client = null;
            try
            {
                client = (NDAWebClient)sender;
                if (e.Error != null)
                {
                    throw e.Error;
                }
                else
                {
                    reader = new StreamReader(e.Result);
                    string s = reader.ReadToEnd();
                    if (CommonUtil.IsNullOrBlank(s))
                    {
                        throw new Exception("获取的文件为空.");
                    }
                    else
                    {
                        InvokeAppendLogText("OK! " + client.ProxyServer.Address);
                        RefreshStatus(true);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorInfo = "访问失败, 代理地址: " + client.ProxyServer.Address + ". " + ex.Message;
                //this.InvokeAppendLogText(errorInfo, LogLevelType.Error, true);
                InvokeAppendLogText(errorInfo);
                RefreshStatus(false);
            }
            finally
            {
                if (data != null)
                {
                    data.Close();
                    data.Dispose();
                }
                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }
            }
        }
        #endregion 
    }
}
