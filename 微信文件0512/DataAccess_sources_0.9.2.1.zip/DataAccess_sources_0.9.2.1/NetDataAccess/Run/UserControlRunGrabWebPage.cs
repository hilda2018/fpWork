﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using NetDataAccess.Base.Common;
using HtmlAgilityPack;
using NetDataAccess.Base.Definition;
using System.Xml;
using System.Threading;
using NetDataAccess.Base.EnumTypes;
using NetDataAccess.Base.Config;
using System.IO;
using System.Web;
using System.Reflection;
using NetDataAccess.Base.UI;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System.Net;
using Newtonsoft.Json.Linq;
using NetDataAccess.Base.Proxy;
using NetDataAccess.Base.Web;
using System.Collections;
using ICSharpCode.SharpZipLib.Zip;
using NetDataAccess.Export;
using NetDataAccess.DB;
using NetDataAccess.Base.Reader;
using NetDataAccess.Base.DB;
using Microsoft.VisualBasic.Devices;
using mshtml;
using NetDataAccess.Config;
using log4net;
using log4net.Config;
using log4net.Repository;
using NetDataAccess.Main;
using NetDataAccess.Base.DLL;
using NetDataAccess.Base.Log; 

namespace NetDataAccess.Run
{
    /// <summary>
    /// 运行一个爬取任务
    /// </summary>
    public partial class UserControlRunGrabWebPage : UserControl, IRunWebPage
    {

        #region 日志
        private RunTaskLog _TaskLog = null;
        public RunTaskLog TaskLog
        {
            get
            {
                return _TaskLog;
            }
        }
        #endregion

        #region 本次运行的任务Id
        private string _TaskId = "_";
        public string TaskId
        {
            get
            {
                return _TaskId;
            }
        }
        #endregion

        #region 本次运行的参数
        private string _Parameter = "";
        public string Parameter
        {
            get
            {
                return _Parameter;
            }
        }
        #endregion

        #region 文件路径
        public string FileDir
        {
            get
            {
                return TaskManager.FileDir;
            }
        }
        #endregion

        #region 输入文件路径
        public string InputFileDir
        {
            get
            {
                return Path.Combine(TaskManager.InputFileDir, TaskId);
            }
        }
        #endregion

        #region 输出文件路径
        public string OutputFileDir
        {
            get
            {
                return Path.Combine(TaskManager.OutputFileDir, TaskId);
            }
        }
        #endregion

        #region 运行的任务文件路径
        public string TaskFileDir
        {
            get
            {
                return Path.Combine(TaskManager.TaskFileDir,  TaskId);
            }
        }
        #endregion

        #region 构造函数
        public UserControlRunGrabWebPage(Proj_Main project)
        {
            InitializeComponent();
            Create(project, false, "", "_");
        }
        #endregion

        #region 构造函数
        public UserControlRunGrabWebPage(Proj_Main project, bool autoRun, string parameter, string taskId)
        {
            InitializeComponent();
            Create(project, autoRun, parameter, taskId);
        }
        #endregion

        #region 创建
        private void Create(Proj_Main project, bool autoRun, string parameter, string taskId)
        {
            //。。。。。。。。。。//动态制定log文件设置有问题 20151221  
            this._TaskId = taskId;
            this._Parameter = parameter;
            this._AutoRun = autoRun;

            this.Project = project;
            this.Load += new EventHandler(FormWebPage_Load);
            this.webBrowserMain.Navigating += new WebBrowserNavigatingEventHandler(webBrowserMain_Navigating);
            this.webBrowserMain.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowserMain_DocumentCompleted);
        }
        #endregion

        #region 自启动任务
        private bool _AutoRun = false;
        public bool AutoRun
        {
            get
            {
                return _AutoRun;
            }
        }
        #endregion

        #region 所有抓取detail的线程
        private List<Thread> _AllGrabDetailThreads = null;
        /// <summary>
        /// 所有抓取detail的线程
        /// </summary>
        private List<Thread> AllGrabDetailThreads
        {
            get
            {
                return _AllGrabDetailThreads; 
            }
        }
        #endregion

        #region 最近100次抓取耗时
        private object _RefreshStatusLocker = new object();
        private List<DateTime> _AllEndTimes = new List<DateTime>();
        private List<bool> _AllSucceeds = new List<bool>();
        //private Dictionary<DateTime, DateTime> _AllSpendTimes = new Dictionary<DateTime, DateTime>();
        private void AddSpendTimeAndSucceed(DateTime startTime, DateTime endTime, bool succeed)
        {
            if (succeed)
            {
                if (_AllEndTimes.Count >= SysConfig.IntervalShowStatus)
                {
                    DateTime deleteEndTime = _AllEndTimes[0];
                    _AllEndTimes.RemoveAt(0);
                    //_AllSpendTimes.Remove(deleteEndTime);
                }
                this._AllEndTimes.Add(endTime);
                //this._AllSpendTimes.Add(endTime, startTime);
            }
            if (_AllSucceeds.Count >= SysConfig.IntervalShowStatus)
            {
                _AllSucceeds.RemoveAt(0);
            }
            this._AllSucceeds.Add(succeed);
        }

        private decimal GetSucceedPercentage()
        {
            int succeedCount = 0;
            foreach (bool succeed in this._AllSucceeds)
            {
                if (succeed)
                {
                    succeedCount++;
                }
            }
            return (decimal)(succeedCount * 100) / (decimal)this._AllSucceeds.Count;
        }

        private decimal CalcAverageMinuteSucceed()
        {
            DateTime firstEndTime = DateTime.Now.AddDays(1);
            foreach (DateTime endTime in this._AllEndTimes)
            {
                if (firstEndTime > endTime)
                {
                    firstEndTime = endTime;
                }
            }

            decimal m = (decimal)(DateTime.Now - firstEndTime).TotalMinutes;

            decimal avgMCount = (this._AllEndTimes.Count / m);
            return avgMCount;
        }

        private decimal CalcRemainTime(decimal avgMCount, int remainCount)
        {
            return avgMCount == 0 ? decimal.MaxValue : remainCount / avgMCount;
        }

        public void RefreshListStatus(bool succeed, DateTime beginTime, DateTime endTime, int beginIndex, int currentIndex, int endIndex)
        {
            RefreshStatus(succeed, "列表页抓取进度: ", beginTime, endTime);
        }

        public void RefreshGrabDetailStatus(bool succeed, DateTime beginTime, DateTime endTime)
        {
            RefreshStatus(succeed, "详情页抓取进度: ", beginTime, endTime);
        }

        public void RefreshReadDetailStatus(bool succeed, DateTime beginTime, DateTime endTime)
        {
            RefreshStatus(succeed, "详情页预处理进度: ", beginTime, endTime);
        }

        public void RefreshStatus(bool succeed, string prefix, DateTime startTime, DateTime endTime)
        {
            lock (_RefreshStatusLocker)
            {
                DateTime dt1 = DateTime.Now;
                try
                {
                    this.AddSpendTimeAndSucceed(startTime, endTime, succeed);
                    if (_CompleteGrabCount % SysConfig.IntervalShowStatus == 0)
                    {
                        decimal succeedPercentage = this.GetSucceedPercentage();
                        StringBuilder sb = new StringBuilder(prefix);
                        sb.Append("已共抓取 " + _SucceedGrabCount.ToString() + " 个页面.");
                        sb.Append("最近的抓取成功率为" + succeedPercentage.ToString("0.00") + "%. ");
                        decimal avgMCount = this.CalcAverageMinuteSucceed();
                        sb.Append("平均每分钟完成 " + avgMCount.ToString("0.00") + " 个. ");
                        int remainCount = _AllNeedGrabCount - _SucceedGrabCount;
                        if (remainCount > 0)
                        {
                            long totalM = (long)CalcRemainTime(avgMCount, remainCount);
                            long remainH = 0;
                            long remainM = 0;
                            long totalH = Math.DivRem(totalM, 60, out remainM);
                            long totalD = Math.DivRem(totalH, 24, out remainH);

                            sb.Append("还需抓取 " + remainCount.ToString() + " 个页面, 预计继续运行" + totalD + "D " + remainH + "H " + remainM.ToString("0.00") + "M.");
                        }
                        this.InvokeShowStatus(sb.ToString());
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    DateTime dt2 = DateTime.Now;
                    double ts = (dt2 - dt1).TotalSeconds;
                    //this.InvokeAppendLogText("RefreshStatus: " + ts.ToString("0.0000"), LogLevelType.System, true);
                }
            }
        }
        #endregion 

        #region 获取已经抓取到的列表页序号
        private int GetSucceedListPageIndex(IListSheet sheet)
        {
            return sheet.GetSucceedListPageIndex();
        }
        #endregion
         
        #region 判断是否在抓取范围
        private bool CheckInGrabRange( int rowIndex, int startPageIndex, int endPageIndex)
        {
            int userRowIndex = rowIndex + 1;
            if (startPageIndex <= 0 && endPageIndex <= 0)
            {
                return true;
            }
            else if (startPageIndex <= 0 &&endPageIndex>0)
            {
                return userRowIndex < endPageIndex;
            }
            else if (startPageIndex > 0 && endPageIndex <= 0)
            {
                return userRowIndex > startPageIndex;
            }
            else
            {
                return startPageIndex <= userRowIndex && userRowIndex <= endPageIndex;
            }
        }
        #endregion

        #region 网页加载
        private bool _IsNavigateCompleted = false;
        public bool IsNavigateCompleted
        {
            get
            {
                return _IsNavigateCompleted;
            }
            set
            {
                _IsNavigateCompleted = value;
            }
        }

        void webBrowserMain_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            IsNavigateCompleted = false;
        }
        void webBrowserMain_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (this.webBrowserMain.ReadyState == WebBrowserReadyState.Complete && !this.webBrowserMain.IsBusy)
            {
                IsNavigateCompleted = true;
                //this.webBrowserMain.Document.Window.ScrollTo(10000, 10000);
                //网页加载完成  
            }
        }
        #endregion 
         
        #region Project
        private Proj_Main _Project;
        public Proj_Main Project
        {
            get
            {
                return _Project;
            }
            set
            {
                _Project = value;
            }
        } 
        #endregion  

        #region Load时
        private void FormWebPage_Load(object sender, EventArgs e)
        {
            this.Project.Format();
            this.AfterLoad();
            this.DoGrab();
        }
        #endregion

        #region 是否正在支持爬取
        private bool _IsGrabing = false;
        private bool IsGrabing
        {
            get 
            {
                return _IsGrabing;
            }
            set 
            {
                _IsGrabing = value;
            }
        }

        #endregion

        #region 报告放弃爬取的个数
        private void ReportGrabStatus(IListSheet listSheet)
        {
            StringBuilder s = new StringBuilder();
            int giveUpCount = 0;
            for (int i = 0; i < listSheet.RowCount; i++)
            {
                bool giveUp = listSheet.GiveUpList[i]; 
                if (giveUp)
                {
                    giveUpCount++;
                }
            }
            s.Append("放弃爬取个数: " + giveUpCount.ToString());
            this.InvokeAppendLogText(s.ToString(), LogLevelType.System, true);
        }
        #endregion
         
        #region 抓取
        private void Grab()
        {
            DateTime startTime = DateTime.Now;
            bool succeed = false;
            string errorInfo = "";
            IListSheet listSheet = null;
            try
            {
                //创建日志
                if (AutoRun)
                {
                    _TaskLog = new RunTaskLog(this.TaskId);

                }
                string excelFileName = CommonUtil.ProcessFileName(Project.Name, "_") + ".xlsx";
                string dbFileName = CommonUtil.ProcessFileName(Project.Name, "_") + ".db";
                string excelFilePath = Path.Combine(TaskFileDir, excelFileName);
                string dbFilePath = Path.Combine(TaskFileDir, dbFileName);
                string newListDBFilePath = Path.Combine(FileDir, "Config\\" + "newList.db");
                InvokeAppendLogText("正在创建任务...", LogLevelType.System, true);
                listSheet = this.CreateListSheet(excelFilePath, dbFilePath, newListDBFilePath, Project.ListNavigateType);

                this.GetDetailPageList(listSheet);

                bool hasGrabList = true;
                if (this._AllowRunGrabList)
                {
                    InvokeAppendLogText("开始抓取列表页...", LogLevelType.System, true);
                    hasGrabList = GrabListPage(listSheet, excelFilePath);
                    InvokeAppendLogText(hasGrabList ? "列表页抓取完成!" : "未能完成列表页抓取!", LogLevelType.System, true);
                    GC.Collect();
                }
                else
                {
                    InvokeAppendLogText("跳过读取列表页.", LogLevelType.System, true);
                }
                if (hasGrabList)
                {
                    bool hasGrabAll = true;
                    if (this._AllowRunGrabDetail)
                    {
                        hasGrabAll = false;
                        int beginGrabTime = 0;
                        while (!hasGrabAll)
                        {
                            if (beginGrabTime > 0)
                            {
                                InvokeAppendLogText("开始抓取详情页...(第" + beginGrabTime.ToString() + "次重新启动抓取任务)", LogLevelType.System, true);
                            }
                            else
                            {
                                InvokeAppendLogText("开始抓取详情页...", LogLevelType.System, true);
                            }
                            hasGrabAll = GrabDetailPage(listSheet);
                            InvokeAppendLogText(hasGrabAll ? "详情页抓取完成!" : "未能完成详情页抓取!", LogLevelType.System, true);
                            GC.Collect();
                            beginGrabTime++;
                        }

                        //报告爬取状态
                        this.ReportGrabStatus(listSheet);

                        InvokeAppendLogText("详情页抓取完成!", LogLevelType.System, true);
                    }
                    else
                    {
                        InvokeAppendLogText("跳过抓取详情页.", LogLevelType.System, true);
                    }

                    if (hasGrabAll)
                    {
                        bool hasReadAll = true;
                        if (this._AllowRunRead)
                        {
                            InvokeAppendLogText("开始读取详情页信息...", LogLevelType.System, true);
                            hasReadAll = ReadDetailPage(listSheet);
                            InvokeAppendLogText(hasReadAll ? "详情页读取完成!" : "未能完成详情页读取!", LogLevelType.System, true);
                            GC.Collect();
                        }
                        else
                        {
                            InvokeAppendLogText("跳过读取详情页.", LogLevelType.System, true);
                        }
                        if (hasReadAll)
                        {
                            bool hasExportAll = true;
                            if (this._AllowRunExport)
                            {
                                InvokeAppendLogText("开始写入到输出文件...", LogLevelType.System, true);
                                hasExportAll = ExportDetailPage(listSheet);
                                InvokeAppendLogText(hasReadAll ? "输出文件完成!" : "未能完成文件输出!", LogLevelType.System, true);
                                GC.Collect();
                            }

                            if (hasExportAll)
                            {
                                bool hasRunProcessAfterGrabAll = true;
                                if (this._AllowRunCustom)
                                {
                                    InvokeAppendLogText("开始执行后期处理外部程序...", LogLevelType.System, true);
                                    hasRunProcessAfterGrabAll = ProcessAfterGrabAll(listSheet);
                                    InvokeAppendLogText(hasReadAll ? "后期处理外部程序执行完成!" : "未能成功执行后期处理外部程序!", LogLevelType.System, true);
                                    GC.Collect();
                                }
                                if (hasRunProcessAfterGrabAll)
                                {
                                    IsGrabing = false;
                                    succeed = true;
                                    InvokeAppendLogText("全部完成!", LogLevelType.System, true);
                                }
                                else
                                {
                                    IsGrabing = false;
                                }
                            }
                            else
                            {
                                IsGrabing = false;
                            }
                        }
                        else
                        {
                            IsGrabing = false;
                        }
                    }
                    else
                    {
                        IsGrabing = false;
                    }
                }
                else
                {
                    IsGrabing = false;
                }

            }
            catch (Exception ex)
            {
                IsGrabing = false;
                errorInfo = CommonUtil.GetExceptionAllMessage(ex);
                InvokeAppendLogText("错误!" + errorInfo, LogLevelType.Error, true);
                
                //关闭日志
                if (AutoRun && TaskLog != null)
                {
                    TaskLog.Close();
                }
            }
            finally
            {
                if (listSheet != null)
                {
                    listSheet.Close();
                }

                DateTime endTime = DateTime.Now;

                //输出爬取是否成功到文件
                TaskManager.ExportGrabResultFlag(this.TaskId, this.Project.Name, succeed ? "000" : "001", errorInfo, startTime, endTime, false);

                //如果是自动运行，那么自动关闭
                if (AutoRun)
                {
                    TaskManager.CloseTaskUI(this.TaskId);
                }
            }
        }
        #endregion

        #region 显示进度
        private DateTime _LastLogTime = DateTime.Now;
        private int hiddenCount = 0;
        private delegate void GrabInvokeDelegate(string msg);
        private delegate void ShowStatusInvokeDelegate(string msg);
        public void InvokeAppendLogText(string msg, LogLevelType logLevel, bool immediatelyShow)
        {
            if (logLevel >= SysConfig.ShowLogLevelType)
            {
                bool canShow = immediatelyShow || (DateTime.Now - _LastLogTime).TotalSeconds > SysConfig.ShowLogMinSecond || hiddenCount > SysConfig.IntervalShowLog;
                canShow = canShow && (logLevel != LogLevelType.Error || SysConfig.AllowShowError);
                if (canShow)
                {
                    hiddenCount = 0;
                    msg = DateTime.Now.ToString("(yyyy-MM-dd HH:mm:ss) ") + logLevel.ToString() + ": " + msg;
                    this.Invoke(new GrabInvokeDelegate(this.AppendLogText), msg);

                    //记录到日志文件
                    if (AutoRun)
                    {
                        TaskLog.AddLog(msg, logLevel, immediatelyShow);
                    }
                }
                else
                {
                    hiddenCount++;
                }
                _LastLogTime = DateTime.Now;
            }
        }
        private void AppendLogText(string msg)
        {
            this.textBoxGrabLog.AppendText(msg + "\r\n");
        }
         
        public void InvokeShowStatus(string msg)
        {
            this.Invoke(new ShowStatusInvokeDelegate(this.ShowStatus), new object[] { msg });
        }
        private void ShowStatus(string msg)
        {
            this.textBoxStatus.Text = msg;
        }
        #endregion

        #region 抓取列表页数据
        private List<string> _DetailPageUrlList;
        public List<string> DetailPageUrlList
        {
            get
            {
                return _DetailPageUrlList;
            }
        }
        private List<string> _DetailPageCookieList;
        public List<string> DetailPageCookieList
        {
            get
            {
                return _DetailPageCookieList;
            }
        }
        private List<string> _DetailPageNameList = new List<string>();
        public List<string> DetailPageNameList
        {
            get
            {
                return _DetailPageNameList;
            }
        }

        /*
        private Dictionary<string, Dictionary<string, string>> _DetailNameToFieldValues = new Dictionary<string, Dictionary<string, string>>();
        public Dictionary<string, Dictionary<string, string>> DetailNameToFieldValues 
        {
            get
            {
                return _DetailNameToFieldValues;
            }
        }
        */

        private void GetDetailPageList(IListSheet listSheet)
        {
            listSheet.InitDetailPageInfo();
            _DetailPageUrlList = listSheet.PageUrlList;
            _DetailPageNameList = listSheet.PageNameList;
            _DetailPageCookieList = listSheet.PageCookieList;
        }

        private bool GrabListPage(IListSheet listSheet, string filePath)
        {
            switch (this.Project.ListNavigateType)
            {
                case ListNavigateType.AutoUrlType:
                    {
                        Proj_ListPageInfo listPageInfo = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                        int succeedLastPageIndex = this.GetSucceedListPageIndex(listSheet);
                        int pageCount = succeedLastPageIndex + 1;
                        int pageIndex = succeedLastPageIndex > listPageInfo.BeginIndex ? succeedLastPageIndex : listPageInfo.BeginIndex;
                        while (listPageInfo.PageCountLimit == 0 || pageCount < listPageInfo.PageCountLimit)
                        {
                            DateTime dt1 = DateTime.Now;
                            if (GrabListPage(listSheet, filePath, pageIndex, listPageInfo))
                            { 
                                InvokeAppendLogText("已获取详情页地址：" + DetailPageUrlList.Count.ToString(), LogLevelType.Normal, false);
                                pageIndex = pageIndex ++;
                                pageCount++;
                            }
                            else
                            {
                                break;
                            }
                            DateTime dt2 = DateTime.Now;
                            TimeSpan ts = dt2 - dt1;
                            this.InvokeAppendLogText("此页面用时" + ts.TotalSeconds.ToString("0.00") + "秒", LogLevelType.Normal, false);

                            this.RefreshListStatus(true, dt1, dt2, listPageInfo.BeginIndex, pageIndex, listPageInfo.PageCountLimit > 0 ? listPageInfo.PageCountLimit : 0);
                        }
                        return true;
                    }
                case ListNavigateType.ProgramType:
                    {
                        Proj_CustomProgram customProgram = (Proj_CustomProgram)this.Project.ListPageInfoObject;

                        List<object> runParams = new List<object>(); 
                        runParams.Add(listSheet);  

                        List<Type> runParamTypes = new List<Type>(); 
                        runParamTypes.Add(typeof(IListSheet));  

                        return this.RunExtendedProgram(customProgram, runParams, runParamTypes);
                    }
                case ListNavigateType.ManualType:
                    {
                        if (listSheet == null)
                        {
                            throw new Exception("没有找到列表页对应的Sheet.");
                        }
                        else
                        {
                            return true;
                        }
                    }
                case ListNavigateType.NoneListPage:
                    return true;
                default:
                    return false;
            }
        }

        private bool RunExtendedProgram(Proj_CustomProgram customProgram, List<object> runParams, List<Type> runParamTypes)
        {
            try
            {
                string assemblyPath = Path.Combine(this.FileDir, "Extended\\" + customProgram.AssemblyName + ".dll");
                Assembly assembly = Assembly.LoadFile(assemblyPath);
                string typeName = customProgram.NamespaceName + "." + customProgram.ClassName;
                Type type = assembly.GetType(typeName);
                MethodInfo initMethod = type.GetMethod("Init", new Type[] { typeof(IRunWebPage) });
                object obj = assembly.CreateInstance(typeName);
                initMethod.Invoke(obj, new object[] { this });

                Type[] types ;
                if (runParamTypes == null)
                {
                    types = new Type[] { typeof(string) };
                }
                else
                {
                    runParamTypes.Insert(0, typeof(string));
                    types = runParamTypes.ToArray();
                }

                //如果为自启动任务，那么Parameter值可能不为空，那么用自启动任务的传入参数，否则用Project中定义的参数
                string parameter = CommonUtil.IsNullOrBlank(this.Parameter) ? customProgram.Parameters : this.Parameter;

                MethodInfo runMethod = type.GetMethod("Run", types);
                object[] runParamObjects;
                if (runParams == null)
                {
                    runParamObjects = new object[] { parameter };
                }
                else
                {
                    runParams.Insert(0, parameter);
                    runParamObjects = runParams.ToArray();
                }
                bool succeed = (bool)runMethod.Invoke(obj, runParamObjects);
                return succeed;
            }
            catch (Exception ex)
            {
                throw new Exception("执行      外部程序出错.", ex);
            }
        }

        private string GetListHtmlByWebBrowser(string pageUrl, Proj_ListPageInfo listPageInfo)
        {
            InvoceShowWebPage(pageUrl);

            int waitCount = 0;
            while (!this.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > SysConfig.WebPageRequestTimeout * 1000)
                {
                    //超时
                    throw new Exception("请求列表页超时. PageUrl = " + pageUrl);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }

            InvokeAvoidWebBrowserUnfriendlyJavaScript();

            //再增加个等待，等待异步加载的数据
            Thread.Sleep((int)listPageInfo.IntervalAfterLoaded * 1000);

            switch (listPageInfo.ProcessTypeAfterLoaded)
            {
                case ProcessTypeAfterLoaded.None:
                    break;
                case ProcessTypeAfterLoaded.ScrollToBottom:
                    {
                        int pageHeight = this.InvokeGetWebPageHeight();
                        this.InvokeScrollWebPage(pageHeight);
                    }
                    break;
                case ProcessTypeAfterLoaded.ScrollToBottomSlow:
                    {
                        int lastToY = 0;
                        int pageHeight = this.InvokeGetWebPageHeight();
                        while (lastToY < pageHeight)
                        {
                            lastToY += 500;
                            this.InvokeScrollWebPage(lastToY);
                            Thread.Sleep(500);
                            pageHeight = this.InvokeGetWebPageHeight();
                        }
                    }
                    break;
            }
            string webPageHtml = InvokeGetPageHtml();
            return webPageHtml;
        }

        private bool GetListHtmlInfo(IListSheet listSheet, string filePath, int pageIndex, string pageUrl, Proj_ListPageInfo listPageInfo, string webPageHtml)
        {
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);
            string[] blockPathSections = listPageInfo.DetailBlockPath.Split(new string[] { SysConfig.XPathSplit }, StringSplitOptions.RemoveEmptyEntries);
            List<HtmlNode> allBlockNodes = new List<HtmlNode>();
            allBlockNodes.Add(htmlDoc.DocumentNode);
            foreach (string blockPath in blockPathSections)
            {
                if (blockPath != SysConfig.XPathSplit)
                {
                    List<HtmlNode> allNewBlockNodes = new List<HtmlNode>();
                    foreach (HtmlNode parentNode in allBlockNodes)
                    {
                        HtmlNodeCollection children = parentNode.SelectNodes(blockPath);
                        if (children != null)
                        {
                            allNewBlockNodes.AddRange(children);
                        }
                    }
                    allBlockNodes = allNewBlockNodes;
                }
            }

            int addedCount = 0;
            //foreach (HtmlNode blockNode in allBlockNodes)
            for (int i = 0; i < allBlockNodes.Count; i++)
            {
                HtmlNode blockNode = allBlockNodes[i];
                HtmlNode aNode = CommonUtil.IsNullOrBlank(listPageInfo.DetailCtrlPath) ? null : GetHtmlNode(blockNode, listPageInfo.DetailCtrlPath);

                string detailUrl = aNode == null ? "" : aNode.GetAttributeValue("href", "");
                string detailName = "";
                if (!CommonUtil.IsNullOrBlank(listPageInfo.DetailNameCtrlPath))
                {
                    HtmlNode nameNode = GetHtmlNode(blockNode, listPageInfo.DetailNameCtrlPath);
                    if (nameNode == null)
                    {
                        throw new Exception("根据DetailNameCtrlPath没有找到详情页Name值. ListUrl = " + pageUrl);
                    }
                    else
                    {
                        detailName = nameNode.InnerText;
                    }
                }
                else if (!CommonUtil.IsNullOrBlank(listPageInfo.DetailCtrlNameAttribute))
                {
                    detailName = GetParamValue(detailUrl, listPageInfo.DetailCtrlNameAttribute);
                    if (CommonUtil.IsNullOrBlank(detailName))
                    {
                        throw new Exception("根据DetailCtrlNameAttribute没有找到详情页Name值. DetailUrl = " + detailUrl);
                    }
                }
                else
                {
                    detailName = detailUrl;
                }
                if (!CommonUtil.IsNullOrBlank(detailName))
                {
                    if (!DetailPageNameList.Contains(detailName))
                    {
                        DetailPageUrlList.Add(detailUrl);
                        DetailPageNameList.Add(detailName);
                        Dictionary<string, string> fieldValues = new Dictionary<string, string>();
                        //fieldValues.Add(SysConfig.ListPageIndexFieldName, pageIndex.ToString());
                        fieldValues.Add(SysConfig.DetailPageNameFieldName, detailName);
                        fieldValues.Add(SysConfig.DetailPageUrlFieldName, detailUrl);
                        //fieldValues.Add(SysConfig.SucceedRowFieldName, " ");

                        if (listPageInfo.Fields.Count > 0)
                        {
                            foreach (Proj_Detail_Field field in listPageInfo.Fields)
                            {
                                HtmlNode fieldValueNode = null;
                                if (!field.IsAbsolute)
                                {
                                    fieldValueNode = GetHtmlNode(blockNode, field.Path);
                                }
                                else
                                {
                                    fieldValueNode = GetHtmlNode(htmlDoc.DocumentNode, field.Path);
                                }
                                string value = fieldValueNode == null ? "" : fieldValueNode.InnerText;
                                fieldValues.Add(field.Name, value);
                            }
                        }

                        this.SaveListFieldValueToDB(listSheet, fieldValues);


                        addedCount++;
                    }
                }
            }

            if (addedCount > 0)
            {
                //this.SaveExcelToDisk(filePath);
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool GetListJsonInfo(IListSheet listSheet, string filePath, int pageIndex, string pageUrl, Proj_ListPageInfo listPageInfo, string webPageText)
        {
            JObject rootJo = JObject.Parse(webPageText); 
            string  blockPath   = listPageInfo.DetailBlockPath;
            JToken jt = rootJo.SelectToken(blockPath);
            if(jt == null)
            {
                throw new Exception("找不到路径"+blockPath+"的值. JSON = "+ webPageText);
            }
            else if(!(jt is JArray))
            {
                throw new Exception("找到了"+blockPath+"的值, 但是它不是数组. JSON = "+ webPageText);
            }
            else
            {
                int addedCount = 0;
                JArray jas = jt as JArray;
                for(int i=0;i<jas.Count;i++)
                {
                    JObject jo = jas[i] as JObject;
                    JToken detailUrlJ = CommonUtil.IsNullOrBlank(listPageInfo.DetailCtrlPath) ? null : jo[listPageInfo.DetailCtrlPath];

                    string detailUrl = detailUrlJ == null ? "" : detailUrlJ.ToString();
                    string detailName = "";
                    if (!CommonUtil.IsNullOrBlank(listPageInfo.DetailCtrlNameAttribute))
                    {
                        JToken nameJ = jo[listPageInfo.DetailCtrlNameAttribute];
                        if (nameJ == null)
                        {
                            throw new Exception("根据DetailCtrlNameAttribute没有找到Json值. ListUrl = " + pageUrl);
                        }
                        else
                        {
                            detailName = nameJ.ToString();
                        }
                    } 
                    else
                    {
                        detailName = detailUrl;
                    }
                    if (!CommonUtil.IsNullOrBlank(detailName))
                    {
                        if (!DetailPageNameList.Contains(detailName))
                        {
                            DetailPageUrlList.Add(detailUrl);
                            DetailPageNameList.Add(detailName);
                            Dictionary<string, string> fieldValues = new Dictionary<string, string>();
                            //fieldValues.Add(SysConfig.ListPageIndexFieldName, pageIndex.ToString());
                            fieldValues.Add(SysConfig.DetailPageNameFieldName, detailName);
                            fieldValues.Add(SysConfig.DetailPageUrlFieldName, detailUrl);
                            //fieldValues.Add(SysConfig.SucceedRowFieldName, " ");

                            if (listPageInfo.Fields.Count > 0)
                            {
                                foreach (Proj_Detail_Field field in listPageInfo.Fields)
                                {
                                    JToken fieldValueJ = jo[field.Name];
                                    string value = fieldValueJ == null ? "" : fieldValueJ.ToString();
                                    fieldValues.Add(field.Name, value);
                                }
                            }

                            this.SaveListFieldValueToDB(listSheet, fieldValues);

                            addedCount++;
                        }
                    }
                }

                if (addedCount > 0)
                {
                    //this.SaveExcelToDisk(filePath);
                    return true;
                }
                else
                {
                    return false;
                }
            } 
        }

        private bool GrabListPage(IListSheet listSheet, string filePath, int pageIndex, Proj_ListPageInfo listPageInfo)
        {
            string pageUrl = listPageInfo.ListUrlFormat.Replace("#pageIndex#", pageIndex.ToString());
            decimal intervalAfterLoaded = listPageInfo.IntervalAfterLoaded;
            string sourceDir = this.GetSourceFileDir(listPageInfo);
            string localPagePath = this.GetFilePath(pageUrl, sourceDir);
            Encoding encoding =  Encoding.GetEncoding(listPageInfo.Encoding);
            try
            {
                switch (listPageInfo.TextAccessType)
                {
                    case Proj_DataAccessType.WebBrowserHtml:
                        {
                            string webPageText = "";
                            if (this.ExistFile(localPagePath))
                            {
                                webPageText = ReadFile(localPagePath);
                            }
                            else
                            {
                                webPageText = GetListHtmlByWebBrowser(pageUrl, listPageInfo);
                                this.SaveFile(webPageText, localPagePath, encoding);
                            }
                            return this.GetListHtmlInfo( listSheet, filePath, pageIndex, pageUrl, listPageInfo, webPageText);
                        }
                    case Proj_DataAccessType.WebRequestHtml:
                        {
                            string webPageText = "";
                            if (this.ExistFile(localPagePath))
                            {
                                webPageText = ReadFile(localPagePath);
                            }
                            else
                            {
                                webPageText = GetTextByRequest(pageUrl, listPageInfo.NeedProxy, intervalAfterLoaded, listPageInfo.RequestTimeout, encoding,"");
                                this.SaveFile(webPageText, localPagePath, encoding);
                            }
                            return this.GetListHtmlInfo(listSheet, filePath, pageIndex, pageUrl, listPageInfo, webPageText);
                        }
                    case Proj_DataAccessType.WebRequestJson:
                        {
                            string webPageText = "";
                            if (this.ExistFile(localPagePath))
                            {
                                webPageText = ReadFile(localPagePath);
                            }
                            else
                            {
                                webPageText = GetTextByRequest(pageUrl, listPageInfo.NeedProxy, intervalAfterLoaded, listPageInfo.RequestTimeout, encoding,"");
                                this.SaveFile(webPageText, localPagePath, encoding);
                            }
                            return this.GetListJsonInfo(listSheet, filePath, pageIndex, pageUrl, listPageInfo, webPageText);
                        }
                    case Proj_DataAccessType.WebRequestFile:
                    default:
                        return false;

                }
            }
            catch (Exception ex)
            {
                throw new Exception("抓取列表页数据出错. PageUrl = " + pageUrl, ex);
            }
        }
        #endregion

        #region 获取符合条件的节点
        private HtmlNode GetHtmlNode(HtmlNode parentNode, string allPathes) 
        {
            string[] pathes = allPathes.Split(new string[] { "#or#" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string path in pathes)
            {
                if (path != null && path.Length > 0)
                {
                    HtmlNode node = parentNode.SelectSingleNode(path);
                    if (node != null)
                    {
                        return node;
                    }
                }
            }
            return null;
        }
        #endregion

        #region 获取路径中的参数值
        private string GetParamValue(string url, string paramterName)
        {
            if (!CommonUtil.IsNullOrBlank(paramterName))
            {

                Uri uri = new Uri(this.webBrowserMain.Url, url, false);                
                string value = HttpUtility.ParseQueryString(uri.Query).Get(paramterName);
                return CommonUtil.IsNullOrBlank(value) ? url : value;
            }
            else 
            {
                return url;
            }
        }
        #endregion

        #region 网址输入框按键按下
        private void textBoxPageUrl_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    ShowWebPage();
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region 显示网页
        private void ShowWebPage()
        {
            this.webBrowserMain.Navigate(this.textBoxPageUrl.Text);
        }
        #endregion

        #region 获取浏览器HTML内容
        private delegate string WebPageInvokeDelegate();
        public string InvokeGetPageHtml()
        {
            return (string)this.Invoke(new WebPageInvokeDelegate(this.GetPageHtmlContent));
        }
        private string GetPageHtmlContent()
        {
            return this.webBrowserMain.Document.Body.OuterHtml;
        }
        #endregion

        #region 抓取完成后的后期处理
        private bool ProcessAfterGrabAll(IListSheet listSheet)
        {
            Proj_CustomProgram processAfterGrabAll = (Proj_CustomProgram)this.Project.ProgramAfterGrabAllObject;
            if (processAfterGrabAll != null)
            {
                List<object> runParams = new List<object>(); 
                runParams.Add(listSheet);

                List<Type> runParamTypes = new List<Type>();
                runParamTypes.Add(typeof(IListSheet)); 

                return this.RunExtendedProgram(processAfterGrabAll, runParams, runParamTypes);
            }
            else
            {
                return true;
            }
        }
        #endregion

        #region 通过webrequest获取网页html
        private string GetTextByRequest(string pageUrl, bool needProxy, decimal intervalAfterLoaded, int timeout, Encoding encoding, string cookie)
        {
            NDAWebClient client = null;
            Stream data = null;
            StreamReader reader = null;
            try
            {
                DateTime dt1 = DateTime.Now;
                client = new NDAWebClient();
                System.Net.ServicePointManager.DefaultConnectionLimit = 512;
                client.Timeout = timeout * 1000;
                if (needProxy)
                {
                    client.Proxy = ProxyServers.GetWebProxy(this.Project.Id);
                }
                client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                if (!CommonUtil.IsNullOrBlank(cookie))
                {
                    client.Headers.Add("cookie", cookie);
                    //client.Headers.Add("connection", "keep-alive");
                }
                data = client.OpenRead(pageUrl);
                reader = new StreamReader(data, encoding);
                string s = reader.ReadToEnd();
                data.Close();
                reader.Close();

                //再增加个等待，等待异步加载的数据
                Thread.Sleep((int)intervalAfterLoaded * 1000);

                DateTime dt2 = DateTime.Now;
                double ts = (dt2 - dt1).TotalSeconds;
                //this.InvokeAppendLogText("GetTextByRequest: " + ts.ToString("0.0000"), LogLevelType.System, true);
              
                return s;
            }
            catch (Exception ex)
            {
                string errorInfo = "访问失败, PageUrl = " + pageUrl + (client.Proxy == null ? "" : ("代理地址:" + client.Proxy.ToString())) + ". " + ex.Message;
                //this.InvokeAppendLogText(errorInfo, LogLevelType.Error, true);
                throw new GrabRequestException(errorInfo, ex);
            }
            finally
            {
                if (data != null)
                {
                    data.Close();
                    data.Dispose();
                }
                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                }
            }
        }
        #endregion

        #region 通过webrequest获取File
        private byte[] GetFileByRequest(string pageUrl, bool needProxy, decimal intervalAfterLoaded, int timeout)
        {
            NDAWebClient client = null;
            try
            {
                client = new NDAWebClient();
                client.Timeout = timeout * 1000;
                if (needProxy)
                {
                    client.Proxy = ProxyServers.GetWebProxy(this.Project.Id);
                }
                client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                byte[] data = client.DownloadData(pageUrl);
                 
                //再增加个等待，等待异步加载的数据
                Thread.Sleep((int)intervalAfterLoaded * 1000);

                return data;
            }
            catch (Exception ex)
            {
                string errorInfo = "访问失败, PageUrl = " + pageUrl + ". " + ex.Message;
                //this.InvokeAppendLogText(errorInfo, LogLevelType.Error, true);
                throw new GrabRequestException(errorInfo);
            }
        }
        #endregion

        #region 抓取详情页数据 
         
        private int _CompleteGrabCount = 0;
        private int _SucceedGrabCount = 0;
        private int _AllNeedGrabCount = 0; 

        private object _GetPageIndexLocker = new object();

        private List<int> _NeedGrabIndexs = null;
        private int InitGrabDetailPageIndexList(IListSheet listSheet, int startPageIndex, int endPageIndex, string sourceDir)
        { 
            int detailPageIndex = 0;
            this._NeedGrabIndexs = new List<int>();
            while (detailPageIndex < DetailPageUrlList.Count)
            {
                string pageUrl = DetailPageUrlList[detailPageIndex];
                string localPagePath = this.GetFilePath(pageUrl, sourceDir);
                if (CheckInGrabRange(detailPageIndex, startPageIndex, endPageIndex)
                    && !this.ExistFile(localPagePath)
                    && !this.CheckGiveUpGrabPage(listSheet, pageUrl, detailPageIndex))
                {
                    this._NeedGrabIndexs.Add(detailPageIndex);
                }
                detailPageIndex++;
            }
            return this._NeedGrabIndexs.Count;
        }
        private Nullable<int> GetNextGrabDetailPageIndex()
        {
            lock (_GetPageIndexLocker)
            {
                DateTime dt1 = DateTime.Now;
                try
                {
                    if (_NeedGrabIndexs.Count > 0)
                    {
                        int index = _NeedGrabIndexs[0];
                        _NeedGrabIndexs.RemoveAt(0);
                        return index;
                    }
                    else
                    {
                        return null;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    DateTime dt2 = DateTime.Now;
                    double ts = (dt2 - dt1).TotalSeconds;
                    //this.InvokeAppendLogText("GetNextGrabDetailPageIndex: " + ts.ToString("0.0000"), LogLevelType.System, true);
                }
            }
        } 

        private void BeginGrabDetailPageInParallelThread(IListSheet listSheet, Proj_Detail_SingleLine detailPageInfo)
        {
            int threadCount = detailPageInfo.DataAccessType == Proj_DataAccessType.WebBrowserHtml ? 1 : detailPageInfo.ThreadCount;
            this._AllGrabDetailThreads = new List<Thread>();
            for (int i = 0; i < threadCount; i++)
            {
                Thread grabThread = new Thread(new ParameterizedThreadStart(ThreadGrabDetailPageSingle));
                this.AllGrabDetailThreads.Add(grabThread);
                this.InvokeAppendLogText("线程" + grabThread.ManagedThreadId.ToString() + "开始抓取数据.", LogLevelType.System, true);
                grabThread.Start(new object[] { listSheet, detailPageInfo });
                Thread.Sleep(500);
            }
        }

        private void BeginGrabDetailPageInParallelThread(IListSheet listSheet, Proj_Detail_MultiLine detailPageInfo)
        {
            int threadCount = detailPageInfo.DataAccessType == Proj_DataAccessType.WebBrowserHtml ? 1 : detailPageInfo.ThreadCount;
            this._AllGrabDetailThreads = new List<Thread>();
            for (int i = 0; i < threadCount; i++)
            {
                Thread grabThread = new Thread(new ParameterizedThreadStart(ThreadGrabDetailPageMulti));
                this.AllGrabDetailThreads.Add(grabThread);
                this.InvokeAppendLogText("线程" + grabThread.ManagedThreadId.ToString() + "开始抓取数据.", LogLevelType.System, true);
                grabThread.Start(new object[] { listSheet, detailPageInfo });
                Thread.Sleep(200);
            }
        }

        private void ThreadGrabDetailPageSingle(object parameters)
        {
            object[] parameterArray = (object[])parameters;
            IListSheet listSheet = (IListSheet)parameterArray[0]; 
            Proj_Detail_SingleLine detailPageInfo = (Proj_Detail_SingleLine)parameterArray[1];
            string sourceDir = this.GetSourceFileDir(detailPageInfo);
            Nullable<int> nextPageIndex = this.GetNextGrabDetailPageIndex();
            while (nextPageIndex != null)
            {
                try
                { 
                    this.ThreadGrabDetailPage(listSheet, (int)nextPageIndex, detailPageInfo, sourceDir);
                }
                catch (Exception ex)
                {
                    this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 出错!!!!!!!!!!!!" + ex.Message, LogLevelType.System, true);
                }
                nextPageIndex = this.GetNextGrabDetailPageIndex();
            }
            this.AllGrabDetailThreads.Remove(Thread.CurrentThread);
        }

        private void ThreadGrabDetailPageMulti(object parameters)
        {
            object[] parameterArray = (object[])parameters;
            IListSheet listSheet = (IListSheet)parameterArray[0];
            Proj_Detail_MultiLine detailPageInfo = (Proj_Detail_MultiLine)parameterArray[1];
            string sourceDir = this.GetSourceFileDir(detailPageInfo);
            Nullable<int> nextPageIndex = this.GetNextGrabDetailPageIndex();
            while (nextPageIndex != null)
            {
                try
                {
                    this.ThreadGrabDetailPage(listSheet, (int)nextPageIndex, detailPageInfo, sourceDir);
                }
                catch (Exception ex)
                {
                    this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 出错!!!!!!!!!!!!" + ex.Message, LogLevelType.System, true);
                }
                nextPageIndex = this.GetNextGrabDetailPageIndex();
            }
            this.AllGrabDetailThreads.Remove(Thread.CurrentThread);
        }

        private void ThreadGrabDetailPage(IListSheet listSheet, int detailPageIndex, Proj_Detail_SingleLine detailPageInfo, string sourceDir)
        {
            DateTime dt1 = DateTime.Now;
            string pageUrl = DetailPageUrlList[detailPageIndex];
            string cookie = DetailPageCookieList[detailPageIndex];
            string localPagePath = this.GetFilePath(pageUrl, sourceDir);
            bool succeed = true;
            if (!this.ExistFile(localPagePath))
            {
                succeed = GrabDetailPage(listSheet, pageUrl, localPagePath, detailPageIndex, detailPageInfo, cookie);
            }

            this.RefreshGrabCount(succeed);

            DateTime dt2 = DateTime.Now;
            TimeSpan ts = dt2 - dt1;
            this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 抓取了第" + (detailPageIndex + 1).ToString() + "个页面, 用时" + ts.TotalSeconds.ToString("0.00") + "秒", LogLevelType.Normal, false);

            this.RefreshGrabDetailStatus(succeed, dt1, dt2);
        }

        private void ThreadGrabDetailPage(IListSheet listSheet, int detailPageIndex, Proj_Detail_MultiLine detailPageInfo, string sourceDir)
        {
            DateTime dt1 = DateTime.Now;
            string pageUrl = DetailPageUrlList[detailPageIndex];
            string cookie = DetailPageCookieList[detailPageIndex];
            string localPagePath = this.GetFilePath(pageUrl, sourceDir);
            bool succeed = true;
            if (!this.ExistFile(localPagePath))
            {
                succeed = GrabDetailPage(listSheet, pageUrl, localPagePath, detailPageIndex, detailPageInfo, cookie);
            }
            this.RefreshGrabCount(succeed);

            DateTime dt2 = DateTime.Now;
            TimeSpan ts = dt2 - dt1;
            this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 抓取了第" + (detailPageIndex + 1).ToString() + "个页面, 用时" + ts.TotalSeconds.ToString("0.00") + "秒", LogLevelType.Normal, false);

            this.RefreshGrabDetailStatus(succeed, dt1, dt2);
        }

        private void RefreshGrabCount(bool succeed)
        {
            if (succeed)
            {
                _SucceedGrabCount++; 
            }
            _CompleteGrabCount++;
        }
        
        private bool GrabDetailPage(IListSheet listSheet)
        {
            //初始化计数器 
            _CompleteGrabCount = 0;
            _SucceedGrabCount = 0; 

            switch (this.Project.DetailGrabType)
            {
                case DetailGrabType.NoneDetailPage:
                    {
                        return true;
                    }
                case DetailGrabType.SingleLineType:
                    {
                        try
                        {
                            Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                            Proj_Detail_SingleLine detailPageInfo = (Proj_Detail_SingleLine)this.Project.DetailGrabInfoObject; 
                            string sourceDir = this.GetSourceFileDir(detailPageInfo);
                            int startPageIndex = detailPageInfo.StartPageIndex;
                            int endPageIndex = detailPageInfo.EndPageIndex;
                            _AllNeedGrabCount = this.InitGrabDetailPageIndexList(listSheet, startPageIndex, endPageIndex, sourceDir);
                            if (_AllNeedGrabCount != 0)
                            {
                                this.BeginGrabDetailPageInParallelThread(listSheet, detailPageInfo);
                                while (this._CompleteGrabCount < this._AllNeedGrabCount || this.AllGrabDetailThreads.Count > 0)
                                {
                                    Thread.Sleep(5000);
                                }
                                return this._SucceedGrabCount == this._AllNeedGrabCount;
                            }
                            else
                            {
                                return true;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                        } 
                    }
                case DetailGrabType.MultiLineType:
                    {
                        try
                        {
                            Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                            Proj_Detail_MultiLine detailPageInfo = (Proj_Detail_MultiLine)this.Project.DetailGrabInfoObject;
                            string sourceDir = this.GetSourceFileDir(detailPageInfo);
                            int startPageIndex = detailPageInfo.StartPageIndex;
                            int endPageIndex = detailPageInfo.EndPageIndex;
                            _AllNeedGrabCount = this.InitGrabDetailPageIndexList(listSheet, startPageIndex, endPageIndex, sourceDir);
                            if (_AllNeedGrabCount != 0)
                            {
                                this.BeginGrabDetailPageInParallelThread(listSheet, detailPageInfo);
                                while (this._CompleteGrabCount < this._AllNeedGrabCount || this.AllGrabDetailThreads.Count > 0)
                                {
                                    Thread.Sleep(5000);
                                }
                                return this._SucceedGrabCount == this._AllNeedGrabCount;
                            }
                            else
                            {
                                return true;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                        } 
                    }
                case DetailGrabType.ProgramType:
                    {
                        Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                        Proj_CustomProgram customProgram = (Proj_CustomProgram)this.Project.DetailGrabInfoObject;

                        List<object> runParams = new List<object>();
                        runParams.Add(listSheet);

                        List<Type> runParamTypes = new List<Type>();
                        runParamTypes.Add(typeof(ISheet));

                        return this.RunExtendedProgram(customProgram, runParams, runParamTypes);
                    } 
                default:
                    return false;
            }
        }
        #endregion

        #region 创建导出文件
        private DetailExportWriter CreateExportFile(string dir, ExportType exportType, Dictionary<string, int> columnNameToIndex)
        {
            DetailExportWriter exportWriter = null;
            switch (exportType)
            {
                case ExportType.Csv:
                    {
                        string filePath = Path.Combine(dir, this.Project.Name + "_Detail.csv");
                        exportWriter = new CsvWriter(filePath, columnNameToIndex);
                    }
                    break;
                case ExportType.Excel:
                    {
                        string filePath = Path.Combine(dir, this.Project.Name + "_Detail.xlsx");
                        exportWriter = new ExcelWriter(filePath, columnNameToIndex);
                    }
                    break;
                case ExportType.None:
                    {
                        this.InvokeAppendLogText("已经设置了无需输出文件.", LogLevelType.System, true);
                        exportWriter = null;
                    }
                    break;
                case ExportType.Xml:
                    throw new Exception("尚未实现xml格式的导出功能"); 
            }
            return exportWriter;
        }
        #endregion

        #region 导出详情页信息到文件
        private bool ExportDetailPage(IListSheet listSheet)
        {
            switch (this.Project.DetailGrabType)
            {
                case DetailGrabType.NoneDetailPage:
                    {
                        return true;
                    }
                case DetailGrabType.SingleLineType:
                    {
                        Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                        Proj_Detail_SingleLine detailPageInfo = (Proj_Detail_SingleLine)this.Project.DetailGrabInfoObject;
                        if (detailPageInfo.Fields.Count > 0)
                        {
                            int startPageIndex = detailPageInfo.StartPageIndex;
                            int endPageIndex = detailPageInfo.EndPageIndex;
                            string sourceDir = this.GetSourceFileDir(detailPageInfo);
                            string readDir = this.GetReadFileDir(detailPageInfo);

                            try
                            {
                                DetailExportWriter exportWriter = this.CreateExportFile(this.GetExportDir(detailPageInfo), detailPageInfo.ExportType, this.ColumnNameToIndex);
                                if (exportWriter != null)
                                {
                                    int detailPageIndex = 0;
                                    while (detailPageIndex < DetailPageUrlList.Count)
                                    {
                                        string pageUrl = DetailPageUrlList[detailPageIndex];
                                        string localReadFilePath = this.GetReadFilePath(pageUrl, readDir);
                                        if (this.CheckInGrabRange(detailPageIndex, startPageIndex, endPageIndex))
                                        {
                                            if (!ExportDetailPage(listSheet, exportWriter, detailPageIndex, pageUrl, localReadFilePath, detailPageInfo))
                                            {
                                                return false;
                                            }
                                        }
                                        detailPageIndex++;
                                    }
                                    exportWriter.SaveToDisk();
                                }
                                return true;
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                case DetailGrabType.MultiLineType:
                    {
                        Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                        Proj_Detail_MultiLine detailPageInfo = (Proj_Detail_MultiLine)this.Project.DetailGrabInfoObject;
                        if (detailPageInfo.Fields.Count > 0)
                        {
                            List<Proj_Detail_Field> allFields = GetOutputFields(listPageInfoObj == null ? null : listPageInfoObj.Fields, detailPageInfo.Fields);
                            int startPageIndex = detailPageInfo.StartPageIndex;
                            int endPageIndex = detailPageInfo.EndPageIndex;
                            string sourceDir = this.GetSourceFileDir(detailPageInfo);
                            string readDir = this.GetReadFileDir(detailPageInfo);
                            try
                            {
                                DetailExportWriter exportWriter = this.CreateExportFile(this.GetExportDir(detailPageInfo), detailPageInfo.ExportType, this.ColumnNameToIndex);
                                if (exportWriter != null)
                                {
                                    int detailPageIndex = 0;
                                    while (detailPageIndex < DetailPageUrlList.Count)
                                    {
                                        string pageUrl = DetailPageUrlList[detailPageIndex];
                                        string localReadFilePath = this.GetReadFilePath(pageUrl, readDir);
                                        if (this.CheckInGrabRange(detailPageIndex, startPageIndex, endPageIndex))
                                        {
                                            if (!ExportDetailPage(listSheet, exportWriter, detailPageIndex, pageUrl, localReadFilePath, detailPageInfo))
                                            {
                                                return false;
                                            }
                                        }
                                        detailPageIndex++;
                                    }
                                    exportWriter.SaveToDisk();
                                }
                                return true;
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                case DetailGrabType.ProgramType:
                    return false;
                default:
                    return false;
            }
        }
        #endregion

        #region 读取详情页信息
        private bool ReadDetailPage( IListSheet listSheet )
        {
            switch (this.Project.DetailGrabType)
            {
                case DetailGrabType.NoneDetailPage:
                    {
                        return true;
                    }
                case DetailGrabType.SingleLineType:
                    {
                        Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                        Proj_Detail_SingleLine detailPageInfo = (Proj_Detail_SingleLine)this.Project.DetailGrabInfoObject;
                        if (detailPageInfo.Fields.Count > 0)
                        {
                            int startPageIndex = detailPageInfo.StartPageIndex;
                            int endPageIndex = detailPageInfo.EndPageIndex;
                            string sourceDir = this.GetSourceFileDir(detailPageInfo);
                            string readDir = this.GetReadFileDir(detailPageInfo);
                            bool hasError = false;
                            try
                            {
                                int detailPageIndex = 0;
                                while (detailPageIndex < DetailPageUrlList.Count)
                                {
                                    string pageUrl = DetailPageUrlList[detailPageIndex];
                                    string pageName = DetailPageNameList[detailPageIndex];
                                    string localPagePath = this.GetFilePath(pageUrl, sourceDir);
                                    string localReadFilePath = this.GetReadFilePath(pageUrl, readDir);
                                    if (CheckInGrabRange(detailPageIndex, detailPageInfo.StartPageIndex, detailPageInfo.EndPageIndex)
                                        && !this.ExistFile(localReadFilePath))
                                    {
                                        DateTime dt1 = DateTime.Now;
                                        bool succeed = ReadDetailPage(listSheet, pageUrl, pageName, localPagePath,detailPageIndex, localReadFilePath, detailPageInfo);
                                        hasError = succeed ? hasError : true;
                                        DateTime dt2 = DateTime.Now;
                                        TimeSpan ts = dt2 - dt1;
                                        this.RefreshReadDetailStatus(succeed, dt1, dt2);
                                    }
                                    detailPageIndex++;
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                            finally
                            {
                            }
                            return !hasError;
                        }
                        else
                        {
                            return true;
                        }
                    }
                case DetailGrabType.MultiLineType:
                    {
                        Proj_ListPageInfo listPageInfoObj = (Proj_ListPageInfo)this.Project.ListPageInfoObject;
                        Proj_Detail_MultiLine detailPageInfo = (Proj_Detail_MultiLine)this.Project.DetailGrabInfoObject;
                        if (detailPageInfo.Fields.Count > 0)
                        {
                            List<Proj_Detail_Field> allFields = GetOutputFields(listPageInfoObj == null ? null : listPageInfoObj.Fields, detailPageInfo.Fields);
                            int startPageIndex = detailPageInfo.StartPageIndex;
                            int endPageIndex = detailPageInfo.EndPageIndex;
                            string sourceDir = this.GetSourceFileDir(detailPageInfo);
                            string readDir = this.GetReadFileDir(detailPageInfo);
                            bool hasError = false;
                            try
                            {
                                int detailPageIndex = 0;
                                while (detailPageIndex < DetailPageUrlList.Count)
                                {
                                    string pageUrl = DetailPageUrlList[detailPageIndex];
                                    string pageName = DetailPageNameList[detailPageIndex];
                                    string localPagePath = this.GetFilePath(pageUrl, sourceDir);
                                    string localReadFilePath = this.GetReadFilePath(pageUrl, readDir);
                                    if (CheckInGrabRange(detailPageIndex, detailPageInfo.StartPageIndex, detailPageInfo.EndPageIndex)
                                        && !this.ExistFile(localReadFilePath))
                                    {
                                        DateTime dt1 = DateTime.Now;
                                        bool succeed = ReadDetailPage(listSheet, pageUrl, pageName, localPagePath, detailPageIndex, localReadFilePath, detailPageInfo);
                                        hasError = succeed ? hasError : false;
                                        DateTime dt2 = DateTime.Now;
                                        TimeSpan ts = dt2 - dt1;
                                        //this.RefreshReadDetailStatus(succeed, dt1, dt2, detailPageInfo.StartPageIndex <= 0 ? 1 : detailPageInfo.StartPageIndex, detailPageIndex, detailPageInfo.EndPageIndex > 0 ? detailPageInfo.EndPageIndex : DetailPageUrlList.Count);
                                    }
                                    detailPageIndex++;
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                            finally
                            {
                            }
                            return !hasError;
                        }
                        else
                        {
                            return true;
                        }
                    }
                case DetailGrabType.ProgramType:
                    return false;
                default:
                    return false;
            }
        }

        #region 屏蔽不友好的js，例如弹出框
        private void InvokeAvoidWebBrowserUnfriendlyJavaScript()
        {
            WebBrowser webBrowser = this.GetWebBrowser(); 
            webBrowser.Invoke(new AvoidWebBrowserUnfriendlyJavaScriptDelegate(AvoidWebBrowserUnfriendlyJavaScript));
        }
        private delegate void AvoidWebBrowserUnfriendlyJavaScriptDelegate();
        private void AvoidWebBrowserUnfriendlyJavaScript()
        {
            WebBrowser webBrowser = this.GetWebBrowser(); 
            HtmlElement sElement = webBrowser.Document.CreateElement("script");
            IHTMLScriptElement scriptElement = (IHTMLScriptElement)sElement.DomElement;
            scriptElement.text = "alert = function(){};confirm = function(){};";
            webBrowser.Document.Body.AppendChild(sElement); 
        }
        #endregion

        private string GetDetailHtmlByWebBrowser(string pageUrl, decimal intervalAfterLoaded, int timeout)
        {
            InvoceShowWebPage(pageUrl);

            int waitCount = 0;
            while (!this.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > timeout * 1000)
                {
                    //超时
                    throw new GrabRequestException("请求详情页超时. PageUrl = " + pageUrl);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }

            InvokeAvoidWebBrowserUnfriendlyJavaScript();

            //再增加个等待，等待异步加载的数据
            Thread.Sleep((int)intervalAfterLoaded * 1000);
            string webPageHtml = InvokeGetPageHtml();
            return webPageHtml;
        }

        private void GetDetailHtmlInfo( string pageUrl, string pageName, string localPagePath, string localReadFilePath, Proj_Detail_SingleLine detailPageInfo, string webPageHtml)
        {
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);
            Dictionary<string, string> fieldValues = new Dictionary<string, string>();
            foreach (Proj_Detail_Field field in detailPageInfo.Fields)
            {
                if (field.Name == "*")
                {
                    fieldValues.Add(field.Name, webPageHtml);
                }
                else
                {
                    HtmlNode node = GetHtmlNode(htmlDoc.DocumentNode, field.Path);
                    string value = node == null
                        ? ""
                        : (field.NeedAllHtml ? node.OuterHtml : (CommonUtil.IsNullOrBlank(field.AttributeName) ? node.InnerText : node.GetAttributeValue(field.AttributeName, "")));
                    fieldValues.Add(field.Name, value);
                }
            }
            fieldValues.Add(SysConfig.DetailPageNameFieldName, pageName);
            fieldValues.Add(SysConfig.DetailPageUrlFieldName, pageUrl);

            this.SaveDetailFieldValueToFile( fieldValues, localReadFilePath); 

        }


        private void GetDetailJsonInfo( string pageUrl, string pageName, string localPagePath,string localReadFilePath, Proj_Detail_SingleLine detailPageInfo, string webPageText)
        {
            JObject rootJo = JObject.Parse(webPageText);  

            Dictionary<string, string> fieldValues = new Dictionary<string, string>();
            foreach (Proj_Detail_Field field in detailPageInfo.Fields)
            {
                if (field.Name == "*")
                {
                    fieldValues.Add(field.Name, rootJo.ToString());
                }
                else
                {
                    JToken fieldValueJ = rootJo[field.Name];
                    string value = fieldValueJ == null ? "" : fieldValueJ.ToString();
                    fieldValues.Add(field.Name, value);
                }
            }

            fieldValues.Add(SysConfig.DetailPageNameFieldName, pageName);
            fieldValues.Add(SysConfig.DetailPageUrlFieldName, pageUrl);
            this.SaveDetailFieldValueToFile(fieldValues, pageUrl); 
        }

        private bool GrabDetailPage(IListSheet listSheet, string pageUrl, string localPagePath, int pageIndex, Proj_Detail_SingleLine detailPageInfo, string cookie)
        {
            string pageName = DetailPageNameList[pageIndex];
            decimal intervalAfterLoaded = detailPageInfo.IntervalAfterLoaded;
            Encoding encoding =  Encoding.GetEncoding(detailPageInfo.Encoding);
            try
            {
                switch (detailPageInfo.DataAccessType)
                {
                    case Proj_DataAccessType.WebBrowserHtml:
                        {
                            string webPageText = GetDetailHtmlByWebBrowser(pageUrl, intervalAfterLoaded, detailPageInfo.RequestTimeout);
                            this.SaveFile(webPageText, localPagePath, encoding);
                        }
                        break;
                    case Proj_DataAccessType.WebRequestHtml:
                        {
                            string webPageText = GetTextByRequest(pageUrl, detailPageInfo.NeedProxy, intervalAfterLoaded, detailPageInfo.RequestTimeout, encoding, cookie);
                            this.SaveFile(webPageText, localPagePath, encoding);
                        }
                        break;
                    case Proj_DataAccessType.WebRequestJson:
                        {
                            string webPageText = GetTextByRequest(pageUrl, detailPageInfo.NeedProxy, intervalAfterLoaded, detailPageInfo.RequestTimeout, encoding, cookie);
                            this.SaveFile(webPageText, localPagePath, encoding);
                        }
                        break;
                    case Proj_DataAccessType.WebRequestFile:
                        {
                            byte[] data = GetFileByRequest(pageUrl, detailPageInfo.NeedProxy, intervalAfterLoaded, detailPageInfo.RequestTimeout);
                            this.SaveFile(data, localPagePath);
                        }
                        break;
                }
                return true;
            }
            catch (Exception ex)
            {
                if (!detailPageInfo.AllowAutoGiveUp || !GiveUpGrabPage(listSheet, pageUrl, pageIndex, ex))
                {
                    this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 抓取详情页数据出错. PageUrl = " + pageUrl + ". " + ex.Message, LogLevelType.Error, true);
                    if (detailPageInfo.NeedProxy && detailPageInfo.AutoAbandonDisableProxy)
                    {
                        ProxyServer ps = ProxyServers.Abandon(this.Project.Id);
                        this.InvokeAppendLogText("已经放弃了代理服务器. ProxyServer = " + ps.IP + ":" + ps.Port.ToString(), LogLevelType.Error, true);
                    }
                    return false;
                }
                else
                {
                    this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 放弃抓取, 抓取详情页数据出错. PageUrl = " + pageUrl + ". " + ex.Message, LogLevelType.Error, true);
                    return true;
                }
            }
        }

        /// <summary>
        ///  获取是否放弃抓取此页
        /// </summary>
        /// <returns></returns>
        public bool CheckGiveUpGrabPage(IListSheet listSheet, string pageUrl, int pageIndex)
        {
            bool giveUp = listSheet.GiveUpList[pageIndex];
            string url = listSheet.PageUrlList[pageIndex];
            if (url == pageUrl)
            {
                return giveUp;
            }
            else
            {
                throw new Exception("记录行定位错误. PageUrl = " + pageUrl + ". UrlCellValue = " + url);
            }
        }

        /// <summary>
        ///  判断是否放弃抓取此页
        /// </summary>
        /// <returns></returns>
        private bool GiveUpGrabPage(IListSheet listSheet, string pageUrl, int pageIndex, Exception ex)
        {
            bool giveUp = false;
            string errorMsg = "";
            if (ex is GrabRequestException)
            {
                giveUp = true;
                errorMsg = ex.Message;
            }

            if (giveUp)
            {
                listSheet.SetGiveUp(pageIndex, pageUrl, errorMsg);
                return true;
            }
            else
            {
                return false;
            }
        }


        private bool ReadDetailPage(IListSheet listSheet, string pageUrl, string pageName, string localPagePath, int detailPageIndex, string localReadFilePath, Proj_Detail_SingleLine detailPageInfo)
        {
            try
            {
                if (this.CheckGiveUpGrabPage(listSheet, pageUrl, detailPageIndex))
                {
                    return true;
                }
                else
                {
                    string webPageText = this.ReadFile(localPagePath);
                    switch (detailPageInfo.DataAccessType)
                    {
                        case Proj_DataAccessType.WebBrowserHtml:
                            {
                                this.GetDetailHtmlInfo(pageUrl, pageName, localPagePath, localReadFilePath, detailPageInfo, webPageText);
                            }
                            break;
                        case Proj_DataAccessType.WebRequestHtml:
                            {
                                this.GetDetailHtmlInfo(pageUrl, pageName, localPagePath, localReadFilePath, detailPageInfo, webPageText);
                            }
                            break;
                        case Proj_DataAccessType.WebRequestJson:
                            {
                                this.GetDetailJsonInfo(pageUrl, pageName, localPagePath, localReadFilePath, detailPageInfo, webPageText);
                            }
                            break;
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                this.InvokeAppendLogText("读取详情页信息出错. PageUrl = " + pageUrl + " " + ex.Message, LogLevelType.Error, true);
                return false;
            }
        }

        private bool ReadDetailPage(IListSheet listSheet, string pageUrl, string pageName, string localPagePath, int detailPageIndex, string localReadFilePath, Proj_Detail_MultiLine detailPageInfo)
        {
            try
            {
                if (this.CheckGiveUpGrabPage(listSheet, pageUrl, detailPageIndex))
                {
                    return true;
                }
                else
                {
                    string webPageText = this.ReadFile(localPagePath);
                    switch (detailPageInfo.DataAccessType)
                    {
                        case Proj_DataAccessType.WebBrowserHtml:
                            {
                                this.GetDetailHtmlInfo(pageUrl, pageName, localPagePath, localReadFilePath, detailPageInfo, webPageText);
                            }
                            break;
                        case Proj_DataAccessType.WebRequestHtml:
                            {
                                this.GetDetailHtmlInfo(pageUrl, pageName, localPagePath, localReadFilePath, detailPageInfo, webPageText);
                            }
                            break;
                        case Proj_DataAccessType.WebRequestJson:
                            {
                                this.GetDetailJsonInfo(pageUrl, pageName, localPagePath, localReadFilePath, detailPageInfo, webPageText);
                            }
                            break;
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                this.InvokeAppendLogText("读取详情页信息出错. PageUrl = " + pageUrl, LogLevelType.Error, true);
                return false;
            }
        }
        private bool ExportDetailPage(IListSheet listSheet, DetailExportWriter ew, int detailPageIndex, string pageUrl, string localReadFilePath, Proj_Detail_MultiLine detailPageInfo)
        {
            try
            {
                if (this.CheckGiveUpGrabPage(listSheet, pageUrl, detailPageIndex))
                {
                    return true;
                }
                else
                {
                    string webPageText = this.ReadFile(localReadFilePath);
                    List<Dictionary<string, string>> fieldValueList = this.ReadDetailFieldValueListFromFile(localReadFilePath);

                    foreach (Dictionary<string, string> fieldValues in fieldValueList)
                    {
                        ew.SaveDetailFieldValue(listSheet, this.ColumnNameToIndex, fieldValues, detailPageIndex, pageUrl);
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                this.InvokeAppendLogText("写入到输出文件出错. PageUrl = " + pageUrl + " " + ex.Message, LogLevelType.Error, true);
                return false;
            }
        }
        private bool ExportDetailPage(IListSheet listSheet, DetailExportWriter ew, int detailPageIndex, string pageUrl, string localReadFilePath, Proj_Detail_SingleLine detailPageInfo)
        {
            try
            {
                if (this.CheckGiveUpGrabPage(listSheet, pageUrl, detailPageIndex))
                {
                    return true;
                }
                else
                {
                    string webPageText = this.ReadFile(localReadFilePath);
                    Dictionary<string, string> fieldValues = this.ReadDetailFieldValueFromFile(localReadFilePath);
                    ew.SaveDetailFieldValue(listSheet, this.ColumnNameToIndex, fieldValues, detailPageIndex, pageUrl);
                    return true;
                }
            }
            catch (Exception ex)
            {
                this.InvokeAppendLogText("写入到输出文件出错. PageUrl = " + pageUrl + " " + ex.Message, LogLevelType.Error, true);
                return false;
            }
        }

        private string GetSourceFileDir(Proj_ListPageInfo listPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(listPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir,  this.Project.Name + "\\SourceFile\\List");
            }
            else
            {
                return Path.Combine(listPageInfo.SaveFileDirectory, "List");
            }
        }

        private string GetSourceFileDir(Proj_Detail_SingleLine detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\SourceFile\\Detail");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "Detail");
            }
        }

        private string GetSourceFileDir(Proj_CustomProgram detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\SourceFile\\Detail");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "Detail");
            }
        }

        private string GetExportDir(Proj_Detail_SingleLine detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\Export");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "Export");
            }
        }

        private string GetExportDir(Proj_CustomProgram detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, "Data\\" + this.Project.Name + "\\Export");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "Export");
            }
        }

        private string GetExportDir(Proj_Detail_MultiLine detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\Export");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "Export");
            }
        } 

        public string GetListSourceFileDir()
        {
            switch (this.Project.ListNavigateType)
            {
                case ListNavigateType.AutoUrlType:
                    return this.GetSourceFileDir((Proj_ListPageInfo)this.Project.ListPageInfoObject);
                default:
                    return "";
            }
        }

        public string GetDetailSourceFileDir()
        {
            switch (this.Project.DetailGrabType)
            {
                case DetailGrabType.MultiLineType:
                    return this.GetSourceFileDir((Proj_Detail_MultiLine)this.Project.DetailGrabInfoObject);
                case DetailGrabType.SingleLineType:
                    return this.GetSourceFileDir((Proj_Detail_SingleLine)this.Project.DetailGrabInfoObject);
                case DetailGrabType.ProgramType:
                    return this.GetSourceFileDir((Proj_CustomProgram)this.Project.DetailGrabInfoObject);
                default:
                    return "";
            }
        }

        public string GetExportDir()
        {
            switch (this.Project.DetailGrabType)
            {
                case DetailGrabType.MultiLineType:
                    return this.GetExportDir((Proj_Detail_MultiLine)this.Project.DetailGrabInfoObject);
                case DetailGrabType.SingleLineType:
                    return this.GetExportDir((Proj_Detail_SingleLine)this.Project.DetailGrabInfoObject);
                case DetailGrabType.ProgramType:
                    return this.GetExportDir((Proj_CustomProgram)this.Project.DetailGrabInfoObject);
                default:
                    return "";
            }
        }

        public string GetReadFileDir()
        {
            switch (this.Project.DetailGrabType)
            {
                case DetailGrabType.MultiLineType:
                    return this.GetReadFileDir((Proj_Detail_MultiLine)this.Project.DetailGrabInfoObject);
                case DetailGrabType.SingleLineType:
                    return this.GetReadFileDir((Proj_Detail_SingleLine)this.Project.DetailGrabInfoObject);
                default:
                    return "";
            }
        }

        private string GetReadFileDir(Proj_Detail_SingleLine detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\SourceFile\\ReadDetail");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "ReadDetail");
            }
        }

        private string GetSourceFileDir(Proj_Detail_MultiLine detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\SourceFile\\Detail");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "Detail");
            }
        }

        private string GetReadFileDir(Proj_Detail_MultiLine detailPageInfo)
        {
            if (CommonUtil.IsNullOrBlank(detailPageInfo.SaveFileDirectory))
            {
                return Path.Combine(OutputFileDir, this.Project.Name + "\\SourceFile\\ReadDetail");
            }
            else
            {
                return Path.Combine(detailPageInfo.SaveFileDirectory, "ReadDetail");
            }
        }

        private bool ExistFile(string localPagePath)
        {
            try
            {
                bool isExist = File.Exists(localPagePath);
                string np = localPagePath + ".txt";
                if (File.Exists(np))
                {
                    File.Move(np, localPagePath);
                    isExist = true;
                }
                return isExist;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string ReadFile(string filePath)
        {  
            TextReader tr = null;
            try
            {
                tr = new StreamReader(filePath);
                string fileText = tr.ReadToEnd();
                return fileText;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (tr != null)
                {
                    tr.Dispose();
                    tr = null;
                }
            }
        }

        public string GetReadFilePath(string pageUrl, string dir)
        {
            return GetFilePath(pageUrl + ".txt", dir);
        }


        public string GetFilePath(string pageUrl, string dir)
        {
            try
            {
                string fileName = CommonUtil.ProcessFileName(pageUrl, "_");
                string filePath = Path.Combine(dir, fileName);
                return filePath;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SaveFile(string fileText, string localPagePath, Encoding encoding)
        {
            if (CommonUtil.IsNullOrBlank(fileText))
            {
                throw new Exception("空文件.");
            }
            else
            {

                CommonUtil.CreateFileDirectory(localPagePath);
                StreamWriter sw = null;
                try
                {
                    sw = new StreamWriter(localPagePath, false, encoding);
                    sw.Write(fileText);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (sw != null)
                    {
                        sw.Dispose();
                        sw = null;
                    }
                }
            }
        }

        private void SaveFile(byte[] data, string localPagePath)
        {
            if (data == null && data.Length>0)
            {
                throw new Exception("空文件. LocalPagePath = " + localPagePath);
            }
            else
            {
                CommonUtil.CreateFileDirectory(localPagePath);
                FileStream fs = null;
                try
                { 
                    fs = new FileStream(localPagePath, FileMode.Create, FileAccess.Write);
                    fs.Write(data, 0, data.Length);
                    fs.Flush();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                        fs.Dispose();
                        fs = null;
                    }
                }
            }
        }

        private void GetDetailHtmlInfo(string pageUrl, string pageName, string localPagePath, string localReadFilePath, Proj_Detail_MultiLine detailPageInfo, string webPageHtml)
        {
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);

            string[] blockPathSections = detailPageInfo.MultiCtrlPath.Split(new string[] { SysConfig.XPathSplit }, StringSplitOptions.RemoveEmptyEntries);
            List<HtmlNode> allBlockNodes = new List<HtmlNode>();
            allBlockNodes.Add(htmlDoc.DocumentNode);
            foreach (string blockPath in blockPathSections)
            {
                if (blockPath != SysConfig.XPathSplit)
                {
                    List<HtmlNode> allNewBlockNodes = new List<HtmlNode>();
                    foreach (HtmlNode parentNode in allBlockNodes)
                    {
                        HtmlNodeCollection children = parentNode.SelectNodes(blockPath);
                        if (children != null)
                        {
                            allNewBlockNodes.AddRange(children);
                        }
                    }
                    allBlockNodes = allNewBlockNodes;
                }
            }

            List<Dictionary<string, string>> filedValuesList = new List<Dictionary<string, string>>();
            //foreach (HtmlNode relativeNode in allBlockNodes)
            for (int i = 0; i < allBlockNodes.Count; i++)
            {
                HtmlNode relativeNode = allBlockNodes[i];
                Dictionary<string, string> fieldValues = new Dictionary<string, string>();
                foreach (Proj_Detail_Field field in detailPageInfo.Fields)
                {
                    HtmlNode baseNode = field.IsAbsolute ? htmlDoc.DocumentNode : relativeNode;

                    HtmlNode node = GetHtmlNode(baseNode, field.Path);
                    string value = node == null
                        ? ""
                        : (field.NeedAllHtml ? node.OuterHtml : (CommonUtil.IsNullOrBlank(field.AttributeName) ? node.InnerText : node.GetAttributeValue(field.AttributeName, "")));
                    fieldValues.Add(field.Name, value);
                }

                fieldValues.Add(SysConfig.DetailPageNameFieldName, pageName);
                fieldValues.Add(SysConfig.DetailPageUrlFieldName, pageUrl);

                filedValuesList.Add(fieldValues);
            }

            this.SaveDetailFieldValueToFile(filedValuesList, localReadFilePath);
        }

        private void GetDetailJsonInfo(string pageUrl, string pageName, string localPagePath, string localReadFilePath, Proj_Detail_MultiLine detailPageInfo, string webPageText)
        {
            string blockPath = detailPageInfo.MultiCtrlPath;
            Object jt = null;
            if (CommonUtil.IsNullOrBlank(blockPath))
            {
                jt = JArray.Parse(webPageText);
            }
            else
            {
                JObject rootJo = JObject.Parse(webPageText);
                jt = rootJo.SelectToken(blockPath);
            }
            if (jt == null)
            {
                throw new Exception("找不到路径" + blockPath + "的值. JSON = " + webPageText);
            }
            else if (!(jt is JArray))
            {
                throw new Exception("找到了" + blockPath + "的值, 但是它不是数组. JSON = " + webPageText);
            }
            else
            {
                List<Dictionary<string, string>> filedValuesList = new List<Dictionary<string, string>>();
                JArray jas = jt as JArray;
                for (int i = 0; i < jas.Count; i++)
                {
                    Dictionary<string, string> fieldValues = new Dictionary<string, string>();
                    if (jas[i] is JValue)
                    {
                        JValue jo = jas[i] as JValue;

                        foreach (Proj_Detail_Field field in detailPageInfo.Fields)
                        {
                            if (field.Name == "*")
                            {
                                fieldValues.Add(field.Name, jo.ToString());
                            }
                            else
                            {
                                fieldValues.Add(field.Name, "");
                            }
                        }
                    }
                    else if (jas[i] is JArray)
                    {
                        JArray jo = jas[i] as JArray;

                        foreach (Proj_Detail_Field field in detailPageInfo.Fields)
                        {
                            if (field.Name == "*")
                            {
                                fieldValues.Add(field.Name, jo.ToString());
                            }
                            else
                            {
                                fieldValues.Add(field.Name, "");
                            }
                        }
                    }
                    else if (jas[i] is JObject)
                    {
                        JObject jo = jas[i] as JObject;

                        foreach (Proj_Detail_Field field in detailPageInfo.Fields)
                        {
                            if (field.Name == "*")
                            {
                                fieldValues.Add(field.Name, jo.ToString());
                            }
                            else
                            {
                                JToken fieldValueJ = jo[field.Name];
                                string value = fieldValueJ == null ? "" : fieldValueJ.ToString();
                                fieldValues.Add(field.Name, value);
                            }
                        }
                    }

                    fieldValues.Add(SysConfig.DetailPageNameFieldName, pageName);
                    fieldValues.Add(SysConfig.DetailPageUrlFieldName, pageUrl);

                    filedValuesList.Add(fieldValues);
                }
                this.SaveDetailFieldValueToFile(filedValuesList, localReadFilePath);
            }
        }

        private bool GrabDetailPage(IListSheet listSheet, string pageUrl, string localPagePath, int pageIndex, Proj_Detail_MultiLine detailPageInfo,string cookie)
        {
            string pageName = DetailPageNameList[pageIndex];
            decimal intervalAfterLoaded = detailPageInfo.IntervalAfterLoaded;
            Encoding encoding = Encoding.GetEncoding(detailPageInfo.Encoding);
            try
            {
                switch (detailPageInfo.DataAccessType)
                {
                    case Proj_DataAccessType.WebBrowserHtml:
                        {
                            string webPageText = GetDetailHtmlByWebBrowser(pageUrl, intervalAfterLoaded, detailPageInfo.RequestTimeout);
                            this.SaveFile(webPageText, localPagePath, encoding);
                        }
                        break;
                    case Proj_DataAccessType.WebRequestHtml:
                        {
                            string webPageText = GetTextByRequest(pageUrl, detailPageInfo.NeedProxy, intervalAfterLoaded, detailPageInfo.RequestTimeout, encoding, cookie);
                            this.SaveFile(webPageText, localPagePath, encoding);
                        }
                        break;
                    case Proj_DataAccessType.WebRequestJson:
                        {
                            string webPageText = GetTextByRequest(pageUrl, detailPageInfo.NeedProxy, intervalAfterLoaded, detailPageInfo.RequestTimeout, encoding, cookie);
                            this.SaveFile(webPageText, localPagePath, encoding);
                        }
                        break;
                    case Proj_DataAccessType.WebRequestFile:
                        {
                            byte[] data = GetFileByRequest(pageUrl, detailPageInfo.NeedProxy, intervalAfterLoaded, detailPageInfo.RequestTimeout);
                            this.SaveFile(data, localPagePath);
                        }
                        break;
                }
                return true;
            }
            catch (Exception ex)
            {
                if (!detailPageInfo.AllowAutoGiveUp || !GiveUpGrabPage(listSheet, pageUrl, pageIndex, ex))
                {
                    this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 抓取出错. PageUrl = " + pageUrl + ". " + ex.Message, LogLevelType.Error, true);
                    if (detailPageInfo.NeedProxy && detailPageInfo.AutoAbandonDisableProxy)
                    {
                        ProxyServer ps = ProxyServers.Abandon(this.Project.Id);
                        this.InvokeAppendLogText("已经放弃了代理服务器. ProxyServer = " + ps.IP + ":" + ps.Port.ToString(), LogLevelType.Error, true);
                    }
                    return false;
                }
                else
                {
                    this.InvokeAppendLogText("线程" + Thread.CurrentThread.ManagedThreadId.ToString() + ": 放弃抓取, 抓取详情页数据出错. PageUrl = " + pageUrl + ". " + ex.Message, LogLevelType.Error, true);
                    return true;
                }
            }
        }
        #endregion          

        #region 创建Excel文件,包含详情页地址
        public List<Proj_Detail_Field> GetOutputFields(List<Proj_Detail_Field> listPageFields, List<Proj_Detail_Field> detailPageFields)
        {
            List<Proj_Detail_Field> newAllFields = new List<Proj_Detail_Field>();
            Proj_Detail_Field urlField = new Proj_Detail_Field();
            urlField.Name = SysConfig.DetailPageUrlFieldName;
            urlField.ColumnWidth = 20;
            newAllFields.Add(urlField);
            if (listPageFields != null)
            {
                newAllFields.AddRange(listPageFields.ToArray());
            }
            if (detailPageFields != null)
            {
                newAllFields.AddRange(detailPageFields.ToArray());
            }
            return newAllFields;
        }
        #endregion

        #region 判断列表DB是否已经存在
        private bool NeedCreateListDB(string dbFilePath)
        {
            if (!AutoRun && File.Exists(dbFilePath))
            {
                if (MessageBox.Show("列表DB文件已经存在，是否继续执行上次未完成的任务?", "确认", MessageBoxButtons.OKCancel)
                    == DialogResult.OK)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }
        #endregion

        #region 为DB中的list表增加列
        private void AddColumnToDBList(List<string> newColumns, IListSheet listSheet)
        {
        }
        #endregion

        #region 将excel文件中的list复制到db中
        private IListSheet CopyListToDBFromExcel(string excelFilePath, string dbFilePath)
        {
            ExcelReader excelReader = new ExcelReader(excelFilePath, "List");

            //判断excel中必须的行是否存在
            Dictionary<string, int> columnToIndexs = excelReader.ColumnNameToIndex;
            List<string> excelSysColumnList = new List<string>(); 
            excelSysColumnList.Add(SysConfig.DetailPageUrlFieldName);
            excelSysColumnList.Add(SysConfig.DetailPageNameFieldName);
            excelSysColumnList.Add(SysConfig.DetailPageCookieFieldName);
            excelSysColumnList.Add(SysConfig.GrabStatusFieldName);
            excelSysColumnList.Add(SysConfig.GiveUpGrabFieldName);
            foreach (string columnName in excelSysColumnList)
            {
                if (!columnToIndexs.ContainsKey(columnName))
                {
                    throw new Exception("导入的详情页地址Excel中没有包含列: " + columnName);
                }
            }

            //获取Excel中的记录行
            List<Dictionary<string, string>> allExcelRows = new List<Dictionary<string, string>>();
            int excelRowCount = excelReader.GetRowCount();
            for (int i = 0; i < excelRowCount; i++)
            {
                Dictionary<string, string> f2vs = excelReader.GetFieldValues(i);
                string giveUpStr = f2vs[SysConfig.GiveUpGrabFieldName];
                if (CommonUtil.IsNullOrBlank(giveUpStr))
                {
                    f2vs[SysConfig.GiveUpGrabFieldName] = "N";
                }
                else if(giveUpStr == "是")
                {
                    f2vs[SysConfig.GiveUpGrabFieldName] = "Y";
                }
                f2vs[SysConfig.ListPageIndexFieldName] = i.ToString();
                allExcelRows.Add(f2vs);
            }
            excelReader.Close();

            //增加用户自定义列
            List<string> dbSysColumnList = new List<string>();
            dbSysColumnList.AddRange(excelSysColumnList.ToArray());
            dbSysColumnList.Add(SysConfig.ListPageIndexFieldName);

            IListSheet listSheet = new ListSheetInDB(dbFilePath);
            List<string> columns = new List<string>();
            foreach (string column in columnToIndexs.Keys)
            {
                if (!dbSysColumnList.Contains(column))
                {
                    columns.Add(column);
                }
            }
            listSheet.AddColumns(columns);

            //拷贝数据记录
            if (allExcelRows.Count > 0)
            {
                listSheet.CopyToListSheet(allExcelRows, columnToIndexs, excelSysColumnList);
            }
            return listSheet;
        }
        #endregion

        #region 获取ListSheet连接
        private IListSheet GetDBListSheet(string dbFilePath)
        {
            IListSheet listSheet = new ListSheetInDB(dbFilePath);
            return listSheet;
        }
        #endregion

        #region 在List的DB文件中增加用户定义的项目中包含的列 
        private void InitCustomColumnsToListSheet(IListSheet listSheet)
        {
            List<string> fields = new List<string>();

            if (this.Project.ListPageInfoObject != null && this.Project.ListPageInfoObject.Fields != null)
            {
                foreach(Proj_Detail_Field f in this.Project.ListPageInfoObject.Fields)
                {
                    fields.Add(f.Name);
                } 
            }
            listSheet.AddColumns(fields);
        } 
        #endregion

        #region 创建DB文件
        public IListSheet CreateListSheet(string excelFilePath, string dbFilePath, string newListDBFilePath, ListNavigateType listNavigateType)
        {
            CommonUtil.CreateFileDirectory(dbFilePath);
            IListSheet listSheet = null;
            if (this.NeedCreateListDB(dbFilePath))
            {
                File.Copy(newListDBFilePath, dbFilePath, true);
                if (listNavigateType == ListNavigateType.ManualType)
                {
                    //从excel文件中，导入列表页地址
                    listSheet = CopyListToDBFromExcel(excelFilePath, dbFilePath);
                    GC.Collect();
                }
                else
                {
                    listSheet = this.GetDBListSheet(dbFilePath);
                    //增加用户自定义列
                    InitCustomColumnsToListSheet(listSheet);
                }
            }
            else
            {
                listSheet = this.GetDBListSheet(dbFilePath); 
            }

            return listSheet;
        }
        #endregion   

        #region 列名序号对应
        private Dictionary<string, int> _ColumnNameToIndex = null;
        public Dictionary<string, int> ColumnNameToIndex
        {
            get
            {
                if (_ColumnNameToIndex == null)
                {
                    List<Proj_Detail_Field> fields = new List<Proj_Detail_Field>();
                    Dictionary<string, int> columnNameToIndex = new Dictionary<string, int>();

                    //columnNameToIndex.Add(SysConfig.ListPageIndexFieldName, SysConfig.ListPageIndexFieldIndex);
                    columnNameToIndex.Add(SysConfig.DetailPageUrlFieldName, SysConfig.DetailPageUrlFieldIndex);
                    columnNameToIndex.Add(SysConfig.DetailPageNameFieldName, SysConfig.DetailPageNameFieldIndex);
                    columnNameToIndex.Add(SysConfig.DetailPageCookieFieldName, SysConfig.DetailPageCookieFieldIndex);
                    columnNameToIndex.Add(SysConfig.GrabStatusFieldName, SysConfig.GrabStatusFieldIndex);
                    columnNameToIndex.Add(SysConfig.GiveUpGrabFieldName, SysConfig.GiveUpGrabFieldIndex);
                    //columnNameToIndex.Add(SysConfig.SucceedRowFieldName, SysConfig.SucceedRowFieldIndex);

                    if (this.Project.ListPageInfoObject != null && this.Project.ListPageInfoObject.Fields != null)
                    {
                        fields.AddRange(this.Project.ListPageInfoObject.Fields.ToArray());
                    }
                    if (this.Project.DetailGrabType != DetailGrabType.NoneDetailPage)
                    {
                        fields.AddRange(this.Project.DetailGrabInfoObject.Fields.ToArray());
                    }

                    for (int i = 0; i < fields.Count; i++)
                    {
                        int index = i + SysConfig.SystemColumnCount;
                        Proj_Detail_Field field = fields[i];
                        columnNameToIndex.Add(field.Name, index);
                    }
                    _ColumnNameToIndex = columnNameToIndex;
                }
                return _ColumnNameToIndex;
            }
        }
        #endregion
         
        #region 设置列宽
        private void SetColumnWidth(ISheet sheet, int columnIndex, int width)
        {
            sheet.SetColumnWidth(columnIndex, width * 256);
        }
        #endregion

        #region 设置列宽
        private void SetCellValue(IRow row, int columnIndex, string value)
        {
            row.CreateCell(columnIndex).SetCellValue(value);
        }
        #endregion 

        #region 保存Excel文件到硬盘 放弃使用的方法
        /*
        public void SaveExcelToDisk( string filePath)
        { 
            CommonUtil.CreateFileDirectory(filePath);
             
            FileStream fs = null;
            try
            {
                fs = File.Open(filePath, FileMode.Create);
                //wk.Write(fs); 
            }
            catch (Exception ex)
            {
                throw new Exception("保存Excel文件到硬盘失败. FilePath = " + filePath, ex);
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                    fs.Dispose();
                }
            }
        }
         */
        #endregion

        #region 写入Excel文件
        public void SaveListFieldValueToDB(IListSheet sheet, Dictionary<string, string> fieldValues)
        {
            sheet.AddListRow(fieldValues); 
        }

        public void CheckPageUrlByExcel(ISheet listSheet, int rowIndex, string pageUrl)
        {
            IRow listRow = listSheet.GetRow(rowIndex + SysConfig.ColumnTitleRowCount);
            string urlCellValue = listRow.GetCell(SysConfig.DetailPageUrlFieldIndex).ToString();
            if (urlCellValue != pageUrl)
            { 
                throw new Exception("第" + rowIndex.ToString() + "行地址不匹配. Url_1 = " + pageUrl + ", Url_2 = " + urlCellValue);
            }
        }

        public void SaveDetailFieldValueToExcel(ISheet listSheet, ISheet detailSheet, Dictionary<string, string> fieldValues, int rowIndex, string pageUrl)
        {
            IRow listRow = listSheet.GetRow(rowIndex + SysConfig.ColumnTitleRowCount);
            string urlCellValue = listRow.GetCell(SysConfig.DetailPageUrlFieldIndex).ToString();
            if (urlCellValue == pageUrl)
            {
                IRow detailRow = detailSheet.CreateRow(detailSheet.LastRowNum + 1);
                foreach (string columnName in this.ColumnNameToIndex.Keys)
                {
                    int index = this.ColumnNameToIndex[columnName];
                    ICell cell = listRow.GetCell(index);
                    if (cell != null)
                    {
                        detailRow.CreateCell(index).SetCellValue(cell.ToString());
                    }
                }

                foreach (string fieldName in fieldValues.Keys)
                {
                    int index = this.ColumnNameToIndex[fieldName];
                    string value = fieldValues[fieldName];
                    ICell cell = detailRow.CreateCell(index);
                    cell.SetCellValue(value);
                }
            }
            else
            {
                throw new Exception("第" + rowIndex.ToString() + "行地址不匹配. Url_1 = " + pageUrl + ", Url_2 = " + urlCellValue);
            }
        }
        #endregion 

        #region 保存读取信息结果
        public void SaveDetailFieldValueToFile(Dictionary<string, string> fieldValues, string localReadFilePath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml("<?xml version=\"1.0\" encoding=\"UTF-8\"?><DetailPage></DetailPage>");
            XmlElement root = xmlDoc.DocumentElement;
            foreach (string f in fieldValues.Keys)
            {
                string value = fieldValues[f];
                XmlNode node = xmlDoc.CreateElement("Field");
                root.AppendChild(node);

                XmlAttribute fieldAttr = xmlDoc.CreateAttribute("Key");
                fieldAttr.Value = f;
                node.Attributes.Append(fieldAttr);

                XmlAttribute valueAttr = xmlDoc.CreateAttribute("Value");
                valueAttr.Value = value;
                node.Attributes.Append(valueAttr);
            }
            this.SaveFile(xmlDoc.OuterXml, localReadFilePath, Encoding.UTF8);
        }
        #endregion

        #region 读取信息结果
        public Dictionary<string, string> ReadDetailFieldValueFromFile(string localReadFilePath)
        {
            string xml = ReadFile(localReadFilePath);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xml);
            XmlElement root = xmlDoc.DocumentElement;
            Dictionary<string, string> fieldValues = new Dictionary<string, string>();
            XmlNodeList nodes = root.ChildNodes;

            foreach (XmlNode fNode in nodes)
            {
                string f = fNode.Attributes["Key"].Value;
                string v = fNode.Attributes["Value"].Value;
                fieldValues.Add(f, v);
            }
            return fieldValues;
        } 
        public List<Dictionary<string, string>> ReadDetailFieldValueListFromFile(string localReadFilePath)
        {
            string xml = ReadFile(localReadFilePath);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xml);
            XmlElement root = xmlDoc.DocumentElement;
            List<Dictionary<string, string>> fieldValueList = new List<Dictionary<string, string>>();
            XmlNodeList fvNodes = root.ChildNodes;

            foreach (XmlNode fvNode in fvNodes)
            {
                XmlNodeList fNodes = fvNode.ChildNodes;
                Dictionary<string, string> fieldValues = new Dictionary<string, string>();
                foreach (XmlNode fNode in fNodes)
                {
                    string f = fNode.Attributes["Key"].Value;
                    string v = fNode.Attributes["Value"].Value;
                    fieldValues.Add(f, v);
                }
                fieldValueList.Add(fieldValues);
            }
            return fieldValueList;
        }
        #endregion

        #region 保存读取信息结果
        public void SaveDetailFieldValueToFile(List<Dictionary<string, string>> fieldValuesList, string localReadFilePath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml("<?xml version=\"1.0\" encoding=\"UTF-8\"?><DetailPages></DetailPages>");
            XmlElement root = xmlDoc.DocumentElement;
            for (int i = 0; i < fieldValuesList.Count; i++)
            {
                Dictionary<string, string> fieldValues = fieldValuesList[i];
                XmlNode pNode = xmlDoc.CreateElement("DetailPage");
                root.AppendChild(pNode);

                foreach (string f in fieldValues.Keys)
                {
                    string value = fieldValues[f];
                    XmlNode node = xmlDoc.CreateElement("Field");
                    pNode.AppendChild(node);

                    XmlAttribute fieldAttr = xmlDoc.CreateAttribute("Key");
                    fieldAttr.Value = f;
                    node.Attributes.Append(fieldAttr);

                    XmlAttribute valueAttr = xmlDoc.CreateAttribute("Value");
                    valueAttr.Value = value;
                    node.Attributes.Append(valueAttr);
                }
            }
            this.SaveFile(xmlDoc.OuterXml, localReadFilePath ,Encoding.UTF8);
        }
        #endregion 

        #region 抓取进程
        private Thread _GrabThread;
        /// <summary>
        /// 抓取进程
        /// </summary>
        private Thread GrabThread
        {
            get
            {
                return _GrabThread;
            }
            set
            {
                _GrabThread = value;
            }
        }
        #endregion

        #region 显示网页
        public void InvoceShowWebPage(string url)
        {
            this.Invoke(new GrabInvokeDelegate(this.ShowWebPage), url);
        }
        private void ShowWebPage(string url)
        { 
            if (!Uri.IsWellFormedUriString(url, UriKind.Absolute))
            {
                Uri newUri = new Uri(this.webBrowserMain.Url, url);
                url = newUri.AbsoluteUri;
            }
            this.webBrowserMain.Navigate(url);
            this.textBoxPageUrl.Text = url;
        }
        #endregion

        #region 释放浏览器 
        private delegate void DisposeWebBrowserInvokeDelegate();
        public void InvokeDisposeWebBrowser()
        {
            this.Invoke(new DisposeWebBrowserInvokeDelegate(this.DisposeWebBrowser));
        }
        private void DisposeWebBrowser()
        {
            this.webBrowserMain.Dispose();
        }
        #endregion

        #region 显示网页
        private delegate void ScrollWebPageInvokeDelegate(int toY);
        private void InvokeScrollWebPage(int toY)
        {
            this.Invoke(new ScrollWebPageInvokeDelegate(this.ScrollWebPage), toY);
        }
        private void ScrollWebPage(int toY)
        {
            this.webBrowserMain.Document.Window.ScrollTo(0, toY);
        }
        #endregion

        #region 获取网页高度
        private delegate int GetWebPageHeightInvokeDelegate();
        private int InvokeGetWebPageHeight()
        {
            return (int)this.Invoke(new GetWebPageHeightInvokeDelegate(this.GetWebPageHeight));
        }
        private int GetWebPageHeight()
        {
            return this.webBrowserMain.Document.Body.OffsetRectangle.Bottom;
        }
        #endregion

        #region 关闭
        public bool Close()
        {
            if (this.GrabThread != null && this.IsGrabing)
            {
                if (AutoRun || CommonUtil.Confirm("提示", "正在执行抓取. 确定要关闭吗?"))
                {
                    try
                    {
                        this.GrabThread.Abort();
                        this.GrabThread = null;
                        if (this.AllGrabDetailThreads != null)
                        {
                            foreach (Thread thread in this.AllGrabDetailThreads)
                            {
                                if (thread != null && thread.IsAlive)
                                {
                                    thread.Abort();
                                }
                            }
                            this.AllGrabDetailThreads.Clear();
                        }
                    }
                    catch (Exception ex)
                    {
                        this.InvokeAppendLogText("关闭任务时发生错误. " + ex.Message, LogLevelType.Fatal, true);
                        if (!AutoRun)
                        {
                            CommonUtil.Alert("错误", ex.Message);
                        }
                    }
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }
        #endregion
        
        #region 转到按钮
        private void buttonShowPage_Click(object sender, EventArgs e)
        {
            ShowWebPage();
        }
        #endregion

        #region 开始抓取按钮

        private bool _AllowRunGrabList = true;
        private bool _AllowRunGrabDetail = true;
        private bool _AllowRunRead = true;
        private bool _AllowRunExport = true;
        private bool _AllowRunCustom = true;

        private void buttonBeginGrab_Click(object sender, EventArgs e)
        {
            DoGrab();
        }
        private void DoGrab()
        {
            if (AutoRun)
            {
                BeginGrab();
            }
            else
            {
                FormTaskSetting taskSettingForm = new FormTaskSetting();
                if (taskSettingForm.ShowDialog() == DialogResult.OK)
                {
                    Dictionary<string, object> setting = taskSettingForm.Setting;
                    this._AllowRunGrabList = (bool)setting["RunGrabList"];
                    this._AllowRunGrabDetail = (bool)setting["RunGrabDetail"];
                    this._AllowRunRead = (bool)setting["RunRead"];
                    this._AllowRunExport = (bool)setting["RunExport"];
                    this._AllowRunCustom = (bool)setting["RunCustom"];

                    BeginGrab();
                }
            }
        }

        private void BeginGrab()
        {
            this.textBoxPageUrl.ReadOnly = true;
            this.buttonBeginGrab.Enabled = false;
            this.buttonShowPage.Enabled = false;

            Thread thread = new Thread(new ThreadStart(Grab));
            this.GrabThread = thread;
            IsGrabing = true;
            thread.Start();
        }
        #endregion

        #region 初始化之后
        protected void AfterLoad()
        {
            if (this.Project.LoginPageInfoObject != null)
            {
                Proj_LoginPageInfo loginObj = (Proj_LoginPageInfo)this.Project.LoginPageInfoObject;
                this.ShowWebPage(loginObj.LoginUrl);
            }
        }
        #endregion

        #region 获取浏览器控件
        public WebBrowser GetWebBrowser()
        {
            return this.webBrowserMain;
        }
        #endregion

        #region 给控件赋值
        private delegate void SetControlValueByIdInvokeDelegate(string id, string attributeName, string attributeValue);
        public void InvokeSetControlValueById(string id, string attributeName, string attributeValue)
        {
            this.Invoke(new SetControlValueByIdInvokeDelegate(SetControlValueById), new object[] { id, attributeName, attributeValue });
        }
        private void SetControlValueById(string id, string attributeName, string attributeValue)
        { 
            HtmlElement element = this.webBrowserMain.Document.GetElementById(id);
            element.SetAttribute(attributeName, attributeValue);
        }
        #endregion 

        #region 读取下载下来的html
        public HtmlAgilityPack.HtmlDocument GetLocalHtmlDocument(IListSheet listSheet, int pageIndex)
        {
            string pageUrl = listSheet.PageUrlList[pageIndex];
            string pageSourceDir = this.GetDetailSourceFileDir();
            string localFilePath = this.GetFilePath(pageUrl, pageSourceDir);
            TextReader tr = null;

            try
            {
                tr = new StreamReader(localFilePath);
                string webPageHtml = tr.ReadToEnd();
                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                htmlDoc.LoadHtml(webPageHtml);
                return htmlDoc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (tr != null)
                {
                    tr.Close();
                    tr.Dispose();
                }
            }
        }
        #endregion
    }
}
