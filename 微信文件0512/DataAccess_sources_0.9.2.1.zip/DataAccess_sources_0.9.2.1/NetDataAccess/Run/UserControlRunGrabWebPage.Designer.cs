﻿namespace NetDataAccess.Run
{
    partial class UserControlRunGrabWebPage
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxPageUrl = new System.Windows.Forms.TextBox();
            this.labelWebPageUrl = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.buttonBeginGrab = new System.Windows.Forms.Button();
            this.buttonShowPage = new System.Windows.Forms.Button();
            this.tabPageGrabLog = new System.Windows.Forms.TabPage();
            this.textBoxGrabLog = new System.Windows.Forms.TextBox();
            this.panelMain = new System.Windows.Forms.Panel();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageWebBrowser = new System.Windows.Forms.TabPage();
            this.webBrowserMain = new System.Windows.Forms.WebBrowser();
            this.textBoxStatus = new System.Windows.Forms.TextBox();
            this.panelTop.SuspendLayout();
            this.tabPageGrabLog.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageWebBrowser.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxPageUrl
            // 
            this.textBoxPageUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxPageUrl.Location = new System.Drawing.Point(40, 4);
            this.textBoxPageUrl.Name = "textBoxPageUrl";
            this.textBoxPageUrl.Size = new System.Drawing.Size(692, 21);
            this.textBoxPageUrl.TabIndex = 1;
            this.textBoxPageUrl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxPageUrl_KeyDown);
            // 
            // labelWebPageUrl
            // 
            this.labelWebPageUrl.AutoSize = true;
            this.labelWebPageUrl.Location = new System.Drawing.Point(4, 8);
            this.labelWebPageUrl.Name = "labelWebPageUrl";
            this.labelWebPageUrl.Size = new System.Drawing.Size(35, 12);
            this.labelWebPageUrl.TabIndex = 0;
            this.labelWebPageUrl.Text = "地址:";
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.buttonBeginGrab);
            this.panelTop.Controls.Add(this.buttonShowPage);
            this.panelTop.Controls.Add(this.textBoxPageUrl);
            this.panelTop.Controls.Add(this.labelWebPageUrl);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(955, 29);
            this.panelTop.TabIndex = 5;
            // 
            // buttonBeginGrab
            // 
            this.buttonBeginGrab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBeginGrab.Location = new System.Drawing.Point(819, 4);
            this.buttonBeginGrab.Name = "buttonBeginGrab";
            this.buttonBeginGrab.Size = new System.Drawing.Size(75, 23);
            this.buttonBeginGrab.TabIndex = 4;
            this.buttonBeginGrab.Text = "开始抓取";
            this.buttonBeginGrab.UseVisualStyleBackColor = true;
            this.buttonBeginGrab.Click += new System.EventHandler(this.buttonBeginGrab_Click);
            // 
            // buttonShowPage
            // 
            this.buttonShowPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonShowPage.Location = new System.Drawing.Point(738, 4);
            this.buttonShowPage.Name = "buttonShowPage";
            this.buttonShowPage.Size = new System.Drawing.Size(75, 23);
            this.buttonShowPage.TabIndex = 3;
            this.buttonShowPage.Text = "转到";
            this.buttonShowPage.UseVisualStyleBackColor = true;
            this.buttonShowPage.Click += new System.EventHandler(this.buttonShowPage_Click);
            // 
            // tabPageGrabLog
            // 
            this.tabPageGrabLog.Controls.Add(this.textBoxGrabLog);
            this.tabPageGrabLog.Controls.Add(this.textBoxStatus);
            this.tabPageGrabLog.Location = new System.Drawing.Point(4, 22);
            this.tabPageGrabLog.Name = "tabPageGrabLog";
            this.tabPageGrabLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGrabLog.Size = new System.Drawing.Size(947, 502);
            this.tabPageGrabLog.TabIndex = 1;
            this.tabPageGrabLog.Text = "进度";
            this.tabPageGrabLog.UseVisualStyleBackColor = true;
            // 
            // textBoxGrabLog
            // 
            this.textBoxGrabLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxGrabLog.Font = new System.Drawing.Font("宋体", 9F);
            this.textBoxGrabLog.Location = new System.Drawing.Point(3, 24);
            this.textBoxGrabLog.MaxLength = 3276700;
            this.textBoxGrabLog.Multiline = true;
            this.textBoxGrabLog.Name = "textBoxGrabLog";
            this.textBoxGrabLog.ReadOnly = true;
            this.textBoxGrabLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxGrabLog.Size = new System.Drawing.Size(941, 475);
            this.textBoxGrabLog.TabIndex = 1;
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.tabControlMain);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 29);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(955, 528);
            this.panelMain.TabIndex = 3;
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageWebBrowser);
            this.tabControlMain.Controls.Add(this.tabPageGrabLog);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(955, 528);
            this.tabControlMain.TabIndex = 1;
            // 
            // tabPageWebBrowser
            // 
            this.tabPageWebBrowser.Controls.Add(this.webBrowserMain);
            this.tabPageWebBrowser.Location = new System.Drawing.Point(4, 22);
            this.tabPageWebBrowser.Name = "tabPageWebBrowser";
            this.tabPageWebBrowser.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWebBrowser.Size = new System.Drawing.Size(947, 502);
            this.tabPageWebBrowser.TabIndex = 0;
            this.tabPageWebBrowser.Text = "浏览器";
            this.tabPageWebBrowser.UseVisualStyleBackColor = true;
            // 
            // webBrowserMain
            // 
            this.webBrowserMain.AllowWebBrowserDrop = false;
            this.webBrowserMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowserMain.Location = new System.Drawing.Point(3, 3);
            this.webBrowserMain.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowserMain.Name = "webBrowserMain";
            this.webBrowserMain.ScriptErrorsSuppressed = true;
            this.webBrowserMain.Size = new System.Drawing.Size(941, 496);
            this.webBrowserMain.TabIndex = 1;
            // 
            // textBoxStatus
            // 
            this.textBoxStatus.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxStatus.Font = new System.Drawing.Font("宋体", 9F);
            this.textBoxStatus.Location = new System.Drawing.Point(3, 3);
            this.textBoxStatus.MaxLength = 3276700;
            this.textBoxStatus.Name = "textBoxStatus";
            this.textBoxStatus.ReadOnly = true;
            this.textBoxStatus.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxStatus.Size = new System.Drawing.Size(941, 21);
            this.textBoxStatus.TabIndex = 2;
            // 
            // UserControlRunWebPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelTop);
            this.Name = "UserControlRunWebPage";
            this.Size = new System.Drawing.Size(955, 557);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.tabPageGrabLog.ResumeLayout(false);
            this.tabPageGrabLog.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.tabControlMain.ResumeLayout(false);
            this.tabPageWebBrowser.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxPageUrl;
        private System.Windows.Forms.Label labelWebPageUrl;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.TabPage tabPageGrabLog;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageWebBrowser; 
        private System.Windows.Forms.TextBox textBoxGrabLog;
        private System.Windows.Forms.Button buttonShowPage;
        private System.Windows.Forms.Button buttonBeginGrab;
        private System.Windows.Forms.WebBrowser webBrowserMain;
        private System.Windows.Forms.TextBox textBoxStatus;
    }
}
