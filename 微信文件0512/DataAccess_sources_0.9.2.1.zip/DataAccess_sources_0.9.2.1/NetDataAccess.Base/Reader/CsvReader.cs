﻿using NetDataAccess.Base.CsvHelper;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace NetDataAccess.Base.Reader
{
    /// <summary>
    /// CsvReader
    /// </summary>
    public class CsvReader : IFileReader
    {
        #region ElencyCsvFile
        private ElencyCsvFile _CsvFile = null;
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="filePath"></param>
        public CsvReader(string filePath)
        { 
            TextReader tr = null;

            try
            {
                ElencyCsvFile csvFile = new ElencyCsvFile();
                csvFile.Populate(filePath, Encoding.UTF8, true, false);
                this._CsvFile = csvFile;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally 
            {
                if (tr != null)
                {
                    tr.Close();
                    tr.Dispose();
                }
            }
        }
        #endregion

        #region GetRowCount
        public int GetRowCount()
        {
            return this._CsvFile.RecordCount;
        }
        #endregion

        #region GetFieldValues
        public Dictionary<string, string> GetFieldValues(int rowIndex)
        {
            CsvRecord row = (rowIndex >= 0 && rowIndex < this._CsvFile.RecordCount) ? this._CsvFile.Records[rowIndex] : null;
            if (row != null)
            {
                Dictionary<string, string> f2vs = new Dictionary<string, string>();
                for (int i = 0; i < row.FieldCount; i++)
                {
                    string f = this._CsvFile.Headers[i];
                    string v = row.Fields[i];
                    f2vs.Add(f, v);
                }
                return f2vs;
            }
            else
            {
                return null;
            }
        }
        #endregion
    }
}
