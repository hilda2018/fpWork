﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Base.Reader
{
    public interface IFileReader
    { 
        Dictionary<string, string> GetFieldValues(int rowIndex);

        int GetRowCount();
    }
}
