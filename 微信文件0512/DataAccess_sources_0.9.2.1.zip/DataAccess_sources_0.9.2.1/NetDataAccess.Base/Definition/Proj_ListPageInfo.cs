﻿using System;
using System.Collections.Generic;
using System.Text;
using NetDataAccess.Base.EnumTypes;

namespace NetDataAccess.Base.Definition
{
    /// <summary>
    /// 列表页设置
    /// </summary>
    public class Proj_ListPageInfo : IProj_FieldConfig
    {
        #region ListUrlFormat
        private string _ListUrlFormat;
        /// <summary>
        /// ListUrlFormat
        /// </summary>
        public string ListUrlFormat
        {
            set
            {
                _ListUrlFormat = value;
            }
            get
            {
                return _ListUrlFormat;
            }
        }
        #endregion

        #region BeginIndex
        private int _BeginIndex;
        /// <summary>
        /// BeginIndex
        /// </summary>
        public int BeginIndex
        {
            set
            {
                _BeginIndex = value;
            }
            get
            {
                return _BeginIndex;
            }
        }
        #endregion
                
        #region OneStepCount 放弃使用此属性
        /*
        private int _OneStepCount = 1;
        /// <summary>
        /// OneStepCount翻页步长（pageIndex翻页时增加多少）
        /// </summary>
        public int OneStepCount
        {
            set
            {
                _OneStepCount = value;
            }
            get
            {
                return _OneStepCount;
            }
        }
         */
        #endregion

        #region PageCountLimit
        private int _PageCountLimit = 1;
        /// <summary>
        /// PageCountLimit
        /// </summary>
        public int PageCountLimit
        {
            set
            {
                _PageCountLimit = value;
            }
            get
            {
                return _PageCountLimit;
            }
        }
        #endregion

        #region ProcessTypeAfterLoaded加载后动作
        private ProcessTypeAfterLoaded _ProcessTypeAfterLoaded;
        /// <summary>
        /// ProcessTypeAfterLoaded
        /// </summary>
        public ProcessTypeAfterLoaded ProcessTypeAfterLoaded
        {
            set
            {
                _ProcessTypeAfterLoaded = value;
            }
            get
            {
                return _ProcessTypeAfterLoaded;
            }
        }
        #endregion 

        #region DetailBlockPath
        private string _DetailBlockPath;
        /// <summary>
        /// DetailBlockPath
        /// </summary>
        public string DetailBlockPath
        {
            set
            {
                _DetailBlockPath = value;
            }
            get
            {
                return _DetailBlockPath;
            }
        }
        #endregion

        #region DetailCtrlPath
        private string _DetailCtrlPath;
        /// <summary>
        /// DetailCtrlPath
        /// </summary>
        public string DetailCtrlPath
        {
            set
            {
                _DetailCtrlPath = value;
            }
            get
            {
                return _DetailCtrlPath;
            }
        }
        #endregion

        #region DetailCtrlNameAttribute
        private string _DetailCtrlNameAttribute;
        /// <summary>
        /// DetailCtrlNameAttribute
        /// </summary>
        public string DetailCtrlNameAttribute
        {
            set
            {
                _DetailCtrlNameAttribute = value;
            }
            get
            {
                return _DetailCtrlNameAttribute;
            }
        }
        #endregion

        #region DetailNameCtrlPath
        private string _DetailNameCtrlPath;
        /// <summary>
        /// DetailNameCtrlPath
        /// </summary>
        public string DetailNameCtrlPath
        {
            set
            {
                _DetailNameCtrlPath = value;
            }
            get
            {
                return _DetailNameCtrlPath;
            }
        }
        #endregion 

        #region IntervalAfterLoaded
        private decimal _IntervalAfterLoaded;
        /// <summary>
        /// IntervalAfterLoaded
        /// </summary>
        public decimal IntervalAfterLoaded
        {
            set
            {
                _IntervalAfterLoaded = value;
            }
            get
            {
                return _IntervalAfterLoaded;
            }
        }
        #endregion

        #region AllReGrab
        private bool _AllReGrab;
        /// <summary>
        /// AllReGrab
        /// </summary>
        public bool AllReGrab
        {
            set
            {
                _AllReGrab = value;
            }
            get
            {
                return _AllReGrab;
            }
        }
        #endregion

        #region 服务器数据获取方式
        private Proj_DataAccessType _TextAccessType = Proj_DataAccessType.WebBrowserHtml;
        /// <summary>
        /// 服务器数据获取方式
        /// </summary>
        public Proj_DataAccessType TextAccessType
        {
            set
            {
                _TextAccessType = value;
            }
            get
            {
                return _TextAccessType;
            }
        }
        #endregion 
        
        #region Fields
        private List<Proj_Detail_Field> _Fields = new List<Proj_Detail_Field>();
        /// <summary>
        /// Fields
        /// </summary>
        public List<Proj_Detail_Field> Fields
        {
            set
            {
                _Fields = value;
            }
            get
            {
                return _Fields;
            }
        }
        #endregion

        #region 是否使用代理
        private bool _NeedProxy = false;
        /// <summary>
        /// 是否使用代理
        /// </summary>
        public bool NeedProxy
        {
            set
            {
                _NeedProxy = value;
            }
            get
            {
                return _NeedProxy;
            }
        }
        #endregion

        #region 自定放弃使用返回有问题的代理
        private bool _AutoAbandonDisableProxy = false;
        /// <summary>
        /// 自定放弃使用返回有问题的代理
        /// </summary>
        public bool AutoAbandonDisableProxy
        {
            set
            {
                _AutoAbandonDisableProxy = value;
            }
            get
            {
                return _AutoAbandonDisableProxy;
            }
        }
        #endregion 

        #region 文件保存位置
        private string _SaveFileDirectory = "";
        /// <summary>
        /// 文件保存位置
        /// </summary>
        public string SaveFileDirectory
        {
            get
            {
                return _SaveFileDirectory;
            }
            set
            {
                _SaveFileDirectory = value;
            }
        }
        #endregion

        #region 请求超时时间（秒）
        private int _RequestTimeout = 30;
        /// <summary>
        /// 请求超时时间（秒）
        /// </summary>
        public int RequestTimeout
        {
            get
            {
                return _RequestTimeout;
            }
            set
            {
                _RequestTimeout = value;
            }
        }
        #endregion

        #region 编码方式
        private String _Encoding = null;
        /// <summary>
        /// 编码方式
        /// </summary>
        public String Encoding
        {
            get
            {
                return _Encoding;
            }
            set
            {
                _Encoding = value;
            }
        }
        #endregion
    }
}
