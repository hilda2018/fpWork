﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms; 

namespace NetDataAccess.Base.Common
{
    /// <summary>
    /// 通用方法类
    /// 提供文件、简单类型数据的通用处理方法
    /// </summary>
    public static class CommonUtil
    {
        #region 判断字符串是否为空（null或者长度为0的字符串）
        /// <summary>
        /// 判断字符串是否为空（null或者长度为0的字符串）
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsNullOrBlank(string value)
        {
            return value == ""
                || value == null
                || (object)value == DBNull.Value;
        }
        #endregion

        #region 提示
        /// <summary>
        /// 提示
        /// </summary>
        /// <param name="title"></param>
        /// <param name="msg"></param>
        public static void Alert(string title, string msg)
        {
            MessageBox.Show(msg, title);
        }
        #endregion

        #region 确认
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="title"></param>
        /// <param name="msg"></param>
        public static bool Confirm(string title, string msg)
        {
            return MessageBox.Show(msg, title, MessageBoxButtons.OKCancel) == DialogResult.OK;
        }
        #endregion

        #region 文件名字符替换
        /// <summary>
        /// 文件名字符替换
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="replaceStr"></param>
        /// <returns></returns>
        public static string ProcessFileName(string fileName, string replaceStr)
        {
            string[] strs = new string[] { ":", ";", "/", "\\", "|", ",", "*", "?", "\"", "＜", "＞" };
            foreach (string str in strs)
            {
                fileName = fileName.Replace(str, replaceStr);
            }
            return fileName;
        }
        #endregion 

        #region 获取异常信息
        /// <summary>
        /// 获取异常信息
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public static string GetExceptionAllMessage(Exception ex)
        {
            StringBuilder errors = new StringBuilder();
            while (ex != null)
            {
                errors.AppendLine(ex.Message);
                ex = ex.InnerException;
            }
            return errors.ToString();
        }
        #endregion

        #region 递归创建路径中的文件夹
        /// <summary>
        /// 递归创建路径中的文件夹
        /// </summary>
        /// <param name="filePath"></param>
        public static void CreateFileDirectory(string filePath)
        {
            string tempPath = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(tempPath))
            {
                CreateFileDirectory(tempPath);
                Directory.CreateDirectory(tempPath);
            }
        }
        #endregion

        #region 判断文件是否在用
        public static bool IsFileInUse(string filePath)
        {
            bool inUse = true;

            FileStream fs = null;
            try
            {

                fs = new FileStream(filePath, FileMode.Open, FileAccess.Read,

                FileShare.None);

                inUse = false;
            }
            catch
            {

            }
            finally
            {
                if (fs != null)

                    fs.Close();
            }
            return inUse;//true表示正在使用,false没有使用
        }
        #endregion

        #region InitStringIndexDic
        public static Dictionary<string, int> InitStringIndexDic(string[] strs)
        {
            Dictionary<string, int> dic = new Dictionary<string, int>();
            for (int i = 0; i < strs.Length; i++)
            {
                dic.Add(strs[i], i);
            }
            return dic;
        }
        #endregion
    }
}
