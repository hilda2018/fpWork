﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Base.EnumTypes
{
    /// <summary>
    /// 数据详情页地址的生成方式
    /// </summary>
    public enum ListNavigateType
    {
        /// <summary>
        /// 自动生成列表页地址方式
        AutoUrlType, 

        /// <summary>
        /// 使用自定义程序实现返回详情页地址列表和下一页列表页地址
        /// </summary>
        ProgramType,

        /// <summary>
        /// 手工
        /// </summary>
        ManualType,

        /// <summary>
        /// 无列表页
        /// </summary>
        NoneListPage
    }
}
