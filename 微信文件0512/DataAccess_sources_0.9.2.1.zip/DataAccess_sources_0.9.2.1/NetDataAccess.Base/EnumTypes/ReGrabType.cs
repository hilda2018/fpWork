﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Base.EnumTypes
{
    /// <summary>
    /// 重复抓取规则
    /// </summary>
    public enum ReGrabType
    {
        /// <summary>
        /// 对于已经记录在的地址，下次抓取的时候不再重复抓取，且停止后续抓取，即认为之后的页面都是已经抓取过的了
        /// </summary>
        CheckByUrl,

        /// <summary>
        /// 始终全部抓取
        /// </summary>
        AllReTask
    }
}
