﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Base.EnumTypes
{
    /// <summary>
    /// 抓取时间类型
    /// </summary>
    public enum TaskTimeType
    {
        /// <summary>
        /// 手工
        /// </summary>
        Manual,

        /// <summary>
        /// 定时
        /// </summary>
        Timer
    }
}
