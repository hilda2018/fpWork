﻿using NetDataAccess.Base.EnumTypes;
using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Base.Config
{
    /// <summary>
    /// 服务配置类，要改写成配置到配置文件中
    /// </summary>
    public class SysConfig
    {
        #region 常量
        public static string ListSheetName = "List";
        public static string ListPageIndexFieldName = "listPageIndex";
        public static string DetailPageUrlFieldName = "detailPageUrl";
        public static string DetailPageNameFieldName = "detailPageName";
        public static string DetailPageCookieFieldName = "cookie";
        public static string GrabStatusFieldName = "grabStatus";
        public static string GiveUpGrabFieldName = "giveUpGrab";
        //public static int ListPageIndexFieldIndex = 0;
        public static int DetailPageUrlFieldIndex = 0;
        public static int DetailPageNameFieldIndex = 1;
        public static int DetailPageCookieFieldIndex = 1;
        public static int GrabStatusFieldIndex = 3;
        public static int GiveUpGrabFieldIndex = 4;
        public static int SystemColumnCount = 5;
        public static int ColumnTitleRowCount = 1;
        #endregion

        #region 获取多少页详情页数据后保存一次
        private static int _IntervalDetailPageSave = 50;
        /// <summary>
        /// 获取多少页详情页数据后保存一次
        /// </summary>
        public static int IntervalDetailPageSave
        {
            get
            {
                return _IntervalDetailPageSave;
            }
        }
        #endregion

        #region 最大同时执行的任务数
        /// <summary>
        /// 最大同时执行的任务数
        /// </summary>
        private static int _MaxAliveTaskNum = 3;
        /// <summary>
        /// 最大同时执行的任务数
        /// </summary>
        public static int MaxAliveTaskNum
        {
            get
            {
                return _MaxAliveTaskNum;
            }
        }
        #endregion

        #region 网页访问超时时间（ms）
        /// <summary>
        /// 网页访问超时时间（ms）
        /// </summary>
        private static int _WebPageRequestTimeout = 30;
        /// <summary>
        /// 网页访问超时时间
        /// </summary>
        public static int WebPageRequestTimeout
        {
            get
            {
                return _WebPageRequestTimeout;
            }
        }
        #endregion

        #region 系统默认网页编码方式
        /// <summary>
        /// 系统默认网页编码方式
        /// </summary>
        private static string _Encoding = "utf-8";
        /// <summary>
        /// 网页访问超时时间
        /// </summary>
        public static string Encoding
        {
            get
            {
                return _Encoding;
            }
        }
        #endregion

        #region 是否显示错误详情
        private static bool _AllowShowError  = true;
        /// <summary>
        /// 是否显示错误详情
        /// </summary>
        public static bool AllowShowError
        {
            get
            {
                return _AllowShowError;
            }
            set
            {
                _AllowShowError = value;
            }
        }
        #endregion

        #region 网页加载轮询等待间隔时间（ms）
        /// <summary>
        /// 网页加载轮询等待间隔时间（ms）
        /// </summary>
        private static int _WebPageRequestInterval = 200;
        /// <summary>
        /// 网页访问超时时间
        /// </summary>
        public static int WebPageRequestInterval
        {
            get
            {
                return _WebPageRequestInterval;
            }
        }
        #endregion

        #region xpath路径分隔符
        /// <summary>
        /// xpath路径分隔符
        /// </summary>
        private static string _XPathSplit = "#split#";
        /// <summary>
        /// 网页访问超时时间
        /// </summary>
        public static string XPathSplit
        {
            get
            {
                return _XPathSplit;
            }
        }
        #endregion

        #region 显示的日志最低级别
        private static LogLevelType _ShowLogLevelType = LogLevelType.Normal;
        /// <summary>
        /// 显示的日志最低级别
        /// </summary>
        public static LogLevelType ShowLogLevelType
        {
            get
            {
                return _ShowLogLevelType;
            }
            set
            {
                _ShowLogLevelType = value;
            }
        }
        #endregion

        #region 状态刷新间隔
        private static int _IntervalShowStatus = 50;
        /// <summary>
        /// 状态刷新间隔
        /// </summary>
        public static int IntervalShowStatus
        {
            get
            {
                return _IntervalShowStatus;
            }
            set
            {
                _IntervalShowStatus = value;
            }
        }
        #endregion

        #region 日志刷新间隔，如果联系不刷新超过次数，那么强制刷新显示日志
        private static int _IntervalShowLog = 1000;
        /// <summary>
        /// 日志刷新间隔，如果联系不刷新超过次数，那么强制刷新显示日志
        /// </summary>
        public static int IntervalShowLog
        {
            get
            {
                return _IntervalShowLog;
            }
            set
            {
                _IntervalShowLog = value;
            }
        }
        #endregion

        #region 显示最小时间间隔的日志，两次日志直接小于此时间，那么不显示
        private static double _ShowLogMinSecond = 0.5;
        /// <summary>
        /// 状态刷新间隔
        /// </summary>
        public static double ShowLogMinSecond
        {
            get
            {
                return _ShowLogMinSecond;
            }
            set
            {
                _ShowLogMinSecond = value;
            }
        }
        #endregion  
    }
}