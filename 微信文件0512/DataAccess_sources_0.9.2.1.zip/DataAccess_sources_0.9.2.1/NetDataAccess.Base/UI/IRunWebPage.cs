﻿using NetDataAccess.Base.Definition;
using NetDataAccess.Base.EnumTypes;
using NetDataAccess.Base.DB;
using NPOI.SS.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using NetDataAccess.Base.Log; 

namespace NetDataAccess.Base.UI
{
    #region 运行网页抓取的基类
    /// <summary>
    /// 运行网页抓取的基类
    /// </summary>
    public interface IRunWebPage
    {
        #region 日志
        RunTaskLog TaskLog { get; }
        #endregion

        #region 本次运行的任务Id
        string TaskId { get; }
        #endregion

        #region 文件路径 
        string FileDir { get; }
        #endregion

        #region 输入文件路径
        string InputFileDir { get; }
        #endregion

        #region 输出文件路径
        string OutputFileDir { get; }
        #endregion

        #region 运行的任务文件路径
        string TaskFileDir { get; }
        #endregion

        #region Project 
        /// <summary>
        /// Project
        /// </summary>
        Proj_Main Project { get; }
        #endregion  
        
        #region 详情页地址列表 
        /// <summary>
        /// 详情页地址列表
        /// </summary>
        List<string> DetailPageUrlList { get; }
        #endregion

        #region  详情页名称列表 
        /// <summary>
        /// 详情页名称列表
        /// </summary>
        List<string> DetailPageNameList { get; }
        #endregion  

        #region 网页加载完成
        bool IsNavigateCompleted { get; }
        #endregion

        #region 显示网页
        void InvoceShowWebPage(string url);
        #endregion

        #region 显示进度日志
        void InvokeAppendLogText(string msg, LogLevelType logType, bool immediatelyShow);
        #endregion   

        #region 保存Excel文件到硬盘 放弃使用的方法
        //void SaveExcelToDisk( string fileName);
        #endregion
        
        #region 获取浏览器控件
        WebBrowser GetWebBrowser();
        #endregion

        #region 获取HTML内容
        string InvokeGetPageHtml();
        #endregion

        #region 给控件赋值
        void InvokeSetControlValueById(string id, string attributeName, string attributeValue);
        #endregion
        
        #region 列名序号对应
        Dictionary<string, int> ColumnNameToIndex { get; }
        #endregion

        #region 获取源码页保存地址
        string GetFilePath(string pageUrl, string dir);
        #endregion

        #region 获取Read页保存地址
        string GetReadFilePath(string pageUrl, string dir);
        #endregion

        #region 获取处理后的中级文件路径
        string GetReadFileDir();
        #endregion 

        #region 获取结果文件夹
        string GetExportDir();
        #endregion

        #region 获取源文件文件夹
        string GetDetailSourceFileDir();
        #endregion

        #region 获取列表页件文件夹
        string GetListSourceFileDir();
        #endregion

        #region 获取是否放弃抓取此页
        /// <summary>
        ///  获取是否放弃抓取此页
        /// </summary>
        /// <returns></returns>
        bool CheckGiveUpGrabPage(IListSheet listSheet, string pageUrl, int pageIndex);
        #endregion

        #region 从Read文件中，读取信息
        Dictionary<string, string> ReadDetailFieldValueFromFile(string localReadFilePath);
        #endregion

        #region 从Read文件中，读取信息
        List<Dictionary<string, string>> ReadDetailFieldValueListFromFile(string localReadFilePath);
        #endregion

        
        #region 读取下载下来的html
        HtmlAgilityPack.HtmlDocument GetLocalHtmlDocument(IListSheet listSheet, int pageIndex);
        #endregion

        #region 释放浏览器
        void InvokeDisposeWebBrowser();
        #endregion
    }
    #endregion
}
