﻿using NetDataAccess.Base.Common;
using NetDataAccess.Base.Config;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace NetDataAccess.Base.Proxy
{
    /// <summary>
    /// 代理服务器集合
    /// </summary>
    public static class ProxyServers
    {
        #region ServerListFilePath
        /// <summary>
        /// ServerListFilePath
        /// </summary>
        private static string ServerListFilePath = Path.Combine(Path.GetDirectoryName(Application.StartupPath), "Files/Config/Proxy.xlsx");
        #endregion

        #region 锁
        private static object _GetProxyServerLocker = new object();
        #endregion

        #region 加载代理服务器列表
        /// <summary>
        /// 加载代理服务器列表
        /// </summary>
        /// <param name="filePath"></param>
        public static void Load()
        {
            try
            {
                string filePath = ServerListFilePath;
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    IWorkbook wb = new XSSFWorkbook(fs);
                    ISheet sheet = wb.GetSheet("Proxy");
                    List<ProxyServer> allProxies = new List<ProxyServer>();
                    for (int i = 1; i <= sheet.LastRowNum; i++)
                    {
                        IRow row = sheet.GetRow(i);

                        ICell usableCell = row.GetCell(4);
                        if (usableCell != null && usableCell.StringCellValue == "是")
                        {
                            ProxyServer ps = new ProxyServer();
                            ps.IP = row.GetCell(0).ToString();
                            ps.Port = int.Parse(row.GetCell(1).ToString());
                            ps.User = row.GetCell(2) == null ? "" : row.GetCell(2).ToString();
                            ps.Pwd = row.GetCell(3) == null ? "" : row.GetCell(3).ToString();
                            allProxies.Add(ps);
                        }
                    }
                    _AllProxies = allProxies;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("读取代理服务器出错", ex);
            }
        }
        #endregion

        #region 所有代理服务器信息
        private static List<ProxyServer> _AllProxies = new List<ProxyServer>();
        /// <summary>
        /// 所有代理服务器信息
        /// </summary>
        public static List<ProxyServer> AllProxies
        {
            get {
                return _AllProxies;
            }
        }
        #endregion

        #region 记录放弃的代理
        private static Dictionary<string, List<int>> AbandonIndexes = new Dictionary<string, List<int>>();
        #endregion

        #region 记录正在使用的代理
        private static Dictionary<string, int> UsingProxyIndexes = new Dictionary<string, int>();
        #endregion

        #region 放弃
        public static ProxyServer Abandon(string id)
        {
            lock (_GetProxyServerLocker)
            {
                if (!AbandonIndexes.ContainsKey(id))
                {
                    AbandonIndexes.Add(id, new List<int>());
                }
                List<int> indexes = AbandonIndexes[id];
                int index = UsingProxyIndexes[id];
                indexes.Add(index);
                if (indexes.Count == ProxyServers.AllProxies.Count)
                {
                    indexes.Clear();
                }
                return AllProxies[index];
            }
        }
        #endregion

        #region 构造WebProxy
        /// <summary>
        /// 构造WebProxy
        /// </summary>
        /// <param name="ps"></param>
        /// <returns></returns>
        public static IWebProxy GenerateWebProxy(ProxyServer ps)
        {
            WebProxy wp = new WebProxy();
            wp.Address = new Uri("http://" + ps.IP + ":" + ps.Port.ToString());
            if (!CommonUtil.IsNullOrBlank(ps.User))
            {
                wp.Credentials = new NetworkCredential(ps.User, ps.Pwd);
            }
            return wp;
        }
        #endregion

        #region 获取Proxy
        /// <summary>
        /// 获取Proxy
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static IWebProxy GetWebProxy(string id)
        {
            lock (_GetProxyServerLocker)
            {
                if (!AbandonIndexes.ContainsKey(id))
                {
                    AbandonIndexes.Add(id, new List<int>());
                }
                List<int> abandons = AbandonIndexes[id];
                if (AllProxies.Count == 0)
                {
                    throw new Exception("没有指定任何代理服务器.");
                }
                else if (abandons.Count < AllProxies.Count)
                {
                    if (!UsingProxyIndexes.ContainsKey(id))
                    {
                        UsingProxyIndexes.Add(id, -1);
                    }
                    int usingIndex = UsingProxyIndexes[id];

                    int nextIndex = AllProxies.Count > usingIndex + 1 ? usingIndex + 1 : 0;
                    while (abandons.Contains(nextIndex))
                    {
                        nextIndex = AllProxies.Count > nextIndex + 1 ? nextIndex + 1 : 0;
                    }

                    ProxyServer ps = AllProxies[nextIndex];
                    UsingProxyIndexes[id] = nextIndex;
                    return GenerateWebProxy(ps);
                }
                else
                {
                    abandons.Clear();
                    throw new Exception("没有可用的代理服务器, 将重新启用所有代理.");
                }
            }
        }
        #endregion
    }
}
