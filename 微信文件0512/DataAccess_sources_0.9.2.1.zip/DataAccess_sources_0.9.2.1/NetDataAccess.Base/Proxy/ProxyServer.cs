﻿using NetDataAccess.Base.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Base.Proxy
{
    /// <summary>
    /// 代理服务器信息
    /// </summary>
    public class ProxyServer
    {
        #region IP地址
        /// <summary>
        /// IP地址
        /// </summary>
        public string IP { set; get; }
        #endregion

        #region 端口
        /// <summary>
        /// 端口
        /// </summary>
        public int Port { set; get; }
        #endregion

        #region Address
        /// <summary>
        /// Address
        /// </summary>
        public string Address
        {
            get
            {
                return this.IP + ":" + Port.ToString();
            }
        }
        #endregion

        #region 用户名
        /// <summary>
        /// 用户名
        /// </summary>
        public string User { set; get; }
        #endregion

        #region 密码
        /// <summary>
        /// 密码
        /// </summary>
        public string Pwd { set; get; }
        #endregion

        #region 是否需要用户名密码登录
        /// <summary>
        /// 是否需要用户名密码登录
        /// </summary>
        public bool NeedUserPwd
        {
            get
            {
                return !CommonUtil.IsNullOrBlank(this.User);
            }
        }
        #endregion
    }
}
