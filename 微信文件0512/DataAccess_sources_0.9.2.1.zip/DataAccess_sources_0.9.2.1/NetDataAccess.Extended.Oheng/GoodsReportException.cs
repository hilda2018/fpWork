﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Extended.Oheng
{
    /// <summary>
    /// 从html中获取理货报告时发生的异常
    /// </summary>
    public class GoodsReportException : Exception
    {
        #region 预定义的错误码
        /// <summary>
        /// 正在获取
        /// </summary>
        public const string ErrorCode_GettingDelieryInfo = "002";

        /// <summary>
        /// 跳转到了登录页面
        /// </summary>
        public const string ErrorCode_RedirectLoginCode = "003";

        /// <summary>
        /// 不存在此理货单
        /// </summary>
        public const string ErrorCode_NoneExistDelivery = "004";

        /// <summary>
        /// 未知的错误
        /// </summary>
        public const string ErrorCode_Unknown = "005";
        #endregion

        #region 本次的错误码
        private string _ErrorCode = null;
        /// <summary>
        /// 错误码
        /// </summary>
        public string ErrorCode
        {
            get
            {
                return _ErrorCode;
            }
        }
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="code"></param>
        /// <param name="message"></param>
        public GoodsReportException(string code, string message)
            : base(message)
        {
            _ErrorCode = code;
        }
        #endregion
    }
}
