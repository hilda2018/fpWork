﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Timers;

namespace AutomaticControl
{
    public class KeyClickTimer
    {
        private Byte _KeyValue = 0;
        private int _Time = 0;
        private Timer _Timer = null;
        public KeyClickTimer(Byte keyValue, int time)
        {
            _KeyValue = keyValue;
            _Time = time;
        }

        public void Do()
        {
           _Timer = new Timer(_Time);
           _Timer.Elapsed += timer_Elapsed;
           BaseCommand.ClickKey(_KeyValue, KeyEventFlag.Down);
           _Timer.Start();
        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _Timer.Stop();
            _Timer.Dispose();
            BaseCommand.ClickKey(_KeyValue, KeyEventFlag.Up);
        }
    }
}
