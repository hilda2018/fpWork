﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomaticControl
{
    /// <summary>
    /// 键盘事件常量
    /// </summary>
    public enum KeyEventFlag : int
    {
        Down = 0x0000,
        Up = 0x0002,
    }
}
