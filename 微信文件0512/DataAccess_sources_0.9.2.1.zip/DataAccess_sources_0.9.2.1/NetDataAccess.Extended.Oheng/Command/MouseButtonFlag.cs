﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomaticControl
{
    public enum MouseButtonFlag
    {
        Left,
        Middle,
        Right,
    }
}
