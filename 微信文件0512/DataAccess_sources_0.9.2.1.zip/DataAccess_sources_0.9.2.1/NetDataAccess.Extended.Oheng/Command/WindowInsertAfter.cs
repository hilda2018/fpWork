﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomaticControl.Command
{
    public enum WindowInsertAfter : int
    {
        /// <summary>
        /// 将窗口置于Z序的底部。
        /// </summary>
        HWND_BOTTOM = 1,

        /// <summary>
        /// 将窗口置于所有非顶层窗口之上（即在所有顶层窗口之后）
        /// </summary>
        HWND_NOTOPMOST = -2,

        /// <summary>
        /// 将窗口置于Z序的顶部
        /// </summary>
        HWND_TOP = 0,

        /// <summary>
        /// 将窗口置于所有非顶层窗口之上
        /// </summary>
        HWND_TOPMOST = -1
    }
}
