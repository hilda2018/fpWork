﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AutomaticControl
{
    //将枚举作为位域处理
    [Flags]
    public enum MouseEventFlag : uint //设置鼠标动作的键值
    {
        Move = 0x0001,               //发生移动
        LeftDown = 0x0002,           //鼠标按下左键
        LeftUp = 0x0004,             //鼠标松开左键
        RightDown = 0x0008,          //鼠标按下右键
        RightUp = 0x0010,            //鼠标松开右键
        MiddleDown = 0x0020,         //鼠标按下中键
        MiddleUp = 0x0040,           //鼠标松开中键
        XDown = 0x0080,
        XUp = 0x0100,
        Wheel = 0x0800,              //鼠标轮被移动
        VirtualDesk = 0x4000,        //虚拟桌面
        Absolute = 0x8000
    }
}
