﻿using AutomaticControl.Command;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Timers;
using System.Windows.Forms;

namespace AutomaticControl
{
    public class BaseCommand
    { 
        /// <summary>
        /// 设置窗口位置
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="hWndInsertAfter"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        /// <param name="flags"></param>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        private static extern int SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int y, int w, int h, uint flags);

        /// <summary>
        /// 获取鼠标位置
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out Point pt);

        /// <summary>
        /// 获得顶层窗体的句柄
        /// </summary>
        /// <returns></returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        private static extern IntPtr GetForegroundWindow(); 

        /// <summary>
        /// 设置此窗体为活动窗体
        /// </summary>
        /// <param name="hWnd"></param>
        /// <returns></returns>
        [DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        /// <summary>
        /// 该函数用于设置鼠标的位置,其中X和Y是相对于屏幕左上角的绝对位置.
        /// </summary>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]        
        private static extern bool SetCursorPos(int x, int y);

        /// <summary>
        /// 该函数不仅可以设置鼠标指针绝对位置,而且可以以相对坐标来设置位置.
        /// 其中flags标志位集,指定点击按钮和鼠标动作的多种情况.
        /// dx指鼠标沿x轴绝对位置或上次鼠标事件位置产生以来移动的数量.
        /// dy指沿y轴的绝对位置或从上次鼠标事件以来移动的数量.
        /// data如果flags为MOUSE_WHEEL则该值指鼠标轮移动的数量(否则为0),正值向前转动.
        /// extraInfo指定与鼠标事件相关的附加32位值.
        /// </summary>
        /// <param name="flags"></param>
        /// <param name="dx"></param>
        /// <param name="dy"></param>
        /// <param name="data"></param>
        /// <param name="extraInfo"></param>
        [DllImport("user32.dll")]
        private static extern void mouse_event(MouseEventFlag flags, int dx, int dy, uint data, UIntPtr extraInfo);

        /// <summary>
        /// 该函数根据类名和窗口名来得到窗口句柄,但是这个函数不能查找子窗口,也不区分大小写.
        /// 如果要从一个窗口的子窗口查找需要使用FIndWindowEX函数.
        /// </summary>
        /// <param name="strClass"></param>
        /// <param name="strWindow"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string strClass, string strWindow);

        /// <summary>
        /// 该函数获取一个窗口的句柄,该窗口的类名和窗口名与给定的字符串相匹配,
        /// 该函数查找子窗口时从排在给定的子窗口后面的下一个子窗口开始.
        /// 其中参数hwnParent为要查找子窗口的父窗口句柄,
        /// 若该值为NULL则函数以桌面窗口为父窗口,查找桌面窗口的所有子窗口.
        /// hwndChildAfter子窗口句柄,查找从在Z序中的下一个子窗口开始,
        /// 子窗口必须为hwnParent直接子窗口而非后代窗口,若hwnChildAfter为NULL,查找从父窗口的第一个子窗口开始.
        /// strClass指向一个指定类名的空结束字符串或一个标识类名字符串的成员的指针.
        /// strWindow指向一个指定窗口名(窗口标题)的空结束字符串.若为NULL则所有窗体全匹配.
        /// 返回值:如果函数成功,返回值为具有指定类名和窗口名的窗口句柄,如果函数失败,返回值为NULL.
        /// </summary>
        /// <param name="hwndParent"></param>
        /// <param name="hwndChildAfter"></param>
        /// <param name="strClass"></param>
        /// <param name="strWindow"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string strClass, string strWindow);
        
        /// <summary>
        /// 键盘事件函数
        /// </summary>
        /// <param name="bVk"></param>
        /// <param name="bScan"></param>
        /// <param name="dwFlags"></param>
        /// <param name="dwExtraInfo"></param>
        [DllImport("user32.dll", EntryPoint = "keybd_event")]
        private static extern void keybd_event(Byte bVk, Byte bScan, KeyEventFlag dwFlags, Int32 dwExtraInfo);

        /// <summary>
        /// 键盘操作
        /// </summary>
        /// <param name="_bVk"></param>
        /// <param name="_dwFlags"></param>
        public static void ClickKey(Keys keyValue )
        {
            ClickKey((Byte)keyValue);
        }
        /// <summary>
        /// 键盘操作
        /// </summary>
        /// <param name="_bVk"></param>
        /// <param name="_dwFlags"></param>
        public static void ClickKey(Byte keyValue)
        {
            keybd_event(keyValue, 0, KeyEventFlag.Down, 0);
            keybd_event(keyValue, 0, KeyEventFlag.Up, 0);
        }
        /// <summary>
        /// 键盘操作
        /// </summary>
        /// <param name="_bVk"></param>
        /// <param name="_dwFlags"></param>
        public static void ClickKey(Keys keyValue, KeyEventFlag dwFlags)
        {
            keybd_event((Byte)keyValue, 0, dwFlags, 0);
        }
        /// <summary>
        /// 键盘操作
        /// </summary>
        /// <param name="_bVk"></param>
        /// <param name="_dwFlags"></param>
        public static void ClickKey(Byte keyValue, KeyEventFlag dwFlags)
        {
            keybd_event(keyValue, 0, dwFlags, 0);
        }

        /// <summary>
        /// 键盘操作 
        /// 带自动释放time 单位:毫秒
        /// </summary>
        /// <param name="keyValue"></param>
        /// <param name="time"></param>
        public static void ClickKey(Keys keyValue, int time)
        {
            ClickKey((Byte)keyValue, time);
        }

        /// <summary>
        /// 键盘操作 
        /// 带自动释放time 单位:毫秒
        /// </summary>
        /// <param name="keyValue"></param>
        /// <param name="time"></param>
        public static void ClickKey(Byte keyValue, int time)
        {
            KeyClickTimer t = new KeyClickTimer(keyValue, time);
            t.Do();
        }

        /// <summary>
        /// 键盘操作 组合键 带释放
        /// </summary>
        /// <param name="keyValues"></param>
        public static void ClickKey(Keys[] keyValues)
        {
            Byte[] kvs = new Byte[keyValues.Length];
            for (int i = 0; i < keyValues.Length;i++ )
            {
                kvs[i] = (Byte)keyValues[i];
            }
            ClickKey(kvs);
        }

        /// <summary>
        /// 键盘操作 组合键 带释放
        /// </summary>
        /// <param name="keyValues"></param>
        public static void ClickKey(Byte[] keyValues)
        {
            if (keyValues.Length >= 2)
            {
                //按下所有键
                foreach (Byte keyValue in keyValues)
                {
                    ClickKey(keyValue, KeyEventFlag.Down);
                }
                //反转按键排序
                List<Byte> kvs = new List<byte>(keyValues);
                kvs.Reverse();

                //松开所有键
                foreach (Byte keyValue in kvs)
                {
                    ClickKey(keyValue, KeyEventFlag.Up);
                }
            }
        }

        private const int _ScreenMoveMaxStepCount = 65536;

        private static int _ScreenHeight = 0;
        private static int ScreenHeight
        {
            get
            {
                if (_ScreenHeight == 0)
                {
                    GetScreenSize();
                }
                return _ScreenHeight;
            }
        }
        private static int _ScreenWidth = 0;
        private static int ScreenWidth
        {
            get
            {
                if (_ScreenWidth == 0)
                {
                    GetScreenSize();
                }
                return _ScreenWidth;
            }
        }

        private static void GetScreenSize()
        {
            Rectangle rect =Screen.PrimaryScreen.Bounds;
            _ScreenWidth = rect.Width;//屏幕宽
            _ScreenHeight = rect.Height;//屏幕高
        }

        /// <summary> 
        /// dx, dy是绝对坐标
        /// eventFlag可以指定按键
        /// </summary>
        /// <param name="dwFlags"></param>
        /// <param name="dx"></param>
        /// <param name="dy"></param>
        public static void MouseMoveTo(int x, int y, MouseEventFlag eventFlag)
        {
            int dx = (int)(x * _ScreenMoveMaxStepCount / ScreenWidth);
            int dy = (int)(y * _ScreenMoveMaxStepCount / ScreenHeight);
            mouse_event(MouseEventFlag.Absolute | MouseEventFlag.Move | eventFlag, dx, dy, 0, UIntPtr.Zero);
        }

        /// <summary> 
        /// dx, dy是绝对坐标
        /// </summary>
        /// <param name="dwFlags"></param>
        /// <param name="dx"></param>
        /// <param name="dy"></param>
        public static void MouseMoveTo(int x, int y)
        {
            int dx = (int)(x * _ScreenMoveMaxStepCount / ScreenWidth);
            int dy = (int)(y * _ScreenMoveMaxStepCount / ScreenHeight);
            mouse_event(MouseEventFlag.Absolute | MouseEventFlag.Move, dx, dy, 0, UIntPtr.Zero); 
        } 


        /// <summary>
        /// 点击鼠标
        /// </summary>
        /// <param name="button"></param>
        /// <param name="is_double"></param>
        public static void ClickMouseButton(MouseButtonFlag button, bool isDouble)
        {
            switch (button)
            {
                case MouseButtonFlag.Left:
                    mouse_event(MouseEventFlag.LeftDown, 0, 0, 0, UIntPtr.Zero);
                    mouse_event(MouseEventFlag.LeftUp, 0, 0, 0, UIntPtr.Zero);
                    if (isDouble)
                    {
                        mouse_event(MouseEventFlag.LeftDown, 0, 0, 0, UIntPtr.Zero);
                        mouse_event(MouseEventFlag.LeftUp, 0, 0, 0, UIntPtr.Zero);
                    }
                    break;
                case  MouseButtonFlag.Right:
                    mouse_event(MouseEventFlag.RightDown, 0, 0, 0, UIntPtr.Zero);
                    mouse_event(MouseEventFlag.RightUp, 0, 0, 0, UIntPtr.Zero);
                    if (isDouble)
                    {
                        mouse_event(MouseEventFlag.RightDown, 0, 0, 0, UIntPtr.Zero);
                        mouse_event(MouseEventFlag.RightUp, 0, 0, 0, UIntPtr.Zero);
                    }
                    break;
                case MouseButtonFlag.Middle:
                    mouse_event(MouseEventFlag.MiddleDown, 0, 0, 0, UIntPtr.Zero);
                    mouse_event(MouseEventFlag.MiddleUp, 0, 0, 0, UIntPtr.Zero);
                    if (isDouble)
                    {
                        mouse_event(MouseEventFlag.MiddleDown, 0, 0, 0, UIntPtr.Zero);
                        mouse_event(MouseEventFlag.MiddleUp, 0, 0, 0, UIntPtr.Zero);
                    }
                    break;
            }
        }

        /// <summary>
        /// 获取键码 这一部分 就是根据字符串 获取 键码 这里只列出了一部分 可以自己修改
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public Byte GetKeys(string key)
        {
            switch (key.ToLower())
            {
                case "a": return (Byte)Keys.A;
                case "b": return (Byte)Keys.B;
                case "c": return (Byte)Keys.C;
                case "d": return (Byte)Keys.D;
                case "e": return (Byte)Keys.E;
                case "f": return (Byte)Keys.F;
                case "g": return (Byte)Keys.G;
                case "h": return (Byte)Keys.H;
                case "i": return (Byte)Keys.I;
                case "j": return (Byte)Keys.J;
                case "k": return (Byte)Keys.K;
                case "l": return (Byte)Keys.L;
                case "m": return (Byte)Keys.M;
                case "n": return (Byte)Keys.N;
                case "o": return (Byte)Keys.O;
                case "p": return (Byte)Keys.P;
                case "q": return (Byte)Keys.Q;
                case "r": return (Byte)Keys.R;
                case "s": return (Byte)Keys.S;
                case "t": return (Byte)Keys.T;
                case "u": return (Byte)Keys.U;
                case "v": return (Byte)Keys.V;
                case "w": return (Byte)Keys.W;
                case "x": return (Byte)Keys.X;
                case "y": return (Byte)Keys.Y;
                case "z": return (Byte)Keys.Z;
                case "+": 
                case "add": return (Byte)Keys.Add;
                case "back": return (Byte)Keys.Back;
                case "cancel": return (Byte)Keys.Cancel;
                case "capital": return (Byte)Keys.Capital;
                case "capsLock": return (Byte)Keys.CapsLock;
                case "clear": return (Byte)Keys.Clear;
                case "crsel": return (Byte)Keys.Crsel;
                case "ctrl":
                case "control":
                case "controlkey": return (Byte)Keys.ControlKey;
                case "0": return (Byte)Keys.D0;
                case "1": return (Byte)Keys.D1;
                case "2": return (Byte)Keys.D2;
                case "3": return (Byte)Keys.D3;
                case "4": return (Byte)Keys.D4;
                case "5": return (Byte)Keys.D5;
                case "6": return (Byte)Keys.D6;
                case "7": return (Byte)Keys.D7;
                case "8": return (Byte)Keys.D8;
                case "9": return (Byte)Keys.D9;
                case ".":
                case "decimal": return (Byte)Keys.Decimal;
                case "del":
                case "delete": return (Byte)Keys.Delete;
                case "/":
                case "divide": return (Byte)Keys.Divide;
                case "down": return (Byte)Keys.Down;
                case "end": return (Byte)Keys.End;
                case "enter": return (Byte)Keys.Enter;
                case "esc":
                case "escape": return (Byte)Keys.Escape;
                case "f1": return (Byte)Keys.F1;
                case "f2": return (Byte)Keys.F2;
                case "f3": return (Byte)Keys.F3;
                case "f4": return (Byte)Keys.F4;
                case "f5": return (Byte)Keys.F5;
                case "f6": return (Byte)Keys.F6;
                case "f7": return (Byte)Keys.F7;
                case "f8": return (Byte)Keys.F8;
                case "f9": return (Byte)Keys.F9;
                case "f10": return (Byte)Keys.F10;
                case "f11": return (Byte)Keys.F11;
                case "f12": return (Byte)Keys.F12;
                case "help": return (Byte)Keys.Help;
                case "home": return (Byte)Keys.Home;
                case "ins":
                case "insert": return (Byte)Keys.Insert;
                case "leftbutton":
                case "lbutton": return (Byte)Keys.LButton;
                case "leftcontrol":
                case "lcontrol": return (Byte)Keys.LControlKey;
                case "left": return (Byte)Keys.Left;
                case "lalt":
                case "leftalt":
                case "lmenu": return (Byte)Keys.LMenu;
                case "shift":
                case "leftshift":
                case "lshift": return (Byte)Keys.LShiftKey;
                case "window":
                case "windows":
                case "win":
                case "lwin": return (Byte)Keys.LWin;
                case "middlebutton":
                case "mbutton": return (Byte)Keys.MButton;
                case "alt":
                case "menu": return (Byte)Keys.Menu;
                case "*":
                case "multiply": return (Byte)Keys.Multiply; 
                case "next": return (Byte)Keys.Next;
                case "numlock": return (Byte)Keys.NumLock;
                case "numpad0": return (Byte)Keys.NumPad0;
                case "numpad1": return (Byte)Keys.NumPad1;
                case "numpad2": return (Byte)Keys.NumPad2;
                case "numpad3": return (Byte)Keys.NumPad3;
                case "numpad4": return (Byte)Keys.NumPad4;
                case "numpad5": return (Byte)Keys.NumPad5;
                case "numpad6": return (Byte)Keys.NumPad6;
                case "numpad7": return (Byte)Keys.NumPad7;
                case "numpad8": return (Byte)Keys.NumPad8;
                case "numpad9": return (Byte)Keys.NumPad9;
                case "pagedown": return (Byte)Keys.PageDown;
                case "pageup": return (Byte)Keys.PageUp;
                case "process": return (Byte)Keys.ProcessKey;
                case "rightbutton":
                case "rbutton": return (Byte)Keys.RButton;
                case "right": return (Byte)Keys.Right;
                case "rightcontrol":
                case "rcontrol": return (Byte)Keys.RControlKey;
                case "ralt":
                case "rightalt":
                case "rmenu": return (Byte)Keys.RMenu;
                case "rightshift":
                case "rshift": return (Byte)Keys.RShiftKey;
                case "scroll": return (Byte)Keys.Scroll;
                case " ":
                case "space": return (Byte)Keys.Space;
                case "tab": return (Byte)Keys.Tab;
                case "up": return (Byte)Keys.Up;
                case "minus":
                case "-": return (Byte)Keys.OemMinus;
                default:
                    throw new Exception("没有指定此按键, KeyValue = "+ key); 
            } 
        }

        /// <summary>
        /// 移动鼠标（绝对坐标），并点击鼠标左键
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public static void MouseMoveToAndClick(int x, int y)
        {
            MouseMoveTo(x, y);
            ClickMouseButton(MouseButtonFlag.Left, false);
        }

        /// <summary>
        /// 启动程序
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static Process StartApplication(string fileName)
        {
           return Process.Start(fileName); 
        }

        /// <summary>
        /// 获取窗口句柄
        /// </summary>
        /// <param name="windowName"></param>
        /// <returns></returns>
        public static IntPtr FindWindow(string windowName)
        {
            return FindWindow(null, windowName);
        }

        /// <summary>
        /// 设置窗口位置
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="hWndInsertAfter"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="cx"></param>
        /// <param name="cy"></param>
        /// <param name="flags"></param>
        /// <returns></returns> 
        public static int SetWindowPos(IntPtr hWnd, WindowInsertAfter hWndInsertAfter, int x, int y, int w, int h, WindowPosFlag flags)
        {
            return SetWindowPos(hWnd, (int)hWndInsertAfter, x, y, w, h, (uint)flags);
        }

        /// <summary>
        /// 获得顶层窗体的句柄
        /// </summary>
        /// <returns></returns> 
        public static IntPtr GetTopWindow()
        {
            return GetForegroundWindow();
        }

        /// <summary>
        /// 设置此窗体为活动窗体
        /// </summary>
        /// <param name="hWnd"></param>
        /// <returns></returns> 
        public static bool SetTopWindow(IntPtr hWnd)
        {
            return SetForegroundWindow(hWnd);
        }

        /// <summary>
        /// 获取鼠标位置
        /// </summary>
        /// <returns></returns>
        public static Point GetMousePos()
        {
            Point p = new Point(0, 0);
            if (GetCursorPos(out p))
            {
                return p;
            }
            else
            {
                throw new Exception("无法获取鼠标位置.");
            }
        }

        /// <summary>
        /// 屏幕拷贝
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        /// <param name="saveImgPath"></param>
        public static void ScreenShot(int x, int y, int w, int h, string saveImgPath)
        {
            Bitmap bit = new Bitmap(w, h);
            Graphics g = Graphics.FromImage(bit);
            g.CopyFromScreen(x, y, 0, 0, new Size(w, h), CopyPixelOperation.SourceCopy);
            bit.Save(saveImgPath);
            g.Dispose();
        }
    }
}
