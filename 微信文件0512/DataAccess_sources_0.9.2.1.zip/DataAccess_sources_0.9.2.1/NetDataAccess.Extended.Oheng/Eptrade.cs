﻿using System;
using System.Collections.Generic;
using System.Text;
using NetDataAccess.Base.DLL;
using NetDataAccess.Base.Config;
using System.Threading;
using System.Windows.Forms;
using mshtml;
using NetDataAccess.Base.Definition;
using System.IO;
using NetDataAccess.Base.Common;
using NetDataAccess.Base.DB;
using NetDataAccess.Base.Writer;
using NetDataAccess.Base.Reader;
using NetDataAccess.Base.CsvHelper;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using HtmlAgilityPack;

namespace NetDataAccess.Extended.Oheng
{
    class Eptrade : CustomProgramBase
    {
        #region 系统登录用户名
        /// <summary>
        /// 系统登录用户名
        /// </summary>
        private string user_id = "13701814054";
        #endregion

        #region 系统登录密码
        /// <summary>
        /// 系统登录密码
        /// </summary>
        private string user_pwd = "OHLY1234";
        #endregion

        #region 获取网页信息超时时间
        /// <summary>
        /// 获取网页信息超时时间
        /// </summary>
        private int WebRequestTimeout = 120 * 1000;
        #endregion

        #region 浏览器控件
        /// <summary>
        /// 浏览器控件
        /// </summary>
        private WebBrowser WebBrowserMain = null;
        #endregion 

        #region 获取整箱申报信息
        public bool Run(string parameters, IListSheet listSheet)
        {
            //输出的文件
            CsvWriter dEW = null;
            try
            {
                //输入参数
                string[] ps = parameters.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);

                string billNo = ps[0];
                string exportFileName = ps[1];

                //输入的文件夹
                string exportDir = Path.Combine(this.RunPage.OutputFileDir, this.RunPage.Project.Name);
                string pPath = Path.Combine(exportDir, exportFileName);

                //构造输出文件的列
                Dictionary<string, int> pColumnDic = new Dictionary<string, int>();
                pColumnDic.Add("报关单号", 0);
                pColumnDic.Add("提运单号", 1);
                pColumnDic.Add("箱号", 2);
                pColumnDic.Add("船名/航次", 3);
                pColumnDic.Add("放行状态", 4);
                pColumnDic.Add("EDI中心接收时间", 5);

                //记录获取的整箱申报信息
                Dictionary<string, string> resultValueDic = null;

                //允许重新获取次数
                const int allowRetryCount = 5;
                int errorCount = 0;
                while (resultValueDic == null && errorCount < allowRetryCount)
                {
                    //获取提运单信息
                    resultValueDic = GetOne(dEW, billNo);
                    if (resultValueDic == null)
                    {
                        errorCount++;
                    }
                }

                //创建记录提运单信息的文件并保存
                dEW = new CsvWriter(pPath, pColumnDic);
                dEW.AddRow(resultValueDic);
                dEW.SaveToDisk();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }
        #endregion

        #region 获取一个提单信息
        private Dictionary<string, string> GetOne(CsvWriter dEW, string billNo)
        {
            try
            {
                //记录识别验证码
                string txtCode = "";

                //允许验证码识别次数
                const int allowTxtCodeRetryCount = 10; 

                //记录验证码识别错误次数
                int txtCodeErrorCount = 0;

                //允许跳转到查询页面的次数，有时会出现跳转至登录页面的情况
                const int allowGoToQueryPageCount = 10;

                int goToQueryPageErrorCount = 0;

                string queryUrl = "http://dw.eptrade.cn/datawindow/app/htg/index.htm";
                string loginUrl = "http://dp.eptrade.cn/";

                string currentUrl = "";

                while (currentUrl != loginUrl && goToQueryPageErrorCount < allowGoToQueryPageCount)
                {
                    //加载网页
                    this.ShowLoginWebPage(loginUrl);
                    currentUrl = WebBrowserMain.Url.ToString();
                }

                //轮询次数
                int waitCount = 0;

                // 打开登录页面后，首先判断当前是否是登录状态，如果不是则执行登录操作
                if (!this.IsLogin(WebBrowserMain))
                {
                    //在webBrowser的document，即html中增加js脚本，供本程序调用
                    InvokeSetScript();
                    while (txtCode.Length != 4 && txtCodeErrorCount < allowTxtCodeRetryCount)
                    {
                        //识别验证码
                        txtCode = GetTxtCode();
                        //再增加个等待，可能网页会有异步加载数据的情况，等待时间视访问的网页不同而定，此等待不是必须的
                        Thread.Sleep(1000);
                        txtCodeErrorCount++;
                    }
                    if (txtCodeErrorCount == allowTxtCodeRetryCount)
                    {
                        throw new Exception("验证码识别次数超过" + allowTxtCodeRetryCount + "次, 宣告识别");
                    }
                    else
                    {
                        //在网页中执行登录操作
                        this.InvokeDoSubmit(user_id, user_pwd, txtCode);

                        //轮询获取当前webBrowser上的信息，直到webBrowser控件加载完成
                        while (!this.RunPage.IsNavigateCompleted)
                        {
                            if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                            {
                                //超时
                                this.RunPage.InvokeAppendLogText("点击查询后, 响应超时!", Base.EnumTypes.LogLevelType.System, true);
                                throw new Exception("点击查询后, 响应超时!");
                            }
                            //等待
                            waitCount++;
                            Thread.Sleep(SysConfig.WebPageRequestInterval);
                        }

                        //再增加个等待，可能网页会有异步加载数据的情况，等待时间视访问的网页不同而定，此等待不是必须的
                        Thread.Sleep(1000);
                    }
                }

                while (currentUrl != queryUrl)
                {
                    //加载网页
                    this.ShowQueryWebPage(queryUrl);
                    currentUrl = WebBrowserMain.Url.ToString();
                }

                if (currentUrl != queryUrl)
                {
                    throw new Exception("无法定位到查询页面.");
                }
                else
                {
                    //在网页中submit
                    this.InvokeDoQuery(billNo); 
                    //记录查询到的返回值
                    Dictionary<string, string> resultValues = null;

                    //存在异步加载数据的情况，此处用轮询获取查询到的数据
                    while (resultValues == null)
                    {
                        if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                        {
                            //超时
                            this.RunPage.InvokeAppendLogText("点击查询后, 获取信息超时!", Base.EnumTypes.LogLevelType.System, true);
                            throw new Exception("点击查询后, 获取信息超时!");
                        }
                        waitCount++;
                        Thread.Sleep(SysConfig.WebPageRequestInterval);
                        try
                        {
                            //获取返回的数据
                            resultValues = GetRowInfo(dEW,resultValues);
                        }
                        catch (FclDeclareException dex)
                        {
                            if (dex.ErrorCode == FclDeclareException.ErrorCode_GettingDelieryInfo)
                            {
                                //如果还是正在等待查询结果，那么继续轮询
                                continue;
                            }
                            else if (dex.ErrorCode == FclDeclareException.ErrorCode_ErrorTxtCode)
                            {
                                //输入的验证码错误，是由于验证码识别错误造成的
                                break;
                            }
                            else
                            {
                                //如果查询的提运单号不正确，或者其他的未知错误，那么直接抛出异常
                                throw dex;
                            }
                        }
                    }
                    return resultValues;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.RunPage.InvokeDisposeWebBrowser();
                GC.Collect();
            }
        }
        #endregion

        #region 点击查询后，获取信息
        private Dictionary<string, string> GetRowInfo(CsvWriter dEW, Dictionary<string, string> resultValues)
        {
            //获取到当前webBrowser的document的html
            string webPageHtml = this.RunPage.InvokeGetPageHtml();

            //构造成HtmlAgilityPack.HtmlDocument对象，方便查询
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);


            HtmlAgilityPack.HtmlNode checkNode = htmlDoc.DocumentNode.SelectSingleNode("//table[@id=\"dataTable\"]/tbody/tr[1]/td[@class=\"text-blue bold\"]");
            if (checkNode == null)
            {
                //没有对应的报关单信息 
                throw new FclDeclareException(FclDeclareException.ErrorCode_NoneExistDelivery, "不存在的报关信息");
            }
            else
            {
                if(!checkNode.HasAttributes){
                    //没有对应的提运单信息 
                    throw new FclDeclareException(FclDeclareException.ErrorCode_GettingDelieryInfo, "正在加载数据");
                }
                else
                {
                    //获取网页中包含的查询状态信息
                    HtmlAgilityPack.HtmlNodeCollection tdNodes = htmlDoc.DocumentNode.SelectNodes("//table[@id=\"dataTable\"]/tbody/tr/td[@class=\"text-blue bold\" or @class=\"dClass\"]");

                    //如果查询状态为空，那么可能是已经获取到查询结果了
                    Dictionary<string, string> p2vs = new Dictionary<string, string>();
                    if (tdNodes != null)
                    {
                        for (int i = 0; i < tdNodes.Count; i++)
                        {
                            //已经明确获取到信息 

                            p2vs.Add("报关单号", tdNodes[i].InnerText.Trim());
                            i++;
                            p2vs.Add("提运单号", tdNodes[i].InnerText.Trim());
                            i++;
                            p2vs.Add("箱号", tdNodes[i].InnerText.Trim());
                            i++;
                            p2vs.Add("船名/航次", tdNodes[i].InnerText.Trim());
                            i++;
                            p2vs.Add("放行状态", tdNodes[i].InnerText.Trim());
                            i++;
                            p2vs.Add("EDI中心接收时间", tdNodes[i].InnerText.Trim());
                            i++;

                            dEW.AddRow(p2vs);

                            p2vs.Clear();
                        }
                    }
                    else
                    {
                        //没有对应的提运单信息 
                        throw new FclDeclareException(FclDeclareException.ErrorCode_NoneExistDelivery, "不存在的理货信息");
                    }
                    //返回
                    return p2vs;
                }
            }
        }
        #endregion

        #region 显示登录网页
        private void ShowLoginWebPage(string url)
        {
            this.RunPage.InvoceShowWebPage(url);
            int waitCount = 0;
            while (!this.RunPage.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                {
                    this.RunPage.InvokeAppendLogText("请求匿名登录页超时!", Base.EnumTypes.LogLevelType.System, true);
                    //超时
                    throw new Exception("请求匿名登录页超时. PageUrl = " + url);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }
           
            //再增加个等待，等待异步加载的数据
            Thread.Sleep(1000);
            WebBrowserMain = this.RunPage.GetWebBrowser();
            
        }
        #endregion

        #region 显示查询网页
        private void ShowQueryWebPage(string url)
        {
            this.RunPage.InvoceShowWebPage(url);
            int waitCount = 0;
            while (!this.RunPage.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                {
                    this.RunPage.InvokeAppendLogText("请求查询页面超时!", Base.EnumTypes.LogLevelType.System, true);
                    //超时
                    throw new Exception("请求查询页面超时. PageUrl = " + url);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }

            //再增加个等待，等待异步加载的数据
            Thread.Sleep(3000);
            WebBrowserMain = this.RunPage.GetWebBrowser();
            InvokeSetQueryScript();
        }
        #endregion  

        #region 获取验证码并识别
        public string GetTxtCode()
        {
            string txtCode = "";
            Bitmap img = null;
            try
            {
                //获取验证码图片
                Image souceImg = InvokeGetWebImage(WebBrowserMain, "captcha-pic");
                img = SimpleOCR.To16Bmp(new Bitmap(souceImg));
                string imgPath = Path.Combine(Application.StartupPath, "1.bmp");
                img.Save(imgPath);

                //去除边框
                for (int i = 0; i < img.Width; i++)
                {
                    img.SetPixel(i, 0, Color.White);
                    img.SetPixel(i, img.Height - 1, Color.White);
                }
                for (int j = 0; j < img.Height; j++)
                {
                    img.SetPixel(0, j, Color.White);
                    img.SetPixel(img.Width - 1, j, Color.White);
                }

                //简单去除噪音 
                img = SimpleOCR.ReplaceByAround(img, 1, 1, Color.White);

                //二值化
                //img2 = SimpleOCR.ConvertToBlackWhite(img, Color.White);
                //img = SimpleOCR.ConvertTo2Color(img, Color.Black);

                //保存处理后图片
                img.Save("d:\\2.Bmp");

                //识别
                Dictionary<string, string> vars = new Dictionary<string, string>();
                vars.Add("tessedit_char_whitelist", "0123456789");
                //string tessdata = @"F:\Code\OCRTool\OCRTool\bin\Debug\tessdata";
                string tessdata = @"C:\Program Files (x86)\Tesseract-OCR\tessdata";
                string language = "eng";
                txtCode = SimpleOCR.OCRSingleLine(img, tessdata, language, vars).Trim().Replace(" ", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (img != null)
                {
                    img.Dispose();
                }
            }
            return txtCode;
        }
        #endregion

        #region 在网页中获取图片
        private Image InvokeGetWebImage(WebBrowser webCtl, string imgeTagId)
        {
            //采用异步获取，因为跨线程了
            return (Image)WebBrowserMain.Invoke(new GetWebImageInvokeDelegate(GetWebImage), new object[] { webCtl, imgeTagId });
        }
        private delegate Image GetWebImageInvokeDelegate(WebBrowser webCtl, string imgeTagId);
        /// <summary>
        /// 返回指定WebBrowser中图片<IMG></IMG>中的图内容
        /// </summary>
        /// <param name="webCtl">WebBrowser控件</param>
        /// <param name="imgeTag">IMG元素</param>
        /// <returns>IMG对象</returns>
        private Image GetWebImage(WebBrowser webCtl, string imgeTagId)
        {
            System.Windows.Forms.HtmlDocument winHtmlDoc = webCtl.Document;
            HTMLDocument doc = (HTMLDocument)winHtmlDoc.DomDocument;
            HtmlElement imgTag = winHtmlDoc.GetElementById(imgeTagId);
            HTMLBody body = (HTMLBody)doc.body;
            IHTMLControlRange rang = (IHTMLControlRange)body.createControlRange();
            IHTMLControlElement imgE = (IHTMLControlElement)imgTag.DomElement; //图片地址
            rang.add(imgE);
            rang.execCommand("Copy", false, null);  //拷贝到内存
            Image numImage = Clipboard.GetImage();
            return numImage;
        }
        #endregion

        #region 提交登录数据
        private void InvokeDoSubmit(string user_id, string user_pwd, string captcha)
        {
            WebBrowserMain.Invoke(new DoSubmitInvokeDelegate(DoSubmit), new object[] { user_id, user_pwd, captcha });
        }
        private delegate void DoSubmitInvokeDelegate(string user_id, string user_pwd, string captcha);
        private void DoSubmit(string user_id, string user_pwd, string captcha)
        {
            WebBrowserMain.Document.InvokeScript("doSubmit", new object[] { user_id, user_pwd, captcha });
        }
        #endregion 
        
        #region 注入登录操作代码
        private void InvokeSetScript()
        {
            WebBrowserMain.Invoke(new SetScriptInvokeDelegate(SetScript));
        }
        private delegate void SetScriptInvokeDelegate();
        private void SetScript()
        {
            HtmlElement doSubmitElement = WebBrowserMain.Document.CreateElement("script");
            IHTMLScriptElement doSubmitScriptElement = (IHTMLScriptElement)doSubmitElement.DomElement;
            /*
            控件id
            userId 用户名
            userPasswd 密码
            textfield3 验证码
            sub 登录按钮
            */
            doSubmitScriptElement.text = "function doSubmit(user_id, user_pwd, captcha){"
                                + "$('#txtName').val(user_id);"
                                + "$('#txtPwd').val(user_pwd);"
                                + "$('#txtYZM').val(captcha);"
                                + "authorizationOnClick();"
                                + "}";
            WebBrowserMain.Document.Body.AppendChild(doSubmitElement);
        }
        #endregion

        #region 提交查询数据
        private void InvokeDoQuery(string billNo)
        {
            WebBrowserMain.Invoke(new DoQueryInvokeDelegate(DoQuery), new object[] { billNo});
        }
        private delegate void DoQueryInvokeDelegate(string billNo);
        private void DoQuery(string billNo)
        {
            WebBrowserMain.Document.InvokeScript("doQuery", new object[] { billNo});
        }
        #endregion 

        #region 注入查询代码
        private void InvokeSetQueryScript()
        {
            WebBrowserMain.Invoke(new SetQueryScriptInvokeDelegate(SetQueryScript));
        }
        private delegate void SetQueryScriptInvokeDelegate();
        private void SetQueryScript()
        {
            HtmlElement doQueryElement = WebBrowserMain.Document.CreateElement("script");
            IHTMLScriptElement doQueryScriptElement = (IHTMLScriptElement)doQueryElement.DomElement;
            doQueryScriptElement.text = "function doQuery(billNo){"
                                + "$('#queryInput').val(billNo);"
                                + "var evt = $.Event('keydown', {keyCode: 13});"
                                + "$('#queryInput').trigger(evt);"
                                + "}";
            WebBrowserMain.Document.Body.AppendChild(doQueryElement);
        }
        #endregion

        #region 检测当前是否是登录状态
        // 返回是表示登录状态
        private bool IsLogin(WebBrowser webCtl)
        {
            //获取到当前webBrowser的document的html
            string webPageHtml = this.RunPage.InvokeGetPageHtml();

            //构造成HtmlAgilityPack.HtmlDocument对象，方便查询
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);

            HtmlAgilityPack.HtmlNode topNode = htmlDoc.DocumentNode.SelectSingleNode("//ul[@class=\"nav left-panel-log\"]");
            return topNode != null;
        }
        #endregion
    }
}
