﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetDataAccess.Extended.Oheng
{
    /// <summary>
    /// 从html中获取提运单信息时发生的异常
    /// </summary>
    public class DeliveryException : Exception
    {
        #region 预定义的错误码
        /// <summary>
        /// 正在获取
        /// </summary>
        public const string ErrorCode_GettingDelieryInfo = "002";

        /// <summary>
        /// 错误的验证码
        /// </summary>
        public const string ErrorCode_ErrorTxtCode = "003";

        /// <summary>
        /// 不存在此提运单
        /// </summary>
        public const string ErrorCode_NoneExistDelivery = "004";

        /// <summary>
        /// 未知的错误
        /// </summary>
        public const string ErrorCode_Unknown = "005";
        #endregion

        #region 本次的错误码
        private string _ErrorCode = null;
        /// <summary>
        /// 错误码
        /// </summary>
        public string ErrorCode
        {
            get
            {
                return _ErrorCode;
            }
        }
        #endregion

        #region 构造函数
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="code"></param>
        /// <param name="message"></param>
        public DeliveryException(string code, string message)
            : base(message)
        {
            _ErrorCode = code;
        }
        #endregion
    }
}
