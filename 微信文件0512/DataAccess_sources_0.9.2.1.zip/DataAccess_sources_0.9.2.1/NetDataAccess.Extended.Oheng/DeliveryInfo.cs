﻿using System;
using System.Collections.Generic;
using System.Text;
using NetDataAccess.Base.DLL;
using NetDataAccess.Base.Config;
using System.Threading;
using System.Windows.Forms;
using mshtml;
using NetDataAccess.Base.Definition;
using System.IO;
using NetDataAccess.Base.Common; 
using NetDataAccess.Base.DB;
using NetDataAccess.Base.Writer;
using NetDataAccess.Base.Reader;
using NetDataAccess.Base.CsvHelper;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using HtmlAgilityPack;

namespace NetDataAccess.Extended.Oheng
{
    /// <summary>
    /// 获取海关提供的提运单信息
    /// </summary>
    public class DeliveryInfo : CustomProgramBase
    {
        #region 获取网页信息超时时间
        /// <summary>
        /// 获取网页信息超时时间
        /// </summary>
        private int WebRequestTimeout = 120 * 1000;
        #endregion

        #region 浏览器控件
        /// <summary>
        /// 浏览器控件
        /// </summary>
        private WebBrowser WebBrowserMain = null;
        #endregion

        #region 提运单信息查询网址
        /// <summary>
        /// 提运单信息查询网址
        /// </summary>
        private string pageUrl = "http://query.customs.gov.cn/MNFTQ/MQuery.aspx";
        #endregion

        #region 获取提运单信息
        public bool Run(string parameters, IListSheet listSheet)
        {
            //输出的文件
            CsvWriter dEW = null;
            try
            { 
                //输入参数
                string[] ps = parameters.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                
                string gqdm = ps[0];
                string ysfs = ps[1];
                string jcjbz = ps[2];
                string tydh = ps[3];
                string exportFileName = ps[4];
                /*
                string gqdm = "2248";
                string ysfs = "海运";
                string jcjbz = "进口";
                string tydh = "MOLU27803176208";
                string exportFileName = "提运单信息查询结果20151220.csv";
                */    

                //输入的文件夹
                string exportDir = Path.Combine(this.RunPage.OutputFileDir, this.RunPage.Project.Name);
                string pPath = Path.Combine(exportDir, exportFileName);

                //构造输出文件的列
                Dictionary<string, int> pColumnDic = new Dictionary<string, int>();
                pColumnDic.Add("关区代码", 0);
                pColumnDic.Add("运输方式", 1);
                pColumnDic.Add("提运单类型", 2);
                pColumnDic.Add("运输工具名称", 3);
                pColumnDic.Add("航班\\航次", 4);
                pColumnDic.Add("提运单号", 5);
                pColumnDic.Add("进出境日期", 6);
                pColumnDic.Add("件数", 7);
                pColumnDic.Add("重量", 8);
                pColumnDic.Add("进口抵港确报标志", 9);
                pColumnDic.Add("理货状态", 10);
                pColumnDic.Add("出口运抵状态", 11);

                //记录获取的提运单信息
                Dictionary<string, string> resultValueDic = null;

                //允许重新获取次数
                const int allowRetryCount = 5;
                int errorCount = 0;
                while (resultValueDic == null && errorCount < allowRetryCount)
                {
                    //获取提运单信息
                    resultValueDic = GetOne(dEW, gqdm, ysfs, jcjbz, tydh);
                    if (resultValueDic == null)
                    {
                        errorCount++;
                    }
                } 

                //创建记录提运单信息的文件并保存
                dEW = new CsvWriter(pPath, pColumnDic);
                dEW.AddRow(resultValueDic);
                dEW.SaveToDisk();
            }
            catch (Exception ex)
            { 
                throw ex;
            }

            return true;
        }
        #endregion

        #region 获取一个提单信息
        private Dictionary<string,string> GetOne(CsvWriter dEW, string gqdm, string ysfs, string jcjbz, string tydh)
        {
            try
            {
                //记录识别验证码
                string txtCode = "";

                //允许验证码识别次数
                const int allowTxtCodeRetryCount = 10;

                //记录验证码识别错误次数
                int txtCodeErrorCount = 0;

                //因为识别率不高，所以需要重新加载多次网页，直到识别出四个字符的验证码
                while (txtCode.Length != 4 && txtCodeErrorCount < allowTxtCodeRetryCount)
                {
                    //加载网页
                    this.ShowWebPage(pageUrl);

                    //识别验证码
                    //txtCode = GetTxtCode();
                    txtCode = "1234";
                }

                if (txtCodeErrorCount == allowTxtCodeRetryCount)
                {
                    throw new Exception("验证码识别次数超过" + allowTxtCodeRetryCount + "次, 宣告识别");
                }
                else
                {
                    //在网页中submit查询信息和验证码
                    //this.InvokeDoSubmit(gqdm, ysfs, jcjbz, tydh, txtCode);
                    this.InvokeDoSubmit(gqdm, ysfs, jcjbz, tydh);

                    //轮询次数
                    int waitCount = 0;

                    //轮询获取当前webBrowser上的信息，直到webBrowser控件加载完成
                    while (!this.RunPage.IsNavigateCompleted)
                    {
                        if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                        {
                            //超时
                            this.RunPage.InvokeAppendLogText("点击查询后, 响应超时!", Base.EnumTypes.LogLevelType.System, true);
                            throw new Exception("点击查询后, 响应超时!");
                        }
                        //等待
                        waitCount++;
                        Thread.Sleep(SysConfig.WebPageRequestInterval);
                    }

                    //再增加个等待，可能网页会有异步加载数据的情况，等待时间视访问的网页不同而定，此等待不是必须的
                    Thread.Sleep(1000);

                    //在webBrowser的document，即html中增加js脚本，供本程序调用
                    InvokeSetScript();

                    //记录查询到的返回值
                    Dictionary<string, string> resultValues = null;

                    //存在异步加载数据的情况，此处用轮询获取查询到的数据
                    while (resultValues == null)
                    {
                        if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                        {
                            //超时
                            this.RunPage.InvokeAppendLogText("点击查询后, 获取信息超时!", Base.EnumTypes.LogLevelType.System, true);
                            throw new Exception("点击查询后, 获取信息超时!");
                        }
                        waitCount++;
                        Thread.Sleep(SysConfig.WebPageRequestInterval);
                        try
                        {
                            //获取返回的数据
                            resultValues = GetRowInfo(resultValues);
                        }
                        catch (DeliveryException dex)
                        {
                            if (dex.ErrorCode == DeliveryException.ErrorCode_GettingDelieryInfo)
                            {
                                //如果还是正在等待查询结果，那么继续轮询
                                continue;
                            }
                            else if (dex.ErrorCode == DeliveryException.ErrorCode_ErrorTxtCode)
                            {
                                //输入的验证码错误，是由于验证码识别错误造成的
                                break;
                            }
                            else
                            {
                                //如果查询的提运单号不正确，或者其他的未知错误，那么直接抛出异常
                                throw dex;
                            }
                        }
                    }
                    return resultValues;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.RunPage.InvokeDisposeWebBrowser();
                GC.Collect();
            }
        }
        #endregion

        #region 点击查询后，获取信息
        private Dictionary<string, string> GetRowInfo(Dictionary<string, string> resultValues)
        {
            //获取到当前webBrowser的document的html
            string webPageHtml = this.RunPage.InvokeGetPageHtml();

            //构造成HtmlAgilityPack.HtmlDocument对象，方便查询
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);

            //获取网页中包含的查询状态信息
            HtmlAgilityPack.HtmlNode statusNode = htmlDoc.DocumentNode.SelectSingleNode("//*[@id=\"MQueryCtrl1_tdMessage\"]");
            string status = statusNode.InnerText.Replace("&nbsp;", " ").Trim();

            //如果查询状态为空，那么可能是已经获取到查询结果了
            if (status.Length == 0)
            {
                //获取展示查询结果的table
                HtmlAgilityPack.HtmlNode tableNode = htmlDoc.DocumentNode.SelectSingleNode("//*[@id=\"MQueryCtrl1_dgView\"]");
                if (tableNode == null)
                {
                    //如果没有获取到此table，那么说明还是在等待状态
                    throw new DeliveryException(DeliveryException.ErrorCode_GettingDelieryInfo, "解析html出错，没有获取到信息表.");
                }
                else
                {
                    HtmlAgilityPack.HtmlNodeCollection trNodes = tableNode.SelectNodes("./tbody/tr");
                    if (trNodes.Count < 2)
                    {
                        throw new DeliveryException(DeliveryException.ErrorCode_GettingDelieryInfo, "解析html出错，没有获取到信息行.");
                    }
                    else
                    {
                        //已经明确获取到信息
                        HtmlAgilityPack.HtmlNode trNode = trNodes[1];
                        HtmlNodeCollection tdNodes = trNode.SelectNodes("./td");
                        Dictionary<string, string> p2vs = new Dictionary<string, string>();
                        p2vs.Add("关区代码", tdNodes[0].InnerText.Trim());
                        p2vs.Add("运输方式", tdNodes[1].InnerText.Trim());
                        p2vs.Add("提运单类型", tdNodes[2].InnerText.Trim());
                        p2vs.Add("运输工具名称", tdNodes[3].InnerText.Trim());
                        p2vs.Add("航班\\航次", tdNodes[4].InnerText.Trim());
                        p2vs.Add("提运单号", tdNodes[5].InnerText.Trim());
                        p2vs.Add("进出境日期", tdNodes[6].InnerText.Trim());
                        p2vs.Add("件数", tdNodes[7].InnerText.Trim());
                        p2vs.Add("重量", tdNodes[8].InnerText.Trim());
                        p2vs.Add("进口抵港确报标志", tdNodes[9].InnerText.Trim());
                        p2vs.Add("理货状态", tdNodes[10].InnerText.Trim());
                        p2vs.Add("出口运抵状态", tdNodes[11].InnerText.Trim());

                        //返回
                        return p2vs;
                    }
                }
            }
            else
            {
                //验证码错误
                if (status.Contains("验证码"))
                {
                    throw new DeliveryException(DeliveryException.ErrorCode_ErrorTxtCode, status);
                }
                //没有对应的提运单信息
                else if (status.Contains("没有找到"))
                {
                    throw new DeliveryException(DeliveryException.ErrorCode_NoneExistDelivery, status);
                }
                //其它未知错误
                else
                {
                    throw new DeliveryException(DeliveryException.ErrorCode_Unknown, status);
                }
            }
        }
        #endregion

        #region 在网页中获取图片
        private Image InvokeGetWebImage(WebBrowser webCtl, string imgeTagId)
        {
            //采用异步获取，因为跨线程了
            return (Image)WebBrowserMain.Invoke(new GetWebImageInvokeDelegate(GetWebImage), new object[] { webCtl, imgeTagId });
        }
        private delegate Image GetWebImageInvokeDelegate(WebBrowser webCtl, string imgeTagId);
        /// <summary>
        /// 返回指定WebBrowser中图片<IMG></IMG>中的图内容
        /// </summary>
        /// <param name="webCtl">WebBrowser控件</param>
        /// <param name="imgeTag">IMG元素</param>
        /// <returns>IMG对象</returns>
        private Image GetWebImage(WebBrowser webCtl, string imgeTagId)
        {
            System.Windows.Forms.HtmlDocument winHtmlDoc = webCtl.Document;
            HTMLDocument doc = (HTMLDocument)winHtmlDoc.DomDocument;
            HtmlElement imgTag = winHtmlDoc.GetElementById(imgeTagId); 
            HTMLBody body = (HTMLBody)doc.body;
            IHTMLControlRange rang = (IHTMLControlRange)body.createControlRange();
            IHTMLControlElement imgE = (IHTMLControlElement)imgTag.DomElement; //图片地址
            rang.add(imgE);
            rang.execCommand("Copy", false, null);  //拷贝到内存
            Image numImage = Clipboard.GetImage(); 
            return numImage;
        }
        #endregion

        #region 获取验证码并识别
        public string GetTxtCode()
        {
            string txtCode = "";
            Image souceImg = null;
            Bitmap img = null; 
            try
            {
                //获取验证码图片
                souceImg = InvokeGetWebImage(WebBrowserMain, "MQueryCtrl1_imgCode");
                
                //获取图片
                //string imgUrl = "http://query.customs.gov.cn/MNFTQ/Image.aspx";
                //FileRequest fr = new FileRequest();
                //byte[] data = fr.GetFileByRequest(imgUrl, 1, 30); 
                img = SimpleOCR.To16Bmp(new Bitmap(souceImg));
                string imgPath = Path.Combine(Application.StartupPath, "1.bmp");
                img.Save(imgPath);

                //去除边框
                for (int i = 0; i < img.Width; i++)
                {
                    img.SetPixel(i, 0, Color.White);
                    img.SetPixel(i, img.Height - 1, Color.White);
                }
                for (int j = 0; j < img.Height; j++)
                {
                    img.SetPixel(0, j, Color.White);
                    img.SetPixel(img.Width - 1, j, Color.White);
                }

                //简单去除噪音
                img = SimpleOCR.ReplaceByAround(img, 1, 1, Color.White);

                //二值化
                //img2 = SimpleOCR.ConvertToBlackWhite(img, Color.White);

                //保存处理后图片
                img.Save("d:\\2.Bmp");

                //识别
                Dictionary<string, string> vars = new Dictionary<string, string>();
                vars.Add("tessedit_char_whitelist", "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
                string tessdata = @"F:\Code\OCRTool\OCRTool\bin\Debug\tessdata";
                string language = "eng";
                txtCode = SimpleOCR.OCRSingleLine(img, tessdata, language, vars).Trim().Replace(" ", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //释放
                if (souceImg != null)
                {
                    souceImg.Dispose();
                }
                if (img != null)
                {
                    img.Dispose();
                }
            }
            return txtCode;
        }
        #endregion

        #region 显示网页
        private void ShowWebPage(string url)
        {
            this.RunPage.InvoceShowWebPage(url);
            int waitCount = 0;
            while (!this.RunPage.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                {
                    this.RunPage.InvokeAppendLogText("请求查询页面超时!", Base.EnumTypes.LogLevelType.System, true); 
                    //超时
                    throw new Exception("请求查询页面超时. PageUrl = " + url);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }

            //再增加个等待，等待异步加载的数据
            Thread.Sleep(3000);
            WebBrowserMain = this.RunPage.GetWebBrowser();
            InvokeSetScript();
        }
        #endregion  
        
        #region (以注释)提交数据
        //private void InvokeDoSubmit(string gqdm, string ysfs, string jcjbz, string tydh, string txtCode)
        //{
        //    WebBrowserMain.Invoke(new DoSubmitInvokeDelegate(DoSubmit), new object[] { gqdm, ysfs, jcjbz, tydh, txtCode });
        //}
        //private delegate void DoSubmitInvokeDelegate(string gqdm, string ysfs, string jcjbz, string tydh, string txtCode);
        //private void DoSubmit(string gqdm, string ysfs, string jcjbz, string tydh, string txtCode)
        //{
        //    WebBrowserMain.Document.InvokeScript("doSubmit", new object[] { gqdm, ysfs, jcjbz, tydh, txtCode });
        //}
        #endregion 

        #region 提交数据
        private void InvokeDoSubmit(string gqdm, string ysfs, string jcjbz, string tydh)
        {
            WebBrowserMain.Invoke(new DoSubmitInvokeDelegate(DoSubmit), new object[] { gqdm, ysfs, jcjbz, tydh });
        }
        private delegate void DoSubmitInvokeDelegate(string gqdm, string ysfs, string jcjbz, string tydh);
        private void DoSubmit(string gqdm, string ysfs, string jcjbz, string tydh)
        {
            WebBrowserMain.Document.InvokeScript("doSubmit", new object[] { gqdm, ysfs, jcjbz, tydh });
        }
        #endregion 

        #region 注入代码
        private void InvokeSetScript( )
        {
            WebBrowserMain.Invoke(new SetScriptInvokeDelegate(SetScript) );
        }
        private delegate void SetScriptInvokeDelegate( );
        private void SetScript()
        {
            HtmlElement doSubmitElement = WebBrowserMain.Document.CreateElement("script");
            IHTMLScriptElement doSubmitScriptElement = (IHTMLScriptElement)doSubmitElement.DomElement;
            /*
            控件id
            MQueryCtrl1_ddlCustomCode 2225
            MQueryCtrl1_ddlTransport 2 海运
            MQueryCtrl1_ddlBillType 1 进口
            MQueryCtrl1_txtChildNo 提运单号
            //MQueryCtrl1_txtCode 验证码
            MQueryCtrl1_tdMessage 查询状态
            MQueryCtrl1_btQuery 查询按钮
            */
            doSubmitScriptElement.text = "function doSubmit(customCode, transport, billType, childNo, txtCode){"
                                + "$('#MQueryCtrl1_ddlCustomCode').val(customCode); "
                                + "$('#MQueryCtrl1_ddlTransport').val(transport); "
                                + "$('#MQueryCtrl1_ddlBillType').val(billType); "
                                + "$('#MQueryCtrl1_txtChildNo').val(childNo); "
                                //+ "$('#MQueryCtrl1_txtCode').val(txtCode); "
                                + "$('#MQueryCtrl1_tdMessage').text(''); " 
                                + "$('#MQueryCtrl1_btQuery').click();"
                                + "}";
            WebBrowserMain.Document.Body.AppendChild(doSubmitElement);
        }
        #endregion
    }
}