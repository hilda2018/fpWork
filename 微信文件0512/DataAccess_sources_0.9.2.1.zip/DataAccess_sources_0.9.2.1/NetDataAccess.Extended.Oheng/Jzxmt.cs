﻿using System;
using System.Collections.Generic;
using System.Text;
using NetDataAccess.Base.DLL;
using NetDataAccess.Base.Config;
using System.Threading;
using System.Windows.Forms;
using mshtml;
using NetDataAccess.Base.Definition;
using System.IO;
using NetDataAccess.Base.Common; 
using NetDataAccess.Base.DB;
using NetDataAccess.Base.Writer;
using NetDataAccess.Base.Reader;
using NetDataAccess.Base.CsvHelper;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using HtmlAgilityPack;
using AutomaticControl;

namespace NetDataAccess.Extended.Oheng
{
    /// <summary>
    /// 集装箱码头
    /// </summary>
    public class Jzxmt : CustomProgramBase
    {
        #region 获取网页信息超时时间
        /// <summary>
        /// 获取网页信息超时时间
        /// </summary>
        private int WebRequestTimeout = 120 * 1000;
        #endregion

        #region 浏览器控件
        /// <summary>
        /// 浏览器控件
        /// </summary>
        private WebBrowser WebBrowserMain = null;
        #endregion 

        #region 获取理货信息
        public bool Run(string parameters, IListSheet listSheet)
        {
            //输出的文件
            CsvWriter dEW = null;
            try
            { 
                //输入参数
                string[] ps = parameters.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                
                string boxNum = ps[0]; 
                string exportFileName = ps[1]; 

                //输入的文件夹
                string exportDir = Path.Combine(this.RunPage.OutputFileDir, this.RunPage.Project.Name);
                string pPath = Path.Combine(exportDir, exportFileName);

                //构造输出文件的列
                Dictionary<string, int> pColumnDic = new Dictionary<string, int>();
                pColumnDic.Add("船名", 0);
                pColumnDic.Add("航次", 1);
                pColumnDic.Add("进出口", 2);
                pColumnDic.Add("报文类型", 3);
                pColumnDic.Add("箱号", 4);
                pColumnDic.Add("提单号", 5);
                pColumnDic.Add("回执类型", 6);
                pColumnDic.Add("回执数据", 7);
                pColumnDic.Add("入库时间", 8);

                //记录获取的提运单信息
                Dictionary<string, string> resultValueDic = null;

                //允许重新获取次数
                const int allowRetryCount = 5;
                int errorCount = 0;
                while (resultValueDic == null && errorCount < allowRetryCount)
                {
                    //获取提运单信息
                    resultValueDic = GetOne(dEW, boxNum);
                    if (resultValueDic == null)
                    {
                        errorCount++;
                    }
                } 

                //创建记录提运单信息的文件并保存
                dEW = new CsvWriter(pPath, pColumnDic);
                dEW.AddRow(resultValueDic);
                dEW.SaveToDisk();
            }
            catch (Exception ex)
            { 
                throw ex;
            }

            return true;
        }
        #endregion

        #region 获取一个提单信息
        private Dictionary<string, string> GetOne(CsvWriter dEW, string boxNum)
        {
            try
            {
                //允许跳转到查询页面的次数，有时会出现跳转至登录页面的情况
                const int allowGoToQueryPageCount = 10;

                int goToQueryPageErrorCount = 0;

                string queryUrl = "http://www.spict.com/portinfo/Normal/ShipPlanPage.aspx";

                string currentUrl = "";

                while (currentUrl != queryUrl && goToQueryPageErrorCount < allowGoToQueryPageCount)
                {
                    //加载网页 
                    this.ShowQueryWebPage(queryUrl);

                    currentUrl = WebBrowserMain.Url.ToString();
                }

                if (currentUrl != queryUrl)
                {
                    throw new Exception("无法定位到查询页面.");
                }
                else
                {
                    //在网页中submit
                    this.InvokeDoQuery(boxNum);

                    //轮询次数
                    int waitCount = 0;

                    //轮询获取当前webBrowser上的信息，直到webBrowser控件加载完成
                    while (1 == 1)//!this.RunPage.IsNavigateCompleted)
                    {
                        //等待
                        waitCount++;
                        Thread.Sleep(SysConfig.WebPageRequestInterval);
                    }

                    //再增加个等待，可能网页会有异步加载数据的情况，等待时间视访问的网页不同而定，此等待不是必须的
                    Thread.Sleep(1000);

                    //记录查询到的返回值
                    Dictionary<string, string> resultValues = null;

                    //存在异步加载数据的情况，此处用轮询获取查询到的数据
                    while (resultValues == null)
                    {
                        if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                        {
                            //超时
                            this.RunPage.InvokeAppendLogText("点击查询后, 获取信息超时!", Base.EnumTypes.LogLevelType.System, true);
                            throw new Exception("点击查询后, 获取信息超时!");
                        }
                        waitCount++;
                        Thread.Sleep(SysConfig.WebPageRequestInterval);
                        try
                        {
                            if (this.WebBrowserMain.Url.ToString().Contains(queryUrl))
                            {
                                //获取返回的数据
                                resultValues = GetRowInfo(resultValues);
                            }
                            else
                            {
                                throw new GoodsReportException(GoodsReportException.ErrorCode_RedirectLoginCode, "自动跳转到了登录页面.");
                            }
                        }
                        catch (GoodsReportException dex)
                        {
                            if (dex.ErrorCode == GoodsReportException.ErrorCode_GettingDelieryInfo)
                            {
                                //如果还是正在等待查询结果，那么继续轮询
                                continue;
                            }
                            else if (dex.ErrorCode == GoodsReportException.ErrorCode_RedirectLoginCode)
                            {
                                //自动跳转到了登录页面，对方系统有问题造成的
                                break;
                            }
                            else
                            {
                                //如果查询的集装箱号不正确，或者其他的未知错误，那么直接抛出异常
                                throw dex;
                            }
                        }
                    }
                    return resultValues;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.RunPage.InvokeDisposeWebBrowser();
                GC.Collect();
            }
        }
        #endregion

        #region 点击查询后，获取信息
        private Dictionary<string, string> GetRowInfo(Dictionary<string, string> resultValues)
        {
            //获取到当前webBrowser的document的html
            string webPageHtml = this.RunPage.InvokeGetPageHtml();

            //构造成HtmlAgilityPack.HtmlDocument对象，方便查询
            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
            htmlDoc.LoadHtml(webPageHtml);


            HtmlAgilityPack.HtmlNode checkNode = htmlDoc.DocumentNode.SelectSingleNode("//*[@id=\"CtnBigShipTallyRptReceiptInfoList\"]");
            if (checkNode.InnerText.Contains("正在加载数据"))
            {
                //没有对应的提运单信息 
                throw new DeliveryException(DeliveryException.ErrorCode_GettingDelieryInfo, "正在加载数据");
            }
            else
            {
                //获取网页中包含的查询状态信息
                HtmlAgilityPack.HtmlNodeCollection tdNodes = htmlDoc.DocumentNode.SelectNodes("//*[@class=\"x-grid3-row-table\"]/tbody/tr[1]/td");

                //如果查询状态为空，那么可能是已经获取到查询结果了
                if (tdNodes != null && tdNodes.Count > 0)
                {
                    //已经明确获取到信息 
                    Dictionary<string, string> p2vs = new Dictionary<string, string>();
                    p2vs.Add("船名", tdNodes[0].InnerText.Trim());
                    p2vs.Add("航次", tdNodes[1].InnerText.Trim());
                    p2vs.Add("进出口", tdNodes[2].InnerText.Trim());
                    p2vs.Add("报文类型", tdNodes[3].InnerText.Trim());
                    p2vs.Add("箱号", tdNodes[4].InnerText.Trim());
                    p2vs.Add("提单号", tdNodes[5].InnerText.Trim());
                    p2vs.Add("回执类型", tdNodes[6].InnerText.Trim());
                    p2vs.Add("回执数据", tdNodes[7].InnerText.Trim());
                    p2vs.Add("入库时间", tdNodes[8].InnerText.Trim());

                    //返回
                    return p2vs;
                }
                else
                {
                    //没有对应的提运单信息 
                    throw new DeliveryException(DeliveryException.ErrorCode_NoneExistDelivery, "不存在的理货信息");
                }
            }
        }
        #endregion

        #region 显示网页
        private void ShowLoginWebPage(string url)
        {
            this.RunPage.InvoceShowWebPage(url);
            int waitCount = 0;
            while (!this.RunPage.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                {
                    this.RunPage.InvokeAppendLogText("请求匿名登录页超时!", Base.EnumTypes.LogLevelType.System, true);
                    //超时
                    throw new Exception("请求匿名登录页超时. PageUrl = " + url);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }

            //再增加个等待，等待异步加载的数据
            Thread.Sleep(1000); 
        }
        #endregion

        #region 显示查询网页
        private void ShowQueryWebPage(string url)
        {
            this.RunPage.InvoceShowWebPage(url);
            int waitCount = 0;
            while (!this.RunPage.IsNavigateCompleted)
            {
                if (SysConfig.WebPageRequestInterval * waitCount > WebRequestTimeout)
                {
                    this.RunPage.InvokeAppendLogText("请求查询页面超时!", Base.EnumTypes.LogLevelType.System, true);
                    //超时
                    throw new Exception("请求查询页面超时. PageUrl = " + url);
                }
                //等待
                waitCount++;
                Thread.Sleep(SysConfig.WebPageRequestInterval);
            }

            //再增加个等待，等待异步加载的数据
            Thread.Sleep(3000);
            WebBrowserMain = this.RunPage.GetWebBrowser();
            InvokeSetQueryScript();
        }
        #endregion  
        
        #region 提交数据
        private void InvokeDoQuery(string boxNum)
        { 
            //改为通过控制鼠标键盘实现 
            //要保证当前程序的窗口是置顶的,BaseCommand中提供获取窗口句柄和设置置顶的方法
            //运行程序是，请勿移动鼠标或敲击键盘、鼠标按键

            //切换到“按船名查询”tab页
            BaseCommand.MouseMoveToAndClick(620, 270);
            Thread.Sleep(3000);

            //选择船名输入框
            BaseCommand.MouseMoveToAndClick(573, 309);
            Thread.Sleep(3000);

            //输入要查询的船名
            WebBrowserMain.Invoke(new DoQueryInvokeDelegate(DoSetQueryValue), new object[] { "12345" }); 
            BaseCommand.ClickKey(Keys.Space);
            Thread.Sleep(3000);

            //选择第一个，这里要保证至少有一个匹配项
            BaseCommand.MouseMoveToAndClick(573, 359);
            Thread.Sleep(3000);

            //点击查询按钮
            BaseCommand.MouseMoveToAndClick(828, 310);
            Thread.Sleep(3000);

            //以下写代码从document获取需要的信息
        }
        private delegate void DoQueryInvokeDelegate(string boxNum );
        private void DoSetQueryValue(string boxValue)
        {
            WebBrowserMain.Document.InvokeScript("doSetQueryValue", new object[] { boxValue });
        }
        #endregion 

        #region 注入代码
        private void InvokeSetQueryScript()
        {
            WebBrowserMain.Invoke(new SetQueryScriptInvokeDelegate(SetQueryScript));
        }
        private delegate void SetQueryScriptInvokeDelegate();
        private void SetQueryScript()
        {
            HtmlElement doQueryElement = WebBrowserMain.Document.CreateElement("script");
            IHTMLScriptElement doQueryScriptElement = (IHTMLScriptElement)doQueryElement.DomElement;
            doQueryScriptElement.text = "function doSetQueryValue(boxValue){"
                                + "document.getElementById('ASPxSplitter2_ContentPlaceHolder1_SearchPages_cbVessel_I').value = boxValue;}";
            WebBrowserMain.Document.Body.AppendChild(doQueryElement);
        }
        #endregion
    }
}